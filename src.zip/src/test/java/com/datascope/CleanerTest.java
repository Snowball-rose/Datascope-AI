package com.datascope;

import com.datascope.analysis.*;
import com.datascope.model.*;
import org.junit.jupiter.api.Test;
import java.util.*;
import static org.junit.jupiter.api.Assertions.*;

public class CleanerTest {
    private DataSet sample() {
        return new DataSet("t", List.of("a", "cat"), List.of(
            List.of("1", "x"), List.of("2", "x"), List.of("", "y"), List.of("100", "x"), List.of("2", "x"), List.of("2", "x")));
    }

    @Test void meanImputationFillsBlanksAndLeavesOriginalAlone() {
        DataSet ds = sample();
        var o = Cleaner.impute(ds, 0, "median");
        assertEquals(1, o.changed());
        assertFalse(o.data().rows().stream().anyMatch(r -> r.get(0).isBlank()));
        assertTrue(ds.rows().stream().anyMatch(r -> r.get(0).isBlank()), "original must not change");
    }

    @Test void modeImputationWorksOnText() {
        DataSet ds = new DataSet("t", List.of("c"), List.of(List.of("a"), List.of("a"), List.of(""), List.of("b")));
        assertEquals("a", Cleaner.impute(ds, 0, "mode").data().value(2, 0));
    }

    @Test void dropDuplicatesKeepsFirstOccurrence() {
        var o = Cleaner.dropDuplicates(sample());
        assertEquals(2, o.changed());
        assertEquals(4, o.data().rowCount());
    }

    @Test void dropMissingRemovesBlankRows() {
        assertEquals(5, Cleaner.dropMissing(sample(), 0).data().rowCount());
    }

    @Test void clipOutliersPullsExtremeValuesIn() {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < 30; i++) rows.add(List.of(String.valueOf(10 + i % 3)));
        rows.add(List.of("1000"));
        var o = Cleaner.clipOutliers(new DataSet("t", List.of("v"), rows), 0, 3.0);
        assertEquals(1, o.changed());
        assertTrue(Double.parseDouble(o.data().value(30, 0)) < 1000);
    }

    @Test void outcomeCarriesCellLevelChangesForPreview() {
        var o = Cleaner.impute(sample(), 0, "median");
        assertEquals(1, o.changes().size());
        Cleaner.Change c = o.changes().get(0);
        assertEquals(2, c.row());
        assertEquals("a", c.column());
        assertEquals("(missing)", c.before());
        assertFalse(c.after().isBlank());
    }

    @Test void outcomeCarriesAllChangesBeyondFormerPreviewLimit() {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < 750; i++) rows.add(List.of(""));
        var o = Cleaner.impute(new DataSet("t", List.of("v"), rows), 0, "mean");
        assertEquals(750, o.changed());
        assertEquals(750, o.changes().size());
        assertEquals(749, o.changes().get(749).row());
    }

    @Test void insightsFlagMissingnessAndCorrelation() {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < 40; i++) rows.add(List.of(String.valueOf(i), String.valueOf(i * 2), i % 2 == 0 ? "" : "z"));
        DataSet ds = new DataSet("t", List.of("a", "b", "c"), rows);
        var found = Insights.generate(ds, Profiler.profile(ds));
        assertTrue(found.stream().anyMatch(i -> i.title().contains("missing")));
        assertTrue(found.stream().anyMatch(i -> i.title().contains("↔")));
    }
}
