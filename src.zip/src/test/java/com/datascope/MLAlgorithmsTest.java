package com.datascope;

import com.datascope.ml.*;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.*;

public class MLAlgorithmsTest {
 @Test void kmeansFindsSeparatedGroups(){
   double[][] x={{0,0},{0.2,0.1},{-0.1,0.2},{10,10},{9.8,10.2},{10.1,9.9}};
   var r=KMeans.fit(x,2,50,new Random(1));
   assertEquals(2,r.centroids().length);
   assertEquals(6,r.labels().length);
   assertTrue(r.inertia()<1);
 }
 @Test void pcaReturnsRequestedDimensions(){
   double[][] x={{1,2,3},{2,4,6},{3,6,9},{4,8,12},{5,10,15}};
   var r=PCA.fitTransform(x,3);
   assertEquals(5,r.points().length); assertEquals(3,r.points()[0].length);
 }
 @Test void logisticRegressionLearnsSimpleBoundary(){
   double[][] x={{-2},{-1},{-.5},{.5},{1},{2}}; int[] y={0,0,0,1,1,1};
   var r=LogisticRegression.fit(x,y,1200,.2);
   assertTrue(r.accuracy()>=.99);
 }
 @Test void logisticSelectedRowsAvoidsTrainingMatrixCopy(){
   double[][] x={{-2},{-1},{-.5},{.5},{1},{2}}; int[] y={0,0,0,1,1,1};
   var r=LogisticRegression.fitSelected(x,y,new int[]{0,1,2,3,4,5},1200,.2);
   assertTrue(r.accuracy()>=.99);
 }
 @Test void sampledPcaUsesAllRowsForComponentsButReturnsOnlyRequestedPoints(){
   double[][] x=new double[6_000][2];
   for(int i=0;i<x.length;i++){x[i][0]=i;x[i][1]=i%17;}
   double[][] z=Stats.standardizeInPlace(x);
   var r=PCA.fitTransformStandardizedSampled(z,2,3);
   assertEquals(3,r.points().length);
   assertArrayEquals(new int[]{0,2_999,5_999},r.rows());
   assertEquals(2,r.eigenvalues().length);
 }
 @Test void fullPcaProjectionCanReturnEverySourceRow(){
   double[][] x=new double[2_000][2];
   for(int i=0;i<x.length;i++){x[i][0]=i;x[i][1]=i%17;}
   var r=PCA.fitTransformStandardizedSampled(Stats.standardizeInPlace(x),2,x.length);
   assertEquals(x.length,r.points().length);
   assertEquals(x.length,r.rows().length);
   assertEquals(0,r.rows()[0]);
   assertEquals(x.length-1,r.rows()[x.length-1]);
 }
 @Test void anomalyDetectorFindsExtreme(){
   double[][] x={{0},{0.2},{-0.1},{0.3},{0.1},{9}};
   var r=AnomalyDetector.zScore(x,3);
   assertTrue(r.anomaly()[5]);
 }
}
