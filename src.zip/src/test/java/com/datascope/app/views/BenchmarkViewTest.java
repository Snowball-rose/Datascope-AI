package com.datascope.app.views;

import com.datascope.model.DataSet;
import org.junit.jupiter.api.Test;

import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

class BenchmarkViewTest {
    @Test void benchmarkMeasuresIncreasingSlicesOfDiskBackedData() {
        List<List<String>> rows = java.util.stream.IntStream.range(0, 600)
            .mapToObj(i -> List.of(String.valueOf(i), String.valueOf(i % 17)))
            .toList();
        DataSet dataset = DataSet.fromRows("benchmark", List.of("value", "group"), rows);
        try {
            List<BenchmarkView.Row> result = BenchmarkView.measure(dataset, List.of(0, 1));
            assertEquals(12, result.size());
            assertTrue(result.stream().allMatch(row -> row.rows() > 0 && row.rows() <= 600));
            assertTrue(result.stream().anyMatch(row -> row.rows() == 250));
            assertTrue(result.stream().anyMatch(row -> row.rows() == 500));
            assertTrue(result.stream().anyMatch(row -> row.rows() == 600));
        } finally {
            dataset.close();
        }
    }
}
