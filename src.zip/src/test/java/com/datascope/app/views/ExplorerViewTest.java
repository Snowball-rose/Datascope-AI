package com.datascope.app.views;

import com.datascope.app.AppState;
import javafx.scene.paint.Color;
import org.junit.jupiter.api.Test;

import java.util.concurrent.atomic.AtomicLong;

import static org.junit.jupiter.api.Assertions.assertTrue;

class ExplorerViewTest {
    @Test void rasterIncludesAndMakesLatePointsPickable() {
        double[][] points = new double[2_000][3];
        int[] labels = new int[points.length];
        int[] rows = new int[points.length];
        for (int i = 0; i < points.length; i++) {
            points[i][0] = i % 50 - 25;
            points[i][1] = i / 50 - 20;
            rows[i] = i;
        }
        AppState.Projection projection = AppState.Projection.of(points, labels, rows,
            new String[]{"Rows"}, new Color[]{Color.CYAN}, "Test", "PCA", null, null);

        ExplorerView.RasterFrame frame = ExplorerView.rasterize(
            projection, 400, 300, 0, 0, 1, false, 1, new AtomicLong(1));

        assertTrue(java.util.Arrays.stream(frame.pointAtPixel()).anyMatch(index -> index >= 1_500));
        assertTrue(java.util.Arrays.stream(frame.pointAtPixel()).anyMatch(index -> index == 1_999));
    }
}
