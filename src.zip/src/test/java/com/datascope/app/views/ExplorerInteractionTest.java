package com.datascope.app.views;

import org.junit.jupiter.api.Test;

import java.awt.image.BufferedImage;

import static org.junit.jupiter.api.Assertions.assertEquals;

class ExplorerInteractionTest {
    @Test
    void hitTestMapsDisplayCoordinatesToRasterAndFindsNearbyPoint() {
        int width = 200, height = 100;
        int[] pointAtPixel = new int[width * height];
        java.util.Arrays.fill(pointAtPixel, -1);
        pointAtPixel[50 * width + 100] = 42;
        var frame = new ExplorerView.RasterFrame(
            new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB),
            pointAtPixel, width, height);

        assertEquals(42, ExplorerView.hitTest(frame, 50, 25, 100, 50));
        assertEquals(42, ExplorerView.hitTest(frame, 53.5, 25, 100, 50));
        assertEquals(-1, ExplorerView.hitTest(frame, 80, 25, 100, 50));
        assertEquals(-1, ExplorerView.hitTest(frame, 100, 25, 100, 50));
    }
}
