package com.datascope;

import com.datascope.analysis.Cleaner;
import com.datascope.app.AppState;
import com.datascope.io.DataLoader;
import com.datascope.model.DataSet;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

import java.io.OutputStream;
import java.nio.file.Path;
import java.nio.file.Files;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import static org.junit.jupiter.api.Assertions.*;

class DataSetScalingTest {
    @TempDir Path temp;

    @Test void csvLoadingAndMatrixAccessIncludeRowsPastFiveThousand() throws Exception {
        Path csv = temp.resolve("large.csv");
        StringBuilder content = new StringBuilder("value\n");
        for (int i = 0; i < 6_250; i++) content.append(i).append('\n');
        Files.writeString(csv, content);

        DataSet ds = DataLoader.load(csv);
        try {
            assertEquals(6_250, ds.rowCount());
            assertEquals("6249", ds.value(6_249, 0));
            double[][] matrix = AppState.matrix(ds, List.of(0), Integer.MAX_VALUE);
            assertEquals(6_250, matrix.length);
            assertEquals(6_249, matrix[6_249][0]);
        } finally {
            ds.close();
        }
    }

    @Test void cleaningWritesAllRowsToDiskBackedOutput() {
        List<List<String>> rows = java.util.stream.IntStream.range(0, 6_250)
            .mapToObj(i -> List.of(i == 6_249 ? "" : String.valueOf(i)))
            .toList();
        DataSet input = new DataSet("large", List.of("value"), rows);
        Cleaner.Outcome cleaned = Cleaner.impute(input, 0, "mean");
        try {
            assertEquals(6_250, cleaned.data().rowCount());
            assertEquals(1, cleaned.changed());
            assertFalse(cleaned.data().value(6_249, 0).isBlank());
        } finally {
            cleaned.data().close();
        }
    }

    @Test void typeInferenceChecksRowsBeyondInitialSample() {
        List<List<String>> rows = new java.util.ArrayList<>();
        for (int i = 0; i < 1_000; i++) rows.add(List.of(String.valueOf(i % 50)));
        for (int i = 0; i < 200; i++) rows.add(List.of("text-" + i));
        DataSet ds = DataSet.fromRows("mixed", List.of("value"), rows);
        try {
            assertEquals(com.datascope.model.ColumnType.TEXT, ds.inferType(0));
        } finally {
            ds.close();
        }
    }

    @Test void diskBackedRowsCanBeReadConcurrently() throws Exception {
        List<List<String>> rows = java.util.stream.IntStream.range(0, 2_000)
            .mapToObj(i -> List.of(String.valueOf(i), "value-" + i))
            .toList();
        DataSet ds = DataSet.fromRows("concurrent", List.of("number", "text"), rows);
        ExecutorService readers = Executors.newFixedThreadPool(4);
        try {
            List<Future<?>> checks = new java.util.ArrayList<>();
            for (int worker = 0; worker < 4; worker++) {
                int offset = worker;
                checks.add(readers.submit(() -> {
                    for (int i = offset; i < ds.rowCount(); i += 4) {
                        assertEquals(String.valueOf(i), ds.value(i, 0));
                        assertEquals("value-" + i, ds.value(i, 1));
                    }
                }));
            }
            for (Future<?> check : checks) check.get();
        } finally {
            readers.shutdownNow();
            ds.close();
        }
    }

    @Test void matrixComputesImputationMeanAcrossAllRowsInOnePass() {
        DataSet ds = DataSet.fromRows("missing", List.of("value"),
            List.of(List.of("10"), List.of(""), List.of("30")));
        try {
            double[][] matrix = AppState.matrix(ds, List.of(0), 2);
            assertEquals(2, matrix.length);
            assertEquals(10, matrix[0][0]);
            assertEquals(20, matrix[1][0]);
        } finally {
            ds.close();
        }
    }

    @Test void xlsxLoadingStreamsRowsPastFormerPreviewLimit() throws Exception {
        Path xlsx = temp.resolve("large.xlsx");
        try (XSSFWorkbook workbook = new XSSFWorkbook()) {
            var sheet = workbook.createSheet();
            Row header = sheet.createRow(0);
            header.createCell(0).setCellValue("value");
            for (int i = 0; i < 6_250; i++) sheet.createRow(i + 1).createCell(0).setCellValue(i);
            try (OutputStream output = Files.newOutputStream(xlsx)) {
                workbook.write(output);
            }
        }

        DataSet ds = DataLoader.load(xlsx);
        try {
            assertEquals(6_250, ds.rowCount());
            assertEquals("6249", ds.value(6_249, 0));
        } finally {
            ds.close();
        }
    }
}
