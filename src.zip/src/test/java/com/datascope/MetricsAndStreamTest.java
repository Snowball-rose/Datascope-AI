package com.datascope;

import com.datascope.ml.*;
import com.datascope.model.DataSet;
import com.datascope.stream.ReplayEngine;
import org.junit.jupiter.api.Test;
import java.util.*;
import java.util.concurrent.*;
import static org.junit.jupiter.api.Assertions.*;

public class MetricsAndStreamTest {
    @Test void splitPartitionsAllRows() {
        var s = Metrics.split(50, 0.2, new Random(1));
        assertEquals(10, s.test().length);
        assertEquals(40, s.train().length);
        Set<Integer> all = new HashSet<>();
        for (int i : s.test()) all.add(i);
        for (int i : s.train()) all.add(i);
        assertEquals(50, all.size());
    }

    @Test void confusionMetrics() {
        var c = Metrics.confusion(new int[]{1, 1, 0, 0}, new int[]{1, 0, 0, 1});
        assertEquals(1, c.tp()); assertEquals(1, c.fn()); assertEquals(1, c.tn()); assertEquals(1, c.fp());
        assertEquals(0.5, c.f1(), 1e-9);
    }

    @Test void silhouetteIsHighForSeparatedClusters() {
        double[][] x = {{0, 0}, {0.1, 0}, {0, 0.1}, {9, 9}, {9.1, 9}, {9, 9.1}};
        assertTrue(Metrics.silhouette(x, new int[]{0, 0, 0, 1, 1, 1}, 2, 100) > 0.9);
    }

    @Test void constantColumnsDoNotProduceNaN() {
        double[][] z = Stats.standardize(new double[][]{{1, 5}, {2, 5}, {3, 5}});
        assertFalse(Double.isNaN(z[0][1]));
    }

    @Test void anomalyReportsDrivingFeature() {
        var r = AnomalyDetector.zScore(new double[][]{{0, 0}, {0.1, 0.1}, {-0.1, 0}, {0.2, -0.1}, {0, 8}}, 3);
        assertTrue(r.anomaly()[4]);
        assertEquals(1, r.topFeature()[4]);
    }

    @Test void replayFiresCompletionWhenAllRowsAreProcessed() throws Exception {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < 200; i++) rows.add(List.of(String.valueOf(i)));
        DataSet ds = new DataSet("t", List.of("v"), rows);
        ReplayEngine e = new ReplayEngine();
        CountDownLatch done = new CountDownLatch(1);
        e.start(ds, 5000, 500, i -> {}, done::countDown);
        assertTrue(done.await(5, TimeUnit.SECONDS));
        assertEquals(200, e.processed() + e.dropped());
    }

    @Test void replayDropsRowsWhenConsumerIsSlowAndQueueIsSmall() throws Exception {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < 300; i++) rows.add(List.of(String.valueOf(i)));
        DataSet ds = new DataSet("t", List.of("v"), rows);
        ReplayEngine e = new ReplayEngine();
        CountDownLatch done = new CountDownLatch(1);
        e.start(ds, 10000, 10, i -> { try { Thread.sleep(3); } catch (InterruptedException ignored) {} }, done::countDown);
        assertTrue(done.await(15, TimeUnit.SECONDS));
        assertTrue(e.dropped() > 0);
    }
}
