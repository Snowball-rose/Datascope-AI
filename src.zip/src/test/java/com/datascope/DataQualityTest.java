package com.datascope;

import com.datascope.analysis.DataQuality;
import com.datascope.analysis.Profiler;
import com.datascope.model.DataSet;
import org.junit.jupiter.api.Test;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

public class DataQualityTest {
    private DataSet clean() {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < 100; i++) rows.add(List.of(String.valueOf(i), i % 2 == 0 ? "yes" : "no"));
        return new DataSet("clean", List.of("value", "flag"), rows);
    }

    @Test void scoreIsBoundedAndHighForCleanData() {
        DataSet ds = clean();
        DataQuality.Result q = DataQuality.score(ds, Profiler.profile(ds));
        assertTrue(q.score() >= 0 && q.score() <= 100);
        assertTrue(q.score() >= 90, "clean data should score highly, was " + q.score());
        assertEquals(0, q.duplicateRows());
    }

    @Test void duplicateRowsReduceUniqueness() {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < 50; i++) rows.add(List.of("same", "same"));
        DataSet ds = new DataSet("dupes", List.of("a", "b"), rows);
        DataQuality.Result q = DataQuality.score(ds, Profiler.profile(ds));
        assertEquals(49, q.duplicateRows());
        assertTrue(q.uniqueness() < 0.5);
    }

    @Test void constantColumnReducesConsistency() {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < 100; i++) rows.add(List.of(String.valueOf(i), "constant"));
        DataSet ds = new DataSet("const", List.of("value", "flat"), rows);
        DataQuality.Result q = DataQuality.score(ds, Profiler.profile(ds));
        assertEquals(1, q.constantColumns());
        assertTrue(q.consistency() < 1.0);
    }

    @Test void missingCellsAreCountedNotAveragedAway() {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < 99; i++) rows.add(List.of(String.valueOf(i), "full"));
        rows.add(List.of("", ""));
        DataSet ds = new DataSet("gap", List.of("a", "b"), rows);
        DataQuality.Result q = DataQuality.score(ds, Profiler.profile(ds));
        assertEquals(2, q.missingCells());
        assertTrue(q.completeness() < 1.0);
    }

    @Test void profilingTypesMatchDatasetInference() {
        List<List<String>> rows = new ArrayList<>();
        for (int i = 0; i < 100; i++) {
            rows.add(List.of(String.valueOf(i), i % 2 == 0 ? "yes" : "no", "2024-01-01",
                i % 3 == 0 ? "a" : "b", "id-" + i, ""));
        }
        DataSet ds = new DataSet("types", List.of("number", "boolean", "date", "category", "text", "empty"), rows);
        List<com.datascope.model.ColumnProfile> profiles = Profiler.profile(ds);
        for (int c = 0; c < ds.columnCount(); c++)
            assertEquals(ds.inferType(c), profiles.get(c).type(), ds.columns().get(c));
    }
}
