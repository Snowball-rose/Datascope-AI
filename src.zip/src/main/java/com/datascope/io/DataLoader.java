package com.datascope.io;

import com.datascope.model.DataSet;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.util.CellReference;
import org.apache.poi.util.XMLHelper;
import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.model.SharedStrings;
import org.apache.poi.xssf.model.StylesTable;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import org.xml.sax.*;

public final class DataLoader {
    private DataLoader() {}

    public static DataSet load(Path file) throws IOException {
        String lower = file.getFileName().toString().toLowerCase(Locale.ROOT);
        return lower.endsWith(".xlsx") ? loadXlsx(file) : loadCsv(file);
    }

    private static DataSet loadCsv(Path file) throws IOException {
        try (BufferedReader reader = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            return fromReader(reader, file.getFileName().toString());
        }
    }

    /** Loads a CSV bundled on the classpath (used for the built-in demo so it works from any working directory). */
    public static DataSet loadCsvResource(String resource, String displayName) throws IOException {
        try (InputStream in = DataLoader.class.getResourceAsStream(resource)) {
            if (in == null) throw new FileNotFoundException("Bundled resource not found: " + resource);
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
                return fromReader(reader, displayName);
            }
        }
    }

    private static DataSet fromReader(BufferedReader reader, String name) throws IOException {
        String first = reader.readLine();
        if (first == null) return new DataSet(name, List.of(), List.of());
        if (first.startsWith("\uFEFF")) first = first.substring(1); // strip UTF-8 byte-order mark
        List<String> headers = parseCsvLine(first);
        Iterable<List<String>> rows = () -> new Iterator<>() {
            private List<String> next = readNext();

            private List<String> readNext() {
                try {
                    String line;
                    while ((line = reader.readLine()) != null) {
                        if (line.isBlank()) continue;
                        List<String> row = parseCsvLine(line);
                        while (row.size() < headers.size()) row.add("");
                        if (row.size() > headers.size()) row = new ArrayList<>(row.subList(0, headers.size()));
                        return row;
                    }
                    return null;
                } catch (IOException e) {
                    throw new UncheckedIOException("Could not read CSV rows", e);
                }
            }

            @Override public boolean hasNext() { return next != null; }
            @Override public List<String> next() {
                if (next == null) throw new NoSuchElementException();
                List<String> row = next;
                next = readNext();
                return row;
            }
        };
        return DataSet.fromRows(name, headers, rows);
    }

    private static List<String> parseCsvLine(String line) {
        List<String> values = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean quoted = false;
        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);
            if (c == '"') {
                if (quoted && i + 1 < line.length() && line.charAt(i + 1) == '"') { current.append('"'); i++; }
                else quoted = !quoted;
            } else if (c == ',' && !quoted) { values.add(current.toString().trim()); current.setLength(0); }
            else current.append(c);
        }
        values.add(current.toString().trim());
        return values;
    }

    private static DataSet loadXlsx(Path file) throws IOException {
        try (OPCPackage pkg = OPCPackage.open(file.toFile(), PackageAccess.READ)) {
            XSSFReader workbook = new XSSFReader(pkg);
            StylesTable styles = workbook.getStylesTable();
            SharedStrings strings = new ReadOnlySharedStringsTable(pkg);
            Iterator<InputStream> sheets = workbook.getSheetsData();
            if (!sheets.hasNext()) return new DataSet(file.getFileName().toString(), List.of(), List.of());

            DataSet.DiskWriter[] writer = new DataSet.DiskWriter[1];
            boolean[] built = {false};
            try (InputStream sheet = sheets.next()) {
                XSSFSheetXMLHandler.SheetContentsHandler rows = new XSSFSheetXMLHandler.SheetContentsHandler() {
                    private List<String> current;
                    private List<String> headers;

                    @Override public void startRow(int rowNum) { current = new ArrayList<>(); }
                    @Override public void endRow(int rowNum) {
                        if (headers == null) {
                            if (current.stream().allMatch(String::isBlank)) return;
                            headers = List.copyOf(current);
                            try { writer[0] = DataSet.newWriter(file.getFileName().toString(), headers); }
                            catch (IOException e) { throw new IllegalStateException(e); }
                            return;
                        }
                        if (current.stream().allMatch(String::isBlank)) return;
                        List<String> normalized = new ArrayList<>(headers.size());
                        for (int c = 0; c < headers.size(); c++) normalized.add(c < current.size() ? current.get(c) : "");
                        try { writer[0].addRow(normalized); }
                        catch (IOException e) { throw new IllegalStateException(e); }
                    }
                    @Override public void cell(String cellReference, String formattedValue, org.apache.poi.xssf.usermodel.XSSFComment comment) {
                        int col = cellReference == null ? current.size() : columnIndex(cellReference);
                        while (current.size() <= col) current.add("");
                        current.set(col, formattedValue == null ? "" : formattedValue);
                    }
                    @Override public void headerFooter(String text, boolean isHeader, String tagName) {}
                };
                XMLReader parser = XMLHelper.newXMLReader();
                parser.setContentHandler(new XSSFSheetXMLHandler(styles, strings, rows, new DataFormatter(), false));
                parser.parse(new InputSource(sheet));
                if (writer[0] == null) return new DataSet(file.getFileName().toString(), List.of(), List.of());
                DataSet result = writer[0].build();
                built[0] = true;
                return result;
            } catch (SAXException e) {
                throw new IOException("Could not read XLSX rows from " + file.getFileName(), e);
            } finally {
                if (writer[0] != null && !built[0]) writer[0].close();
            }
        } catch (org.apache.poi.openxml4j.exceptions.InvalidFormatException e) {
            throw new IOException("Invalid XLSX file: " + file.getFileName(), e);
        } catch (org.apache.poi.openxml4j.exceptions.OpenXML4JException
                 | SAXException
                 | javax.xml.parsers.ParserConfigurationException e) {
            throw new IOException("Could not stream XLSX file: " + file.getFileName(), e);
        }
    }

    private static int columnIndex(String cellReference) {
        int end = 0;
        while (end < cellReference.length() && Character.isLetter(cellReference.charAt(end))) end++;
        return CellReference.convertColStringToIndex(cellReference.substring(0, end));
    }
}
