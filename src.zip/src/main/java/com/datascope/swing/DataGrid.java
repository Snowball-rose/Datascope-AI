package com.datascope.swing;

import javafx.embed.swing.SwingNode;

import javax.swing.*;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableRowSorter;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.function.BiConsumer;
import java.util.function.IntConsumer;

/*
 * A dark-themed, sortable, filterable Swing data grid, embedded in the JavaFX shell through a
 * {@link SwingNode}.
 *
 * The interface is a JavaFX application: the shell, the theme, the
 * charts, the animated 3D point cloud and the page transitions are all JavaFX, where its CSS
 * engine and scene graph are far ahead of anything Swing offers. Dense tabular work is the
 * opposite case — {@code JTable} with {@code TableRowSorter} and a predicate {@code RowFilter}
 * is the most capable grid in either toolkit, and it stays smooth with tens of thousands of rows.
 * So every data grid in the app is a real Swing component hosted in a {@code SwingNode}.
 */
public final class DataGrid extends JPanel {

    /* Match modes shared with the JavaFX filter controls. */
    public static final String[] MODES =
        {"contains", "equals", "starts with", "is empty", "is not empty", ">", "≥", "<", "≤"};

    private final DefaultTableModel model = new DefaultTableModel() {
        @Override public boolean isCellEditable(int r, int c) { return false; }
    };

    private final JTable table = new JTable(model) {
        @Override public boolean getScrollableTracksViewportWidth() {
            return getPreferredSize().width < Math.max(1, getParent() == null ? 1 : getParent().getWidth());
        }
        @Override public String getToolTipText(MouseEvent e) {
            int row = rowAtPoint(e.getPoint()), col = columnAtPoint(e.getPoint());
            if (row < 0 || col < 0) return null;
            Object raw = getValueAt(row, col);
            String s = raw == null ? "" : String.valueOf(raw);
            if (s.isBlank()) return null;
            int available = getColumnModel().getColumn(col).getWidth() - 28;
            return getFontMetrics(getFont()).stringWidth(s) > available ? s : null;
        }
        @Override public JToolTip createToolTip() {
            JToolTip tip = super.createToolTip();
            tip.setBackground(SwingTheme.CARD);
            tip.setForeground(SwingTheme.TEXT);
            tip.setFont(SwingTheme.BODY);
            tip.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(SwingTheme.BORDER),
                BorderFactory.createEmptyBorder(5, 9, 5, 9)));
            return tip;
        }
        @Override protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (getRowCount() == 0 && emptyText != null && !emptyText.isBlank()) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
                g2.setColor(SwingTheme.MUTED);
                g2.setFont(SwingTheme.BODY);
                FontMetrics fm = g2.getFontMetrics();
                int x = Math.max(14, (getWidth() - fm.stringWidth(emptyText)) / 2);
                int y = Math.max(fm.getHeight() + 14, getHeight() / 2);
                g2.drawString(emptyText, x, y);
                g2.dispose();
            }
        }
    };

    private final TableRowSorter<DefaultTableModel> sorter = new TableRowSorter<>(model);
    private final JScrollPane scroll = new JScrollPane(table);
    private String emptyText = "No data loaded";
    private BiConsumer<Integer, List<String>> onDoubleClick;

    public DataGrid(int preferredHeight) {
        super(new BorderLayout());
        setOpaque(true);
        setBackground(SwingTheme.PANEL);
        setBorder(BorderFactory.createEmptyBorder());

        table.setBackground(SwingTheme.PANEL);
        table.setForeground(SwingTheme.TEXT);
        table.setFont(SwingTheme.BODY);
        table.setRowHeight(29);
        table.setShowVerticalLines(false);
        table.setShowHorizontalLines(true);
        table.setGridColor(SwingTheme.LINE);
        table.setIntercellSpacing(new Dimension(0, 1));
        table.setSelectionBackground(SwingTheme.SELECT);
        table.setSelectionForeground(SwingTheme.TEXT);
        table.setFillsViewportHeight(true);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
        table.setRowSorter(sorter);
        table.setFocusable(true);
        table.setDefaultRenderer(Object.class, new CellRenderer());

        JTableHeader header = table.getTableHeader();
        header.setReorderingAllowed(false);
        header.setBackground(SwingTheme.HEADER);
        header.setForeground(SwingTheme.MUTED);
        header.setFont(SwingTheme.BOLD);
        header.setPreferredSize(new Dimension(-1, 32));
        header.setDefaultRenderer(new HeaderRenderer());

        table.addMouseListener(new MouseAdapter() {
            @Override public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() != 2 || onDoubleClick == null) return;
                int viewRow = table.rowAtPoint(e.getPoint());
                if (viewRow < 0) return;
                int modelRow = table.convertRowIndexToModel(viewRow);
                List<String> row = new ArrayList<>();
                for (int c = 0; c < model.getColumnCount(); c++) {
                    Object v = model.getValueAt(modelRow, c);
                    row.add(v == null ? "" : String.valueOf(v));
                }
                onDoubleClick.accept(modelRow, row);
            }
        });

        scroll.setBorder(BorderFactory.createEmptyBorder());
        scroll.setBackground(SwingTheme.PANEL);
        scroll.getViewport().setBackground(SwingTheme.PANEL);
        scroll.setPreferredSize(new Dimension(900, preferredHeight));
        scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
        scroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
        SwingTheme.skin(scroll.getVerticalScrollBar());
        SwingTheme.skin(scroll.getHorizontalScrollBar());
        add(scroll, BorderLayout.CENTER);
    }

    /* Wraps this grid in a JavaFX node so it can be placed inside the JavaFX scene graph. */
    public SwingNode node() {
        SwingNode n = new SwingNode();
        n.setContent(this);
        n.setFocusTraversable(true);
        return n;
    }

    public void setEmptyText(String text) { this.emptyText = text; table.repaint(); }

    public void setOnRowDoubleClick(BiConsumer<Integer, List<String>> handler) { this.onDoubleClick = handler; }

    /* Called with the model row index whenever the selection changes. */
    public void setOnRowSelected(IntConsumer handler) {
        table.getSelectionModel().addListSelectionListener(e -> {
            if (e.getValueIsAdjusting()) return;
            int viewRow = table.getSelectedRow();
            if (viewRow >= 0) handler.accept(table.convertRowIndexToModel(viewRow));
        });
    }

    /* Selects a row by model index (no-op when it is filtered out). */
    public void selectRow(int modelRow) {
        int view = table.convertRowIndexToView(modelRow);
        if (view >= 0) table.setRowSelectionInterval(view, view);
    }

    /* Empties the grid, keeping the current column set. */
    public void clear() { model.setRowCount(0); }

    /* Replaces the contents of the grid. Column widths and sort comparators are recomputed. */
    public void setData(List<String> columns, List<List<String>> rows) {
        Object[] ids = columns.toArray();
        Object[][] data = new Object[rows.size()][];
        for (int i = 0; i < rows.size(); i++) {
            List<String> r = rows.get(i);
            Object[] cells = new Object[columns.size()];
            for (int c = 0; c < columns.size(); c++) cells[c] = c < r.size() ? r.get(c) : "";
            data[i] = cells;
        }
        model.setDataVector(data, ids);
        for (int c = 0; c < columns.size(); c++) {
            table.getColumnModel().getColumn(c).setPreferredWidth(widthFor(columns.get(c), rows, c));
            sorter.setComparator(c, numericFirst(rows, c));
        }
    }

    /* Column width from the header text and a sample of the values, so nothing is cut off. */
    private static int widthFor(String header, List<List<String>> rows, int column) {
        int widest = header == null ? 0 : header.length();
        int limit = Math.min(rows.size(), 60);
        for (int i = 0; i < limit; i++) {
            List<String> r = rows.get(i);
            if (column >= r.size()) continue;
            String v = r.get(column);
            if (v != null) widest = Math.max(widest, v.length());
        }
        return Math.max(104, Math.min(280, widest * 8 + 48));
    }

    /**
     * Filters rows. A negative {@code column} searches every column; {@code mode} is one of
     * {@link #MODES}.
     */
    public void setFilter(int column, String mode, String needle) {
        String m = mode == null ? "contains" : mode;
        String n = needle == null ? "" : needle.trim().toLowerCase(Locale.ROOT);
        if (n.isEmpty() && !m.equals("is empty") && !m.equals("is not empty")) { sorter.setRowFilter(null); return; }
        sorter.setRowFilter(new RowFilter<DefaultTableModel, Integer>() {
            @Override public boolean include(Entry<? extends DefaultTableModel, ? extends Integer> e) {
                int count = e.getValueCount();
                if (column < 0) {
                    for (int i = 0; i < count; i++) if (match(text(e, i), m, n)) return true;
                    return false;
                }
                return column < count && match(text(e, column), m, n);
            }
        });
    }

    public int visibleRowCount() { return table.getRowCount(); }
    public int totalRowCount() { return model.getRowCount(); }
    public JTable table() { return table; }

    private static String text(RowFilter.Entry<?, ?> e, int i) {
        String v = e.getStringValue(i);
        return v == null ? "" : v;
    }

    private static boolean match(String value, String mode, String needle) {
        String s = value == null ? "" : value;
        return switch (mode) {
            case "equals" -> s.toLowerCase(Locale.ROOT).equals(needle);
            case "starts with" -> s.toLowerCase(Locale.ROOT).startsWith(needle);
            case "is empty" -> s.isBlank();
            case "is not empty" -> !s.isBlank();
            case ">", "≥", "<", "≤" -> {
                Double a = parse(s), b = parse(needle);
                if (a == null || b == null) yield false;
                yield switch (mode) {
                    case ">" -> a > b;
                    case "≥" -> a >= b;
                    case "<" -> a < b;
                    default -> a <= b;
                };
            }
            default -> s.toLowerCase(Locale.ROOT).contains(needle);
        };
    }

    private static Double parse(String s) {
        if (s == null) return null;
        try { return Double.parseDouble(s.trim().replace(",", "")); } catch (Exception e) { return null; }
    }

    /** Numeric columns sort by value (blanks last); everything else sorts case-insensitively. */
    private static Comparator<Object> numericFirst(List<List<String>> rows, int column) {
        int seen = 0, numeric = 0;
        for (List<String> r : rows) {
            if (column >= r.size()) continue;
            String v = r.get(column);
            if (v == null || v.isBlank()) continue;
            seen++;
            if (parse(v) != null) numeric++;
            if (seen >= 250) break;
        }
        boolean byNumber = seen > 0 && numeric >= seen * 0.8;
        return (a, b) -> {
            if (byNumber) {
                Double x = parse(String.valueOf(a)), y = parse(String.valueOf(b));
                if (x != null && y != null) return Double.compare(x, y);
                if (x == null && y == null) return 0;
                return x == null ? 1 : -1;
            }
            return String.valueOf(a).compareToIgnoreCase(String.valueOf(b));
        };
    }

    // ---- renderers ---------------------------------------------------------

    private static final class CellRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(
                JTable t, Object value, boolean selected, boolean focus, int row, int column) {
            super.getTableCellRendererComponent(t, value, selected, false, row, column);
            setFont(SwingTheme.BODY);
            setBorder(BorderFactory.createEmptyBorder(0, 13, 0, 13));
            setBackground(selected ? SwingTheme.SELECT : (row % 2 == 0 ? SwingTheme.ROW : SwingTheme.ROW_ALT));
            setForeground(SwingTheme.TEXT);
            String s = value == null ? "" : String.valueOf(value);
            if (s.isBlank()) { setText("—"); setForeground(SwingTheme.MISSING); }
            else setText(s);
            return this;
        }
    }

    private static final class HeaderRenderer extends DefaultTableCellRenderer {
        @Override public Component getTableCellRendererComponent(
                JTable t, Object value, boolean selected, boolean focus, int row, int column) {
            JLabel l = (JLabel) super.getTableCellRendererComponent(t, value, false, false, row, column);
            l.setOpaque(true);
            l.setBackground(SwingTheme.HEADER);
            l.setForeground(SwingTheme.MUTED);
            l.setFont(SwingTheme.BOLD);
            l.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 1, SwingTheme.BORDER),
                BorderFactory.createEmptyBorder(0, 13, 0, 13)));
            l.setHorizontalAlignment(SwingConstants.LEFT);
            return l;
        }
    }
}
