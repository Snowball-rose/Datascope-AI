package com.datascope.swing;

import javax.swing.*;
import javax.swing.plaf.basic.BasicScrollBarUI;
import java.awt.*;
import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

/**
 * Colour and font tokens for the embedded Swing components.
 *
 * These values deliberately mirror {@code datascope.css} so a Swing grid dropped into the
 * JavaFX shell is indistinguishable from a native JavaFX control. Swing is used for the dense
 * data grids; JavaFX owns the shell, the theme, the charts and the 3D view.
 */
public final class SwingTheme {

    public static final Color BG      = new Color(0x07, 0x0a, 0x0f);
    public static final Color PANEL   = new Color(0x0b, 0x10, 0x18);
    public static final Color CARD    = new Color(0x0c, 0x11, 0x19);
    public static final Color ROW     = new Color(0x0b, 0x10, 0x18);
    public static final Color ROW_ALT = new Color(0x0d, 0x14, 0x1d);
    public static final Color HEADER  = new Color(0x10, 0x18, 0x24);
    public static final Color BORDER  = new Color(0x1d, 0x2a, 0x3a);
    public static final Color LINE    = new Color(0x11, 0x1b, 0x27);
    public static final Color TEXT    = new Color(0xdc, 0xe8, 0xf5);
    public static final Color MUTED   = new Color(0x7d, 0x8c, 0xa0);
    public static final Color SELECT  = new Color(0x1b, 0x33, 0x50);
    public static final Color ACCENT  = new Color(0x43, 0xd8, 0xff);
    public static final Color MISSING = new Color(0xff, 0x7a, 0x45);

    public static final Font BODY = family(13f, Font.PLAIN);
    public static final Font BOLD = family(12f, Font.BOLD);

    private static Font family(float size, int style) {
        String[] wanted = {"Inter", "Segoe UI", "Helvetica Neue", "Liberation Sans", "DejaVu Sans"};
        Set<String> have = new HashSet<>(Arrays.asList(
            GraphicsEnvironment.getLocalGraphicsEnvironment().getAvailableFontFamilyNames()));
        for (String w : wanted) if (have.contains(w)) return new Font(w, style, Math.round(size));
        return new Font(Font.SANS_SERIF, style, Math.round(size));
    }

    /** Applies the dark scrollbar skin to a scroll bar. */
    public static void skin(JScrollBar bar) {
        bar.setBackground(PANEL);
        bar.setUI(new BasicScrollBarUI() {
            @Override protected void configureScrollBarColors() {
                this.thumbColor = BORDER;
                this.trackColor = PANEL;
            }
            @Override protected JButton createDecreaseButton(int o) { return zero(); }
            @Override protected JButton createIncreaseButton(int o) { return zero(); }
            private JButton zero() {
                JButton b = new JButton();
                b.setPreferredSize(new Dimension(0, 0));
                b.setMinimumSize(new Dimension(0, 0));
                b.setMaximumSize(new Dimension(0, 0));
                return b;
            }
            @Override protected void paintTrack(Graphics g, JComponent c, Rectangle r) {
                g.setColor(trackColor); g.fillRect(r.x, r.y, r.width, r.height);
            }
            @Override protected void paintThumb(Graphics g, JComponent c, Rectangle r) {
                if (r.isEmpty() || !c.isEnabled()) return;
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(thumbColor);
                g2.fillRoundRect(r.x + 1, r.y + 1, r.width - 2, r.height - 2, 8, 8);
                g2.dispose();
            }
        });
    }

    private SwingTheme() {}
}
