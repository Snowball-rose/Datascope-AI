package com.datascope.app.views;

import com.datascope.app.AppState;
import com.datascope.ml.*;
import com.datascope.util.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.scene.Node;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import com.datascope.model.DataSet;

import java.util.*;

/**
 * Times the core algorithms at increasing row counts so you can see how they scale.
 * Answers the practical question: "will this still feel fast on my real dataset?"
 */
public final class BenchmarkView {
    record Row(String experiment, int rows, long millis, String result) {}

    private final AppState st;
    private final ScrollPane root;
    private final Button run = Ui.button("Run benchmark suite");
    private final Label status = new Label("Not run yet.");
    private final com.datascope.swing.DataGrid table = new com.datascope.swing.DataGrid(310);
    private final LineChart<String, Number> chart = Ui.lineChart("Time (ms) vs rows", 340);

    public BenchmarkView(AppState st) {
        this.st = st;
        status.getStyleClass().add("muted"); status.setWrapText(true);
        table.setEmptyText("Run the suite to measure your data");
        run.setOnAction(e -> execute());

        VBox explain = new VBox(10,
            Ui.muted("This page runs DataScope's own algorithms on progressively larger slices of your dataset and records the wall-clock time of each run. "
                + "It answers: how does K-Means / PCA / anomaly scoring behave as the data grows, and where does it stop feeling instant?"),
            Ui.muted("• X axis = number of rows fed to the algorithm, Y axis = time in milliseconds."),
            Ui.muted("• “ms / 1k rows” normalises for size — a flat line means linear scaling, a rising line means super-linear (e.g. silhouette is O(n²))."),
            Ui.muted("• Hover any point on the chart to read the exact measurement."));

        root = Ui.page("Benchmark", "Measure how the from-scratch algorithms scale on your data.",
            Ui.card("HOW TO READ THIS PAGE", explain),
            Ui.card("RUN", new VBox(14, run, status)),
            Ui.card("SCALING CURVE", chart),
            Ui.card("MEASUREMENTS", table.node()));
        st.onData(() -> { table.clear(); chart.getData().clear(); status.setText("Not run yet."); });
    }

    public Node node() { return root; }

    private void execute() {
        if (!st.hasData()) { status.setText("Load a dataset with numeric columns first."); return; }
        DataSet dataset = st.dataset();
        List<Integer> nums = st.numericIndexes();
        if (nums.isEmpty()) { status.setText("Load a dataset with numeric columns first."); return; }
        run.setDisable(true); status.setText("Benchmarking… (running each algorithm at several row counts)");
        Async.run(() -> measure(dataset, nums), rows -> {
            run.setDisable(false);
            if (st.dataset() != dataset) {
                status.setText("Benchmark finished, but the dataset changed while it was running. Run it again for the current dataset.");
                return;
            }
            status.setText("Finished " + rows.size() + " measurements on " + dataset.name() + ".");
            List<List<String>> cells = new ArrayList<>();
            for (Row r : rows) cells.add(Arrays.asList(r.experiment(), String.valueOf(r.rows()), String.valueOf(r.millis()),
                String.format("%.2f", r.rows() == 0 ? 0 : r.millis() * 1000.0 / r.rows()), r.result()));
            table.setData(List.of("Experiment", "Rows", "Time (ms)", "ms / 1k rows", "Result"), cells);
            Map<String, XYChart.Series<String, Number>> byExp = new LinkedHashMap<>();
            for (Row r : rows) {
                XYChart.Series<String, Number> s = byExp.computeIfAbsent(r.experiment(), n -> { XYChart.Series<String, Number> sx = new XYChart.Series<>(); sx.setName(n); return sx; });
                XYChart.Data<String, Number> d = new XYChart.Data<>(String.valueOf(r.rows()), r.millis());
                d.setExtraValue(r.experiment() + "  ·  " + r.rows() + " rows  ·  " + r.millis() + " ms  ·  " + r.result());
                s.getData().add(d);
            }
            chart.getData().setAll(byExp.values());
            chart.setLegendVisible(true);
        }, err -> { run.setDisable(false); status.setText("Benchmark failed: " + describe(err)); });
    }

    private static String describe(Throwable err) {
        String message = err.getMessage();
        return err.getClass().getSimpleName() + (message == null || message.isBlank() ? "" : ": " + message);
    }

    static List<Row> measure(DataSet dataset, List<Integer> nums) {
        int total = dataset.rowCount();
        TreeSet<Integer> sizes = new TreeSet<>();
        for (int s : new int[]{250, 500, 1000, 2000, 5000}) if (s < total) sizes.add(s);
        sizes.add(Math.min(total, 20000));
        double[][] allRows = AppState.matrix(dataset, nums, sizes.last());
        double[][] warmup = Arrays.copyOf(allRows, Math.min(250, allRows.length));
        KMeans.fit(Stats.standardize(warmup), 3, 20, new Random(1)); // JIT warm-up

        List<Row> out = new ArrayList<>();
        for (int n : sizes) {
            double[][] x = Arrays.copyOf(allRows, n), z = Stats.standardize(x);
            long t = System.nanoTime();
            KMeans.Result km = KMeans.fit(z, 4, 50, new Random(7));
            out.add(new Row("K-Means (k=4)", x.length, ms(t), "inertia " + String.format("%.1f", km.inertia())));
            t = System.nanoTime();
            PCA.Result pca = PCA.fitTransform(x, 3);
            out.add(new Row("PCA (3 comps)", x.length, ms(t), pca.eigenvalues().length + " components"));
            t = System.nanoTime();
            AnomalyDetector.Result an = AnomalyDetector.zScore(z, 3.5);
            long flagged = 0; for (boolean b : an.anomaly()) if (b) flagged++;
            out.add(new Row("Anomaly scoring", x.length, ms(t), flagged + " flagged"));
            if (n <= 2000) {
                t = System.nanoTime();
                double sil = Metrics.silhouette(z, km.labels(), km.centroids().length, 2000);
                out.add(new Row("Silhouette (O(n²))", x.length, ms(t), "score " + String.format("%.3f", sil)));
            }
        }
        return out;
    }

    private static long ms(long startNanos) { return (System.nanoTime() - startNanos) / 1_000_000; }
}
