package com.datascope.app.views;

import com.datascope.app.AppState;
import com.datascope.ml.*;
import com.datascope.util.*;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.chart.BarChart;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.stage.FileChooser;

import java.io.*;
import java.nio.file.Files;
import java.util.*;

/** Robust (median/MAD) anomaly scan with a threshold slider, flagged-row table and Explorer hand-off. */
public final class AnomalyView {
    private static final int TABLE_PAGE_SIZE = 500;
    private record Scan(double[] scores, boolean[] flags, int[] topFeature, int flagged, int total, double maxScore, int features,
                        List<String> topLabels, List<Double> topScores, AppState.Projection projection) {}

    private final AppState st;
    private final ScrollPane root;
    private final Slider threshold = new Slider(2.0, 8.0, 3.5);
    private final Label thresholdLabel = new Label("3.5");
    private final Label status = new Label("Run a scan to find unusual rows.");
    private final HBox kpis = new HBox(12);
    private final BarChart<String, Number> chart = Ui.barChart("Top 10 anomaly scores", 300);
    private final com.datascope.swing.DataGrid table = new com.datascope.swing.DataGrid(360);
    private final Button scan = Ui.button("Scan for anomalies");
    private final Button toExplorer = Ui.ghost("Show in Explorer");
    private final Button export = Ui.ghost("Export flagged rows…");
    private final Button previousPage = Ui.ghost("Previous");
    private final Button nextPage = Ui.ghost("Next");
    private final Label pageLabel = new Label();
    private AppState.Projection lastProjection;
    private Scan lastScan;
    private int tablePage;

    public AnomalyView(AppState st) {
        this.st = st;
        threshold.setPrefWidth(260); threshold.setBlockIncrement(0.1);
        threshold.valueProperty().addListener((o, a, b) -> thresholdLabel.setText(String.format("%.1f", Math.round(b.doubleValue() * 10) / 10.0)));
        thresholdLabel.getStyleClass().add("metric-value");
        scan.setOnAction(e -> run());
        toExplorer.setDisable(true); export.setDisable(true);
        toExplorer.setOnAction(e -> {
            if (lastProjection == null) return;
            st.setProjection(lastProjection);
            st.notify("Anomalies sent to the Explorer — red points are flagged rows.");
            st.navigate("Explorer");
        });
        export.setOnAction(e -> export());
        previousPage.setOnAction(e -> { if (tablePage > 0) { tablePage--; showHitPage(); } });
        nextPage.setOnAction(e -> { tablePage++; showHitPage(); });
        status.getStyleClass().add("muted"); status.setWrapText(true);

        HBox controls = new HBox(16, Ui.field("Sensitivity threshold (robust |z|) — lower flags more rows", new HBox(12, threshold, thresholdLabel)), scan, toExplorer, export);
        controls.setAlignment(Pos.BOTTOM_LEFT);
        HBox pageControls = new HBox(10, previousPage, pageLabel, nextPage);
        pageControls.setAlignment(Pos.CENTER_RIGHT);

        table.setEmptyText("No anomalies flagged");

        root = Ui.page("Anomaly Lab", "Finds rows that are far from typical on any numeric feature, using median/MAD so extreme values can't hide themselves.",
            Ui.card("SCAN", new VBox(16, controls, status)), kpis, Ui.card("TOP SCORES", chart),
            Ui.card("FLAGGED ROWS", new VBox(10, pageControls, table.node())));
        st.onData(this::reset);
    }

    public Node node() { return root; }

    private void reset() {
        kpis.getChildren().clear(); chart.getData().clear(); table.clear();
        toExplorer.setDisable(true); export.setDisable(true); previousPage.setDisable(true); nextPage.setDisable(true);
        lastProjection = null; lastScan = null; tablePage = 0;
        status.setText("Run a scan to find unusual rows.");
    }

    private void run() {
        if (!st.hasData()) { status.setText("Load a dataset first."); return; }
        final double thr = Math.round(threshold.getValue() * 10) / 10.0;
        var ds = st.dataset();
        List<Integer> nums = List.copyOf(st.numericIndexes());
        scan.setDisable(true); status.setText("Scanning…");
        Async.run(() -> compute(thr, ds, nums), s -> {
            scan.setDisable(false);
            if (st.dataset() != ds) { status.setText("Dataset changed before the scan completed; run the scan again."); return; }
            status.setText(s.flagged() + " of " + s.total() + " rows (" + String.format("%.1f%%", 100.0 * s.flagged() / Math.max(1, s.total()))
                + ") exceed a robust |z| of " + thr + " across " + s.features() + " numeric features.");
            kpis.getChildren().setAll(Ui.metric("FLAGGED ROWS", String.valueOf(s.flagged())), Ui.metric("SHARE OF DATA", String.format("%.1f%%", 100.0 * s.flagged() / Math.max(1, s.total()))),
                Ui.metric("HIGHEST SCORE", String.format("%.1f", s.maxScore())), Ui.metric("FEATURES SCANNED", String.valueOf(s.features())));
            chart.getData().clear();
            chart.getData().add(Ui.series("score", s.topLabels(), s.topScores()));
            lastScan = s; tablePage = 0;
            showHitPage();
            lastProjection = s.projection();
            toExplorer.setDisable(lastProjection == null); export.setDisable(s.flagged() == 0);
        }, err -> { scan.setDisable(false); status.setText("Scan failed: " + err.getMessage()); });
    }

    private Scan compute(double thr, com.datascope.model.DataSet ds, List<Integer> nums) {
        if (nums.isEmpty()) throw new IllegalStateException("There are no numeric columns to scan.");
        double[][] z = Stats.standardizeInPlace(AppState.matrix(ds, nums, ds.rowCount()));
        AnomalyDetector.Result r = AnomalyDetector.zScore(z, thr);

        int flagged = 0;
        PriorityQueue<Integer> best = new PriorityQueue<>(Comparator.comparingDouble(i -> r.scores()[i]));
        for (int i = 0; i < z.length; i++) {
            if (r.anomaly()[i]) flagged++;
            if (best.size() < 10) best.add(i);
            else if (r.scores()[i] > r.scores()[best.peek()]) { best.remove(); best.add(i); }
        }
        List<Integer> order = best.stream().sorted((a, b) -> Double.compare(r.scores()[b], r.scores()[a])).toList();
        List<String> labels = new ArrayList<>(); List<Double> scores = new ArrayList<>();
        for (int i : order) { labels.add("#" + (i + 1)); scores.add(r.scores()[i]); }

        int[] selectedRows = new int[z.length], lab = new int[z.length];
        for (int i = 0; i < z.length; i++) {
            selectedRows[i] = i;
            lab[i] = r.anomaly()[i] ? 1 : 0;
        }
        PCA.SampledResult pr = PCA.fitTransformStandardizedRows(z, 3, selectedRows);
        List<AppState.Projection.ChartSpec> charts = List.of(
            AppState.Projection.ChartSpec.bar("Top 10 anomaly scores", labels, scores),
            AppState.Projection.ChartSpec.bar("Score distribution", scoreBins(), scoreCounts(r.scores())));
        AppState.Projection proj = new AppState.Projection(pr.points(), lab, pr.rows(), new String[]{"Normal", "Anomaly"},
            new Color[]{Color.web("#43d8ff"), Color.web("#ff4d6d")}, "Anomalies (red) on PCA axes", "Anomaly scan", null, charts);
        return new Scan(r.scores(), r.anomaly(), r.topFeature(), flagged, z.length,
            order.isEmpty() ? 0 : r.scores()[order.getFirst()], nums.size(), labels, scores, proj);
    }

    private void showHitPage() {
        if (lastScan == null) { table.setData(List.of("Row #", "Score", "Main driver", "Row values"), List.of()); return; }
        int pages = lastScan.flagged() == 0 ? 0 : (lastScan.flagged() - 1) / TABLE_PAGE_SIZE + 1;
        tablePage = pages == 0 ? 0 : Math.max(0, Math.min(tablePage, pages - 1));
        int skip = tablePage * TABLE_PAGE_SIZE, added = 0;
        List<List<String>> rows = new ArrayList<>();
        var ds = st.dataset();
        List<Integer> nums = st.numericIndexes();
        for (int i = 0, seen = 0; i < lastScan.flags().length && added < TABLE_PAGE_SIZE; i++) {
            if (!lastScan.flags()[i]) continue;
            if (seen++ < skip) continue;
            String driver = ds.columns().get(nums.get(lastScan.topFeature()[i]));
            rows.add(Arrays.asList(String.valueOf(i + 1), String.format("%.2f", lastScan.scores()[i]),
                driver, String.join(" | ", ds.row(i))));
            added++;
        }
        table.setData(List.of("Row #", "Score", "Main driver", "Row values"), rows);
        previousPage.setDisable(tablePage == 0);
        nextPage.setDisable(tablePage + 1 >= pages);
        pageLabel.setText("Page " + (pages == 0 ? 0 : tablePage + 1) + " of " + pages);
    }

    private static List<String> scoreBins() {
        List<String> out = new ArrayList<>();
        for (int b = 0; b < 8; b++) out.add(String.valueOf(b));
        return out;
    }

    private static List<Double> scoreCounts(double[] scores) {
        double[] counts = new double[8];
        for (double s : scores) counts[Math.max(0, Math.min(7, (int) s))]++;
        List<Double> out = new ArrayList<>(); for (double c : counts) out.add(c);
        return out;
    }

    private void export() {
        FileChooser fc = new FileChooser(); fc.setInitialFileName("flagged_rows.csv");
        File f = fc.showSaveDialog(root.getScene().getWindow());
        if (f == null) return;
        Scan result = lastScan;
        var ds = st.dataset();
        List<Integer> nums = List.copyOf(st.numericIndexes());
        export.setDisable(true); status.setText("Exporting all flagged rows…");
        Async.run(() -> {
            try (BufferedWriter w = Files.newBufferedWriter(f.toPath())) {
                List<String> head = new ArrayList<>(); head.add("row"); head.add("score"); head.add("driver"); head.addAll(ds.columns());
                w.write(CleanView.csvLine(head)); w.newLine();
                for (int i = 0; i < result.flags().length; i++) {
                    if (!result.flags()[i]) continue;
                    List<String> line = new ArrayList<>(); line.add(String.valueOf(i + 1));
                    line.add(String.format("%.3f", result.scores()[i]));
                    line.add(ds.columns().get(nums.get(result.topFeature()[i])));
                    line.addAll(ds.row(i));
                    w.write(CleanView.csvLine(line)); w.newLine();
                }
            }
            return result.flagged();
        }, count -> {
            export.setDisable(false);
            status.setText("Exported " + count + " flagged rows to " + f.getName());
            st.notify("Exported " + count + " flagged rows to " + f.getName());
        }, err -> { export.setDisable(false); status.setText("Export failed: " + err.getMessage()); });
    }
}
