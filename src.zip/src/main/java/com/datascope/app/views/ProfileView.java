package com.datascope.app.views;

import com.datascope.app.AppState;
import com.datascope.ml.Stats;
import com.datascope.model.*;
import com.datascope.util.Async;
import com.datascope.util.Ui;
import javafx.scene.Node;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.application.Platform;

import java.util.*;
import java.util.stream.Collectors;
import java.util.concurrent.atomic.AtomicLong;

/** Column-by-column schema table with a distribution panel for the selected column. */
public final class ProfileView {
    private record NumericDetail(double mean, double median, double stdDev, double skew,
                                 double min, double max, List<String> labels, List<Integer> counts) {}
    private final AppState st;
    private final ScrollPane root;
    private static final List<String> HEADS = List.of(
        "Column", "Type", "Missing", "Missing %", "Unique", "Mean", "Min", "Max", "Std Dev", "Sample");

    private final com.datascope.swing.DataGrid grid = new com.datascope.swing.DataGrid(350);
    private final VBox detail = new VBox(16);
    private final AtomicLong detailRevision = new AtomicLong();

    public ProfileView(AppState st) {
        this.st = st;
        grid.setEmptyText("Load a dataset to see its schema");
        grid.setOnRowSelected(i -> {
            List<ColumnProfile> ps = st.profiles();
            if (i >= 0 && i < ps.size()) showDetail(ps.get(i));
        });
        root = Ui.page("Profile", "Schema, data types and distributions. Select a column to inspect it.",
            Ui.card("SCHEMA & DATA QUALITY", grid.node()), Ui.card("COLUMN DETAIL", detail));
        st.onData(this::refresh);
        refresh();
    }

    public Node node() { return root; }

    private static String cell(ColumnProfile p, int k) {
        return switch (k) {
            case 0 -> p.name();
            case 1 -> p.type().name();
            case 2 -> String.valueOf(p.missing());
            case 3 -> String.format("%.1f%%", p.missingPct() * 100);
            case 4 -> String.valueOf(p.unique());
            case 5 -> Ui.fmt(p.mean());
            case 6 -> Ui.fmt(p.min());
            case 7 -> Ui.fmt(p.max());
            case 8 -> p.type() == ColumnType.NUMERIC ? Ui.fmt(p.stdDev()) : "—";
            default -> p.sample();
        };
    }

    private void refresh() {
        List<ColumnProfile> ps = st.profiles();
        List<List<String>> rows = new ArrayList<>();
        for (ColumnProfile p : ps) {
            List<String> r = new ArrayList<>();
            for (int k = 0; k < HEADS.size(); k++) r.add(cell(p, k));
            rows.add(r);
        }
        grid.setData(HEADS, rows);
        if (!ps.isEmpty()) { grid.selectRow(0); showDetail(ps.get(0)); } else showDetail(null);
    }

    private void showDetail(ColumnProfile p) {
        long revision = detailRevision.incrementAndGet();
        Platform.runLater(() -> {
            if (detailRevision.get() == revision)
                detail.getChildren().setAll(Ui.muted(p == null ? "Load a dataset to see column details." : "Calculating full-column details…"));
        });
        if (p == null) return;
        DataSet ds = st.dataset();
        int idx = st.dataset().columns().indexOf(p.name());
        if (idx < 0) return;

        if (p.type() == ColumnType.NUMERIC) {
            Async.run(() -> numericDetail(ds, idx, p), result -> {
                if (!isCurrentDetail(revision, ds)) return;
                if (result.labels().isEmpty()) { detail.getChildren().setAll(Ui.emptyState("No numeric values.")); return; }
                detail.getChildren().setAll(
                    Ui.metricRow(Ui.metric("MEAN", Ui.fmt(result.mean())), Ui.metric("MEDIAN", Ui.fmt(result.median())),
                        Ui.metric("STD DEV", Ui.fmt(result.stdDev())), Ui.metric("SKEW", String.format("%.2f", result.skew())),
                        Ui.metric("MIN", Ui.fmt(result.min())), Ui.metric("MAX", Ui.fmt(result.max()))),
                    histogram(p.name(), result.labels(), result.counts()));
            }, err -> {
                if (isCurrentDetail(revision, ds)) detail.getChildren().setAll(Ui.emptyState("Column analysis failed: " + err.getMessage()));
            });
        } else {
            Async.run(() -> {
                Map<String, Long> counts = new HashMap<>();
                for (int r = 0; r < ds.rowCount(); r++) {
                    String value = ds.value(r, idx).trim();
                    if (!value.isEmpty()) counts.merge(value, 1L, Long::sum);
                }
                return counts.entrySet().stream().sorted(Map.Entry.<String, Long>comparingByValue().reversed())
                    .limit(12).collect(Collectors.toList());
            }, top -> {
                if (!isCurrentDetail(revision, ds)) return;
                BarChart<String, Number> chart = Ui.barChart("Top values — " + p.name(), 300);
                chart.getData().add(Ui.series("count", top.stream().map(Map.Entry::getKey).toList(), top.stream().map(Map.Entry::getValue).toList()));
                detail.getChildren().setAll(Ui.metricRow(Ui.metric("DISTINCT", String.valueOf(p.unique())), Ui.metric("MISSING", String.valueOf(p.missing())),
                    Ui.metric("MOST COMMON", top.isEmpty() ? "—" : top.get(0).getKey())), chart);
            }, err -> {
                if (isCurrentDetail(revision, ds)) detail.getChildren().setAll(Ui.emptyState("Column analysis failed: " + err.getMessage()));
            });
        }
    }

    private boolean isCurrentDetail(long revision, DataSet ds) {
        return detailRevision.get() == revision && st.dataset() == ds;
    }

    private static NumericDetail numericDetail(DataSet ds, int idx, ColumnProfile profile) {
        double[] values = ds.numericColumn(idx);
        double[] finite = Arrays.stream(values).filter(Double::isFinite).toArray();
        if (finite.length == 0) return new NumericDetail(0, 0, 0, 0, 0, 0, List.of(), List.of());
        int bins = Math.max(6, Math.min(20, (int) Math.round(Math.sqrt(finite.length))));
        double lo = profile.min(), hi = profile.max();
        if (hi - lo < 1e-12) hi = lo + 1;
        double width = (hi - lo) / bins;
        int[] counts = new int[bins];
        for (double value : finite) counts[Math.min(bins - 1, (int) ((value - lo) / width))]++;
        List<String> labels = new ArrayList<>(); List<Integer> valuesByBin = new ArrayList<>();
        for (int i = 0; i < bins; i++) { labels.add(Ui.fmt(lo + i * width)); valuesByBin.add(counts[i]); }
        return new NumericDetail(Stats.mean(finite), Stats.median(finite), Stats.std(finite),
            Stats.skewness(finite), profile.min(), profile.max(), labels, valuesByBin);
    }

    private BarChart<String, Number> histogram(String name, List<String> labels, List<Integer> counts) {
        BarChart<String, Number> chart = Ui.barChart("Distribution — " + name, 300);
        chart.setCategoryGap(1);
        chart.getData().add(Ui.series("count", labels, counts));
        return chart;
    }
}
