package com.datascope.app.views;

import com.datascope.analysis.Insights;
import com.datascope.app.AppState;
import com.datascope.model.DataSet;
import com.datascope.model.ColumnProfile;
import com.datascope.util.Async;
import com.datascope.util.Ui;
import javafx.geometry.Insets;
import javafx.geometry.VPos;
import javafx.scene.Node;
import javafx.scene.canvas.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.text.*;

import java.util.List;
import java.util.concurrent.atomic.AtomicLong;

/** Automatic findings plus a correlation heatmap. */
public final class InsightsView {
    private record Analysis(List<Insights.Insight> findings, Insights.Correlation correlation) {}
    private final AppState st;
    private final ScrollPane root;
    private final VBox findings = new VBox(8);
    private final StackPane heat = new StackPane();
    private final AtomicLong revision = new AtomicLong();

    public InsightsView(AppState st) {
        this.st = st;
        root = Ui.page("Insights", "Automatic findings about quality, skew, redundancy and balance — plus how numeric columns relate. Hover any heatmap cell for the exact r.",
            Ui.card("FINDINGS", findings), Ui.card("CORRELATION HEATMAP  (Pearson r)", Ui.scroll(heat)));
        st.onData(this::refresh);
        refresh();
    }

    public Node node() { return root; }

    private void refresh() {
        long currentRevision = revision.incrementAndGet();
        findings.getChildren().clear(); heat.getChildren().clear();
        if (!st.hasData()) { findings.getChildren().add(Ui.emptyState("Load a dataset to generate insights.")); return; }
        DataSet ds = st.dataset();
        List<ColumnProfile> profiles = st.profiles();
        findings.getChildren().setAll(Ui.muted("Analyzing every row in the background…"));
        heat.getChildren().setAll(Ui.muted("Calculating correlations…"));
        Async.run(() -> new Analysis(Insights.generate(ds, profiles), Insights.correlation(ds, profiles)), result -> {
            if (revision.get() != currentRevision || st.dataset() != ds) return;
            showFindings(result.findings());
            showHeatmap(result.correlation());
        }, err -> {
            if (revision.get() != currentRevision) return;
            findings.getChildren().setAll(Ui.emptyState("Insight analysis failed: " + err.getMessage()));
            heat.getChildren().setAll(Ui.emptyState("Correlation analysis failed: " + err.getMessage()));
        });
    }

    private void showFindings(List<Insights.Insight> insights) {
        findings.getChildren().clear();
        for (Insights.Insight in : insights) {
            Label tag = new Label(switch (in.level()) { case WARN -> "ATTENTION"; case GOOD -> "ALL GOOD"; case INFO -> "NOTE"; });
            tag.getStyleClass().addAll("tag", "tag-" + in.level().name().toLowerCase());
            tag.setMinWidth(82);
            Label title = new Label(in.title()); title.getStyleClass().add("finding-title");
            Label detail = Ui.muted(in.detail());
            VBox text = new VBox(2, title, detail); HBox.setHgrow(text, Priority.ALWAYS);
            HBox row = new HBox(12, tag, text); row.getStyleClass().add("finding");
            findings.getChildren().add(row);
        }
    }

    private void showHeatmap(Insights.Correlation c) {
        heat.getChildren().clear();
        if (c.names().size() < 2) { heat.getChildren().add(Ui.emptyState("Need at least two numeric columns for a correlation matrix.")); return; }
        heat.getChildren().add(drawHeatmap(c));
    }

    private Node drawHeatmap(Insights.Correlation c) {
        int n = c.names().size(), cell = 62, left = 120, top = 110;
        Canvas canvas = new Canvas(left + n * cell + 20, top + n * cell + 20);
        GraphicsContext g = canvas.getGraphicsContext2D();
        Tooltip tip = new Tooltip("Hover a cell to read its Pearson r.");
        Tooltip.install(canvas, tip);
        canvas.setOnMouseMoved(e -> {
            int col = (int) ((e.getX() - left) / cell), row = (int) ((e.getY() - top) / cell);
            if (row >= 0 && row < n && col >= 0 && col < n) {
                double r = c.matrix()[row][col];
                String strength = Math.abs(r) >= 0.7 ? "strong" : Math.abs(r) >= 0.4 ? "moderate" : Math.abs(r) >= 0.2 ? "weak" : "negligible";
                tip.setText(c.names().get(row) + "  ×  " + c.names().get(col) + "\nr = " + String.format("%.2f", r)
                    + "  (" + strength + " " + (r >= 0 ? "positive" : "negative") + ")");
            } else tip.setText("Hover a cell to read its Pearson r.");
        });
        canvas.setOnMouseExited(e -> tip.setText("Hover a cell to read its Pearson r."));
        g.setFont(Font.font("System", 11));
        Color neutral = Color.web("#101824"), pos = Color.web("#43d8ff"), neg = Color.web("#ff7a45");
        for (int i = 0; i < n; i++) {
            g.setFill(Color.web("#9bacc0")); g.setTextAlign(TextAlignment.RIGHT); g.setTextBaseline(VPos.CENTER);
            g.fillText(c.names().get(i), left - 10, top + i * cell + cell / 2.0);
            g.save(); g.translate(left + i * cell + cell / 2.0 + 4, top - 10); g.rotate(-45);
            g.setTextAlign(TextAlignment.LEFT); g.fillText(c.names().get(i), 0, 0); g.restore();
            for (int j = 0; j < n; j++) {
                double r = c.matrix()[i][j];
                g.setFill(neutral.interpolate(r >= 0 ? pos : neg, Math.min(1, Math.abs(r))));
                g.fillRoundRect(left + j * cell + 1, top + i * cell + 1, cell - 2, cell - 2, 8, 8);
                g.setFill(Math.abs(r) > 0.55 ? Color.web("#06121c") : Color.web("#dce8f5"));
                g.setTextAlign(TextAlignment.CENTER); g.setTextBaseline(VPos.CENTER);
                g.fillText(String.format("%.2f", r), left + j * cell + cell / 2.0, top + i * cell + cell / 2.0);
            }
        }
        return canvas;
    }
}
