package com.datascope.app.views;

import com.datascope.app.AppState;
import com.datascope.app.AppState.Projection;
import com.datascope.app.AppState.Projection.ChartSpec;
import com.datascope.ml.*;
import com.datascope.model.ColumnType;
import com.datascope.util.*;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;

import java.util.*;
import java.util.function.Supplier;

/**
 * K-Means, PCA, logistic and linear regression with proper train/test evaluation.
 * Heavy maths runs on a worker thread and returns plain data; JavaFX nodes are only built on the FX thread.
 * Every technique also publishes a projection to the Explorer so its result can be inspected visually.
 */
public final class MlView {
    private static final String KMEANS = "K-Means clustering", PCA_ = "PCA projection",
        LOGIT = "Logistic regression (binary target)", LINEAR = "Linear regression (numeric target)";
    private static final int ELBOW_SAMPLE_ROWS = 5000;

    /** Worker-thread result: summary text, optional point cloud, and a supplier that builds nodes on the FX thread. */
    private static final class Panel {
        String summary; Supplier<List<Node>> ui; Projection projection;
    }

    private final AppState st;
    private final ScrollPane root;
    private final ComboBox<String> method = new ComboBox<>(FXCollections.observableArrayList(KMEANS, PCA_, LOGIT, LINEAR));
    private final ComboBox<String> target = new ComboBox<>();
    private final ComboBox<Integer> k = new ComboBox<>(FXCollections.observableArrayList(2, 3, 4, 5, 6, 7, 8));
    private final Node targetField, kField;
    private final Label status = new Label("Pick a technique and run an experiment.");
    private final Button run = Ui.button("Run experiment");
    private final Button openExplorer = Ui.ghost("Open in Explorer");
    private final VBox output = new VBox(14);

    public MlView(AppState st) {
        this.st = st;
        method.getSelectionModel().selectFirst(); k.setValue(4); method.setPrefWidth(290); target.setPrefWidth(180);
        targetField = Ui.field("Target column", target); kField = Ui.field("Clusters (k)", k);
        method.valueProperty().addListener((o, a, b) -> syncControls());
        run.setOnAction(e -> execute());
        openExplorer.setDisable(true);
        openExplorer.setOnAction(e -> { st.navigate("Explorer"); st.notify("Opening the latest experiment in the Explorer."); });
        status.getStyleClass().add("muted"); status.setWrapText(true);
        HBox controls = new HBox(14, Ui.field("Technique", method), kField, targetField, run, openExplorer);
        controls.setAlignment(Pos.BOTTOM_LEFT);
        root = Ui.page("ML Studio", "Unsupervised and supervised models implemented from scratch. Supervised models are scored on a held-out 20% test set. "
            + "Every run publishes a point cloud to the Explorer.",
            Ui.card("EXPERIMENT", new VBox(10, controls, status)), output);
        st.onData(this::refresh);
        refresh();
    }

    public Node node() { return root; }

    private void refresh() {
        String prev = target.getValue();
        target.setItems(FXCollections.observableArrayList(st.dataset().columns()));
        if (prev != null && target.getItems().contains(prev)) target.setValue(prev);
        else if (target.getItems().contains("Churn")) target.setValue("Churn");
        else if (!target.getItems().isEmpty()) target.getSelectionModel().selectLast();
        output.getChildren().clear();
        openExplorer.setDisable(true);
        syncControls();
    }

    private void syncControls() {
        String m = method.getValue();
        boolean sup = LOGIT.equals(m) || LINEAR.equals(m), km = KMEANS.equals(m);
        targetField.setVisible(sup); targetField.setManaged(sup);
        kField.setVisible(km); kField.setManaged(km);
    }

    private void execute() {
        if (!st.hasData()) { status.setText("Load a dataset first."); return; }
        final String m = method.getValue(), tgt = target.getValue();
        final int kk = k.getValue() == null ? 4 : k.getValue();
        List<Integer> nums = new ArrayList<>(st.numericIndexes());
        boolean supervised = LOGIT.equals(m) || LINEAR.equals(m);
        if (supervised) {
            if (tgt == null) { status.setText("Choose a target column."); return; }
            nums.remove(Integer.valueOf(st.dataset().columns().indexOf(tgt))); // never train on the target itself
        }
        if (nums.isEmpty() || st.dataset().rowCount() < 10) { status.setText("Need at least 10 rows and one numeric feature column."); return; }
        final List<Integer> feats = nums;
        run.setDisable(true); status.setText("Running…");
        Async.run(() -> {
            if (KMEANS.equals(m)) return kmeans(feats, kk);
            if (PCA_.equals(m)) return pca(feats);
            if (LOGIT.equals(m)) return logistic(feats, tgt);
            return linear(feats, tgt);
        }, panel -> {
            run.setDisable(false); status.setText(panel.summary);
            output.getChildren().setAll(panel.ui == null ? List.<Node>of() : panel.ui.get());
            if (panel.projection != null) { st.setProjection(panel.projection); openExplorer.setDisable(false); }
            else openExplorer.setDisable(true);
        }, err -> { run.setDisable(false); status.setText("Experiment failed: " + err.getMessage()); });
    }

    // ---- K-Means -----------------------------------------------------------
    private Panel kmeans(List<Integer> feats, int kk) {
        final double[][] z = Stats.standardizeInPlace(st.matrix(feats, st.dataset().rowCount()));
        final KMeans.Result r = KMeans.fit(z, kk, 100, new Random(7));
        final int kUsed = r.centroids().length, p = feats.size();
        final double sil = Metrics.silhouette(z, r.labels(), kUsed, 1500);

        final List<String> ks = new ArrayList<>(); final List<Double> inertia = new ArrayList<>();
        double[][] elbowSample = sampleRows(z, Math.min(ELBOW_SAMPLE_ROWS, z.length));
        for (int c = 2; c <= 8; c++) { ks.add(String.valueOf(c)); inertia.add(KMeans.fit(elbowSample, c, 60, new Random(7)).inertia()); }

        final int[] counts = new int[kUsed]; final double[][] sum = new double[kUsed][p];
        for (int label : r.labels()) counts[label]++;
        for (int j = 0; j < p; j++) {
            double[] column = st.dataset().numericColumn(feats.get(j));
            double mean = Stats.mean(column);
            for (int i = 0; i < column.length; i++) {
                int group = r.labels()[i];
                sum[group][j] += Double.isFinite(column[i]) ? column[i] : mean;
            }
        }
        final List<String> names = new ArrayList<>(); final List<Integer> sizes = new ArrayList<>();
        for (int c = 0; c < kUsed; c++) { names.add("Cluster " + (c + 1)); sizes.add(counts[c]); }
        final List<String> featNames = new ArrayList<>();
        for (int f : feats) featNames.add(st.dataset().columns().get(f));

        PCA.SampledResult proj = PCA.fitTransformStandardizedSampled(z, 3, z.length);
        int n = proj.points().length;
        String[] legend = new String[kUsed]; for (int c = 0; c < kUsed; c++) legend[c] = "Cluster " + (c + 1);
        int[] labels = new int[n];
        for (int i = 0; i < n; i++) {
            int source = proj.rows()[i];
            labels[i] = r.labels()[source];
        }
        List<ChartSpec> charts = List.of(
            ChartSpec.bar("Cluster sizes", names, sizes.stream().map(Integer::doubleValue).toList()),
            ChartSpec.line("Elbow curve — inertia vs k", ks, inertia));

        Panel out = new Panel();
        out.summary = "K-Means finished: k=" + kUsed + ", " + r.iterations() + " iterations, silhouette " + String.format("%.2f", sil)
            + (sil >= 0.5 ? " (clear structure)." : sil >= 0.25 ? " (moderate structure)." : " (weak structure).");
        out.projection = Projection.of(proj.points(), labels, proj.rows(), legend, null,
            "K-Means (k=" + kUsed + ") on PCA axes", "K-Means", null, charts);
        out.ui = () -> {
            List<Node> nodes = new ArrayList<>();
            nodes.add(Ui.metricRow(Ui.metric("CLUSTERS", String.valueOf(kUsed)), Ui.metric("SILHOUETTE", String.format("%.3f", sil)),
                Ui.metric("INERTIA", Ui.fmt(r.inertia())), Ui.metric("ITERATIONS", String.valueOf(r.iterations())), Ui.metric("ROWS USED", String.valueOf(z.length))));
            BarChart<String, Number> sizeChart = Ui.barChart("Cluster sizes", 280);
            sizeChart.getData().add(Ui.series("rows", names, sizes));
            LineChart<String, Number> elbow = Ui.lineChart("Elbow curve (inertia vs k; representative sample)", 280);
            elbow.getData().add(Ui.series("inertia", ks, inertia));
            VBox c1 = Ui.card("SIZES", sizeChart), c2 = Ui.card("CHOOSING K", elbow);
            HBox.setHgrow(c1, Priority.ALWAYS); HBox.setHgrow(c2, Priority.ALWAYS);
            nodes.add(new HBox(14, c1, c2));

            List<String[]> rowsOut = new ArrayList<>();
            for (int c = 0; c < kUsed; c++) {
                String[] row = new String[p + 1]; row[0] = "Cluster " + (c + 1) + " (" + counts[c] + ")";
                for (int j = 0; j < p; j++) row[j + 1] = counts[c] == 0 ? "—" : Ui.fmt(sum[c][j] / counts[c]);
                rowsOut.add(row);
            }
            List<String> heads = new ArrayList<>(); heads.add("Cluster"); heads.addAll(featNames);
            nodes.add(Ui.card("CLUSTER PROFILES  (mean of each feature)", stringTable(heads, rowsOut)));
            return nodes;
        };
        return out;
    }

    // ---- PCA ---------------------------------------------------------------
    private Panel pca(List<Integer> feats) {
        final double[][] raw = Stats.standardizeInPlace(st.matrix(feats, st.dataset().rowCount()));
        final PCA.SampledResult r = PCA.fitTransformStandardizedSampled(raw, 3, raw.length);
        final int p = feats.size(), d = r.eigenvalues().length;
        final List<String> names = new ArrayList<>(); final List<Double> ratio = new ArrayList<>(), cumulative = new ArrayList<>();
        double total = 0, running = 0;
        for (int i = 0; i < d; i++) { names.add("PC" + (i + 1)); double e = r.eigenvalues()[i] / p * 100; ratio.add(e); total += e; running += e; cumulative.add(running); }
        final double cum = total;
        final List<String[]> rows = new ArrayList<>();
        for (int j = 0; j < p; j++) {
            String[] row = new String[d + 1]; row[0] = st.dataset().columns().get(feats.get(j));
            for (int i = 0; i < d; i++) row[i + 1] = String.format("%+.3f", r.components()[i][j]);
            rows.add(row);
        }
        final List<String> heads = new ArrayList<>(); heads.add("Feature"); heads.addAll(names);
        int n = r.points().length;
        int[] labels = new int[n];
        List<ChartSpec> charts = List.of(
            ChartSpec.bar("Explained variance by component (%)", names, ratio),
            ChartSpec.line("Cumulative variance retained (%)", names, cumulative));

        Panel out = new Panel();
        out.summary = "PCA: the first " + d + " components retain " + String.format("%.1f%%", cum) + " of the variance across " + p + " numeric features.";
        out.projection = Projection.of(r.points(), labels, r.rows(), new String[]{"Rows"}, null,
            "PCA projection", "PCA", null, charts);
        out.ui = () -> {
            List<Node> nodes = new ArrayList<>();
            nodes.add(Ui.metricRow(Ui.metric("COMPONENTS", String.valueOf(d)), Ui.metric("VARIANCE RETAINED", String.format("%.1f%%", cum)),
                Ui.metric("FEATURES", String.valueOf(p)), Ui.metric("ROWS USED", String.valueOf(raw.length))));
            BarChart<String, Number> scree = Ui.barChart("Explained variance by component (%)", 280);
            scree.getData().add(Ui.series("variance %", names, ratio));
            nodes.add(Ui.card("SCREE PLOT", scree));
            nodes.add(Ui.card("LOADINGS  (which features drive each component)", stringTable(heads, rows)));
            return nodes;
        };
        return out;
    }

    // ---- Logistic ----------------------------------------------------------
    private Panel logistic(List<Integer> feats, String tgt) {
        int t = st.dataset().columns().indexOf(tgt);
        Map<String, Integer> counts = new LinkedHashMap<>();
        for (int i = 0; i < st.dataset().rowCount(); i++) { String v = st.dataset().value(i, t).trim(); if (!v.isEmpty()) counts.merge(v, 1, Integer::sum); }
        Panel out = new Panel();
        if (counts.size() != 2) { out.summary = "'" + tgt + "' has " + counts.size() + " distinct values; logistic regression needs exactly 2 (e.g. Yes/No)."; return out; }
        final String positive = counts.keySet().stream().filter(v -> v.equalsIgnoreCase("yes") || v.equalsIgnoreCase("true") || v.equals("1")).findFirst()
            .orElseGet(() -> counts.entrySet().stream().min(Map.Entry.comparingByValue()).get().getKey());
        int n = st.dataset().rowCount();
        int[] y = new int[n];
        for (int i = 0; i < n; i++) y[i] = st.dataset().value(i, t).trim().equals(positive) ? 1 : 0;
        double[][] z = Stats.standardizeInPlace(st.matrix(feats, st.dataset().rowCount()));
        Metrics.Split sp = Metrics.split(n, 0.2, new Random(7));
        boolean hasPositive = false, hasNegative = false;
        for (int row : sp.train()) { if (y[row] == 1) hasPositive = true; else hasNegative = true; }
        if (!hasPositive || !hasNegative) { out.summary = "The training split contains only one class."; return out; }
        final LogisticRegression.Result r = LogisticRegression.fitSelected(z, y, sp.train(), trainingEpochs(sp.train().length), 0.2);
        int tp = 0, fp = 0, tn = 0, fn = 0, pos = 0;
        for (int row : sp.test()) {
            int prediction = LogisticRegression.predict(z[row], r.weights(), r.intercept());
            if (y[row] == 1) { pos++; if (prediction == 1) tp++; else fn++; }
            else if (prediction == 1) fp++; else tn++;
        }
        final Metrics.Confusion cf = new Metrics.Confusion(tp, fp, tn, fn);
        final double base = Math.max(pos, sp.test().length - pos) / (double) sp.test().length;
        final List<String> wNames = new ArrayList<>(); final List<Double> wVals = new ArrayList<>();
        topWeights(feats, r.weights(), wNames, wVals);

        // Projection: PCA of the features, coloured by predicted class.
        PCA.SampledResult pr = PCA.fitTransformStandardizedSampled(z, 3, z.length);
        int pn = pr.points().length;
        int[] labels = new int[pn];
        double[] probs = new double[pn];
        for (int i = 0; i < pn; i++) {
            int source = pr.rows()[i];
            double prob = LogisticRegression.probability(z[source], r.weights(), r.intercept());
            probs[i] = prob; labels[i] = prob >= 0.5 ? 1 : 0;
        }
        List<ChartSpec> charts = List.of(
            hist("Predicted P(" + positive + ") distribution", probs, 10, 0, 1),
            ChartSpec.bar("Actual class balance", List.of(positive, "other"),
                List.of((double) counts.getOrDefault(positive, 0), (double) counts.entrySet().stream().filter(e -> !e.getKey().equals(positive)).mapToInt(Map.Entry::getValue).sum())));

        out.summary = "Predicting '" + tgt + " = " + positive + "': test accuracy " + String.format("%.1f%%", cf.accuracy() * 100)
            + " versus " + String.format("%.1f%%", base * 100) + " for always guessing the majority class.";
        out.projection = Projection.of(pr.points(), labels, pr.rows(),
            new String[]{"Predicted other", "Predicted " + positive},
            new Color[]{Color.web("#6aa8ff"), Color.web("#7cf29c")},
            "Logistic regression — predicted class on PCA axes", "Logistic regression", null, charts);
        out.ui = () -> {
            List<Node> nodes = new ArrayList<>();
            nodes.add(Ui.metricRow(Ui.metric("TEST ACCURACY", String.format("%.1f%%", cf.accuracy() * 100)), Ui.metric("BASELINE", String.format("%.1f%%", base * 100)),
                Ui.metric("PRECISION", String.format("%.2f", cf.precision())), Ui.metric("RECALL", String.format("%.2f", cf.recall())), Ui.metric("F1", String.format("%.2f", cf.f1()))));
            GridPane grid = new GridPane(); grid.setHgap(8); grid.setVgap(8);
            grid.add(new Label(""), 0, 0); grid.add(Ui.chip("Predicted " + positive), 1, 0); grid.add(Ui.chip("Predicted other"), 2, 0);
            grid.add(Ui.chip("Actual " + positive), 0, 1); grid.add(Ui.metric("TRUE POSITIVE", String.valueOf(cf.tp())), 1, 1); grid.add(Ui.metric("FALSE NEGATIVE", String.valueOf(cf.fn())), 2, 1);
            grid.add(Ui.chip("Actual other"), 0, 2); grid.add(Ui.metric("FALSE POSITIVE", String.valueOf(cf.fp())), 1, 2); grid.add(Ui.metric("TRUE NEGATIVE", String.valueOf(cf.tn())), 2, 2);
            BarChart<String, Number> w = Ui.barChart("Standardised weights — positive pushes toward '" + positive + "'", 300);
            w.getData().add(Ui.series("weight", wNames, wVals));
            VBox c1 = Ui.card("CONFUSION MATRIX  (test set, " + sp.test().length + " rows)", grid), c2 = Ui.card("WHAT DRIVES THE PREDICTION", w);
            HBox.setHgrow(c2, Priority.ALWAYS);
            nodes.add(new HBox(14, c1, c2));
            return nodes;
        };
        return out;
    }

    // ---- Linear ------------------------------------------------------------
    private Panel linear(List<Integer> feats, String tgt) {
        int t = st.dataset().columns().indexOf(tgt);
        Panel out = new Panel();
        if (st.profiles().get(t).type() != ColumnType.NUMERIC) { out.summary = "'" + tgt + "' is not numeric; choose a numeric target for linear regression."; return out; }
        double[] yAll = st.dataset().numericColumn(t);
        double[][] zAll = Stats.standardizeInPlace(st.matrix(feats, st.dataset().rowCount()));
        int[] validRows = new int[zAll.length]; int validCount = 0;
        for (int i = 0; i < yAll.length; i++) if (Double.isFinite(yAll[i])) validRows[validCount++] = i;
        if (validCount < 10) { out.summary = "Not enough rows with a numeric target."; return out; }
        validRows = Arrays.copyOf(validRows, validCount);
        Metrics.Split sp = Metrics.split(validCount, 0.2, new Random(7));
        int[] trainRows = mapRows(validRows, sp.train()), testRows = mapRows(validRows, sp.test());
        final LinearRegression.Result r = LinearRegression.fitSelected(zAll, yAll, trainRows, trainingEpochs(trainRows.length));
        double testMean = 0;
        for (int row : testRows) testMean += yAll[row];
        testMean /= testRows.length;
        double total = 0, residualSum = 0;
        double[] resid = new double[testRows.length];
        for (int i = 0; i < testRows.length; i++) {
            int row = testRows[i];
            double prediction = predict(zAll[row], r.weights(), r.intercept());
            resid[i] = yAll[row] - prediction;
            residualSum += resid[i] * resid[i];
            total += (yAll[row] - testMean) * (yAll[row] - testMean);
        }
        final double r2 = total == 0 ? 0 : 1 - residualSum / total;
        final double rmse = Math.sqrt(residualSum / testRows.length);
        final int testRowsCount = testRows.length;
        final List<String> wNames = new ArrayList<>(); final List<Double> wVals = new ArrayList<>();
        topWeights(feats, r.weights(), wNames, wVals);

        // Projection: PCA of the features, coloured by predicted-value quartile.
        PCA.SampledResult pr = PCA.fitTransformStandardizedSampled(zAll, 3, zAll.length);
        int pn = pr.points().length;
        double[] predAll = new double[pn];
        for (int i = 0; i < pn; i++) {
            int source = pr.rows()[i];
            double v = r.intercept();
            for (int j = 0; j < zAll[source].length; j++) v += r.weights()[j] * zAll[source][j];
            predAll[i] = v;
        }
        double[] sorted = predAll.clone(); Arrays.sort(sorted);
        double q1 = sorted[(int) (sorted.length * 0.25)], q2 = sorted[(int) (sorted.length * 0.50)], q3 = sorted[(int) (sorted.length * 0.75)];
        int[] labels = new int[pn];
        for (int i = 0; i < pn; i++) {
            labels[i] = predAll[i] <= q1 ? 0 : predAll[i] <= q2 ? 1 : predAll[i] <= q3 ? 2 : 3;
        }
        double rlo = Arrays.stream(resid).min().orElse(-1), rhi = Arrays.stream(resid).max().orElse(1);
        List<ChartSpec> charts = List.of(
            hist("Test residuals (actual − predicted)", resid, 12, rlo, rhi),
            hist("Predicted " + tgt + " distribution", predAll, 12, Arrays.stream(predAll).min().orElse(0), Arrays.stream(predAll).max().orElse(1)));

        out.summary = "Predicting '" + tgt + "': test R² " + String.format("%.3f", r2) + ", RMSE " + Ui.fmt(rmse) + ".";
        out.projection = Projection.of(pr.points(), labels, pr.rows(),
            List.of("Q1 (lowest)", "Q2", "Q3", "Q4 (highest)").toArray(new String[0]), null,
            "Linear regression — predicted quartile on PCA axes", "Linear regression", null, charts);
        out.ui = () -> {
            List<Node> nodes = new ArrayList<>();
            nodes.add(Ui.metricRow(Ui.metric("TEST R²", String.format("%.3f", r2)), Ui.metric("TEST RMSE", Ui.fmt(rmse)),
                Ui.metric("TRAIN R²", String.format("%.3f", r.r2())), Ui.metric("TEST ROWS", String.valueOf(testRowsCount))));
            BarChart<String, Number> w = Ui.barChart("Effect on " + tgt + " per +1 std of each feature", 300);
            w.getData().add(Ui.series("weight", wNames, wVals));
            nodes.add(Ui.card("FEATURE WEIGHTS  (standardised)", w));
            return nodes;
        };
        return out;
    }

    // ---- helpers -----------------------------------------------------------
    private static ChartSpec hist(String title, double[] vals, int bins, double lo, double hi) {
        if (!(hi > lo)) hi = lo + 1;
        int[] c = new int[bins];
        for (double v : vals) if (Double.isFinite(v)) { int b = (int) ((v - lo) / (hi - lo) * bins); c[Math.max(0, Math.min(bins - 1, b))]++; }
        List<String> labels = new ArrayList<>(); List<Double> values = new ArrayList<>();
        for (int i = 0; i < bins; i++) { labels.add(String.format("%.2f", lo + (i + 0.5) * (hi - lo) / bins)); values.add((double) c[i]); }
        return ChartSpec.bar(title, labels, values);
    }

    private void topWeights(List<Integer> feats, double[] w, List<String> names, List<Double> vals) {
        Integer[] order = new Integer[w.length];
        for (int i = 0; i < w.length; i++) order[i] = i;
        Arrays.sort(order, (a, b) -> Double.compare(Math.abs(w[b]), Math.abs(w[a])));
        for (int i = 0; i < Math.min(10, order.length); i++) { names.add(st.dataset().columns().get(feats.get(order[i]))); vals.add(w[order[i]]); }
    }

    private static int sampleIndex(int sample, int total, int count) {
        return count == 1 ? 0 : (int) ((long) sample * (total - 1) / (count - 1));
    }

    private static int trainingEpochs(int rows) {
        return Math.max(1, Math.min(1000, 10_000_000 / Math.max(1, rows)));
    }

    private static int[] mapRows(int[] sourceRows, int[] indexes) {
        int[] rows = new int[indexes.length];
        for (int i = 0; i < indexes.length; i++) rows[i] = sourceRows[indexes[i]];
        return rows;
    }

    private static double predict(double[] features, double[] weights, double intercept) {
        double value = intercept;
        for (int j = 0; j < features.length; j++) value += weights[j] * features[j];
        return value;
    }

    private static double[][] sampleRows(double[][] data, int count) {
        double[][] sample = new double[count][];
        for (int i = 0; i < count; i++) sample[i] = data[sampleIndex(i, data.length, count)];
        return sample;
    }

    private static TableView<String[]> stringTable(List<String> heads, List<String[]> rows) {
        TableView<String[]> tv = new TableView<>();
        for (int i = 0; i < heads.size(); i++) {
            final int idx = i;
            TableColumn<String[], String> c = new TableColumn<>(heads.get(i));
            c.setCellValueFactory(d -> new SimpleStringProperty(d.getValue()[idx]));
            c.setPrefWidth(i == 0 ? 170 : 110);
            tv.getColumns().add(c);
        }
        tv.setItems(FXCollections.observableArrayList(rows));
        double h = 56 + 30 * rows.size();
        tv.setPrefHeight(h); tv.setMinHeight(h);
        return tv;
    }
}
