package com.datascope.app.views;

import com.datascope.app.AppState;
import com.datascope.ml.Stats;
import com.datascope.model.DataSet;
import com.datascope.stream.ReplayEngine;
import com.datascope.util.Async;
import com.datascope.util.Ui;
import javafx.animation.AnimationTimer;
import javafx.application.Platform;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;

import java.util.*;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Streams the dataset through a producer → bounded queue → consumer pipeline and plots one numeric
 * column live. Its purpose is to show how throughput, buffering and backpressure behave in real time:
 * shrink the queue and switch on the slow consumer to watch rows get dropped and the queue saturate.
 */
public final class LiveView {
    private record SignalStats(double mean, double std) {}
    private static final int WINDOW = 200, RECENT = 12;

    private final AppState st;
    private final ReplayEngine replay = new ReplayEngine();
    private final ScrollPane root;
    private final ComboBox<String> rate = new ComboBox<>(FXCollections.observableArrayList("100", "500", "1000", "2500", "5000", "10000"));
    private final ComboBox<String> buffer = new ComboBox<>(FXCollections.observableArrayList("50", "200", "1000", "5000"));
    private final ComboBox<String> column = new ComboBox<>();
    private final CheckBox slow = new CheckBox("Simulate slow consumer");
    private final Button start = Ui.button("Start"), pause = Ui.ghost("Pause"), stop = Ui.ghost("Stop");
    private final Label status = new Label("Idle"), processed = new Label("0"), queue = new Label("0 / 0"),
        dropped = new Label("0"), alerts = new Label("0"), throughput = new Label("0 /s"), pressure = new Label("NORMAL");
    private final ProgressBar queueBar = new ProgressBar(0);
    private final XYChart.Series<Number, Number> series = new XYChart.Series<>();
    private final LineChart<Number, Number> chart;
    private final ListView<String> recentList = new ListView<>();
    private final Label signalInfo = new Label("Pick a numeric column, then Start.");

    private final Object lock = new Object();
    private final ArrayDeque<double[]> window = new ArrayDeque<>();
    private final ArrayDeque<String> recentRows = new ArrayDeque<>();
    private final AtomicInteger alertCount = new AtomicInteger();
    private final AtomicLong preparation = new AtomicLong();
    private volatile int version = 0;
    private volatile boolean slowConsumer = false;
    private volatile double signalMean = 0, signalStd = 1;
    private volatile String signalName = "";
    private int shownVersion = -1;
    private long lastTick = 0, lastProcessed = 0;
    private final AnimationTimer timer;

    public LiveView(AppState st) {
        this.st = st;
        rate.setValue("1000"); buffer.setValue("200");
        rate.setPrefWidth(110); buffer.setPrefWidth(110); column.setPrefWidth(180);

        NumberAxis x = new NumberAxis(), y = new NumberAxis();
        x.setForceZeroInRange(false); y.setForceZeroInRange(false); x.setLabel("Row index"); y.setLabel("Value");
        chart = new LineChart<>(x, y);
        chart.setAnimated(false); chart.setCreateSymbols(false); chart.setLegendVisible(false);
        chart.setPrefHeight(320); chart.setMinHeight(320);
        chart.getData().add(series);
        Ui.attachHover(chart);

        start.setOnAction(e -> begin());
        pause.setOnAction(e -> {
            if (!replay.isRunning()) return;
            if (replay.isPaused()) { replay.resume(); status.setText("Running"); pause.setText("Pause"); }
            else { replay.pause(); status.setText("Paused"); pause.setText("Resume"); }
        });
        stop.setOnAction(e -> { replay.stop(); status.setText("Stopped"); pause.setText("Pause"); });
        rate.valueProperty().addListener((o, a, b) -> { if (b != null) replay.setRate(Integer.parseInt(b)); });
        slow.selectedProperty().addListener((o, a, b) -> slowConsumer = b);

        queueBar.setPrefWidth(200);
        signalInfo.getStyleClass().add("muted"); signalInfo.setWrapText(true);
        HBox controls = new HBox(14, Ui.field("Rows / second", rate), Ui.field("Queue size", buffer), Ui.field("Column to plot", column), start, pause, stop, slow);
        controls.setAlignment(Pos.BOTTOM_LEFT);
        HBox kpis = Ui.metricRow(Ui.liveMetric("STATUS", status), Ui.liveMetric("PROCESSED", processed), Ui.liveMetric("THROUGHPUT", throughput),
            Ui.liveMetric("DROPPED", dropped), Ui.liveMetric("LIVE ALERTS (|z| ≥ 3)", alerts), Ui.liveMetric("BACKPRESSURE", pressure));
        VBox q = new VBox(6, queue, queueBar);
        recentList.setPrefHeight(240); recentList.setMinHeight(240);

        VBox purpose = new VBox(6,
            Ui.muted("This tab turns a static table into a stream so you can watch a real pipeline in action. "
                + "A producer emits one row at a chosen rate; a bounded queue buffers it; a consumer processes rows and plots the chosen column."),
            Ui.muted("• Lower the queue size and tick “Simulate slow consumer” to watch the queue fill and rows get dropped (backpressure)."),
            Ui.muted("• “LIVE ALERTS” counts rows whose robust |z| ≥ 3 against the whole column — an online anomaly signal."),
            Ui.muted("• Hover anywhere on the chart to read the nearest row's index, value and z-score."));

        root = Ui.page("Live Stream", "A producer → bounded queue → consumer pipeline over your data. Use it to understand throughput, buffering and backpressure — not just to draw a line.",
            Ui.card("WHAT THIS TAB SHOWS", purpose),
            Ui.card("CONTROLS", controls), kpis,
            Ui.card("QUEUE FILL", q),
            Ui.card("LIVE SIGNAL  (last " + WINDOW + " rows)", new VBox(8, signalInfo, chart)),
            Ui.card("LATEST ROWS", recentList));

        timer = new AnimationTimer() { @Override public void handle(long now) { tick(now); } };
        timer.start();
        st.onData(this::reset);
        reset();
    }

    public Node node() { return root; }

    private void reset() {
        preparation.incrementAndGet();
        start.setDisable(false);
        replay.stop(); pause.setText("Pause"); status.setText("Idle");
        String prev = column.getValue();
        column.setItems(FXCollections.observableArrayList(st.numericNames()));
        if (prev != null && column.getItems().contains(prev)) column.setValue(prev); else if (!column.getItems().isEmpty()) column.getSelectionModel().selectFirst();
        clearBuffers(); shownVersion = -1; tick(System.nanoTime() + 1_000_000_000L);
        signalInfo.setText(st.hasData() ? "Select a numeric column and press Start." : "Load a dataset to stream it.");
    }

    private void clearBuffers() {
        synchronized (lock) { window.clear(); recentRows.clear(); }
        alertCount.set(0); version++;
    }

    private void begin() {
        if (!st.hasData()) { status.setText("No data"); return; }
        if (column.getValue() == null) { status.setText("No numeric column"); return; }
        final DataSet ds = st.dataset();
        final int col = ds.columns().indexOf(column.getValue());
        long token = preparation.incrementAndGet();
        start.setDisable(true); status.setText("Preparing full-column signal statistics…");
        Async.run(() -> {
            double[] values = ds.numericColumn(col);
            return new SignalStats(Stats.mean(values), Math.max(1e-9, Stats.std(values)));
        }, stats -> {
            if (preparation.get() != token || st.dataset() != ds) return;
            start.setDisable(false);
            beginReplay(ds, col, stats);
        }, err -> {
            if (preparation.get() == token) {
                start.setDisable(false);
                status.setText("Could not prepare signal statistics: " + err.getMessage());
            }
        });
    }

    private void beginReplay(DataSet ds, int col, SignalStats stats) {
        double mean = stats.mean(), std = stats.std();
        signalMean = mean; signalStd = std; signalName = column.getValue();
        signalInfo.setText("Streaming “" + signalName + "” · mean " + Ui.fmt(mean) + " · std " + Ui.fmt(std)
            + " · alert when |z| ≥ 3 (values outside " + Ui.fmt(mean - 3 * std) + " … " + Ui.fmt(mean + 3 * std) + ")");
        clearBuffers(); lastProcessed = 0; pause.setText("Pause");
        status.setText("Running");
        replay.start(ds, Integer.parseInt(rate.getValue()), Integer.parseInt(buffer.getValue()), idx -> {
            if (slowConsumer) { try { Thread.sleep(3); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); } }
            List<String> row = ds.row(idx);
            Double parsed = col < row.size() ? DataSet.parseDouble(row.get(col)) : null;
            double v = parsed == null ? Double.NaN : parsed;
            synchronized (lock) {
                window.addLast(new double[]{idx, v}); if (window.size() > WINDOW) window.pollFirst();
                recentRows.addFirst((idx + 1) + ":  " + String.join(" | ", row)); if (recentRows.size() > RECENT) recentRows.pollLast();
            }
            if (Double.isFinite(v) && Math.abs((v - mean) / std) >= 3) alertCount.incrementAndGet();
            version++;
        }, () -> Platform.runLater(() -> status.setText("Complete")));
    }

    private void tick(long now) {
        if (now - lastTick < 150_000_000L) return;
        double dt = (now - lastTick) / 1e9; lastTick = now;
        long p = replay.processed();
        processed.setText(String.format("%,d", p));
        throughput.setText(String.format("%,.0f /s", Math.max(0, (p - lastProcessed) / Math.max(dt, 1e-3)))); lastProcessed = p;
        dropped.setText(String.format("%,d", replay.dropped()));
        alerts.setText(String.valueOf(alertCount.get()));
        int cap = replay.isRunning() ? Math.max(1, replay.capacity()) : Math.max(1, Integer.parseInt(buffer.getValue()));
        int size = replay.isRunning() ? replay.queueSize() : 0;
        queue.setText(size + " / " + cap + " buffered"); queueBar.setProgress((double) size / cap);
        boolean hot = size > cap * 0.8;
        pressure.setText(hot ? "ACTIVE" : "NORMAL");
        pressure.getStyleClass().remove("text-bad");
        if (hot) pressure.getStyleClass().add("text-bad");

        if (version != shownVersion) {
            shownVersion = version;
            List<XYChart.Data<Number, Number>> pts = new ArrayList<>(); List<String> rows;
            synchronized (lock) {
                for (double[] w : window) if (Double.isFinite(w[1])) {
                    XYChart.Data<Number, Number> d = new XYChart.Data<>(w[0] + 1, w[1]);
                    double z = (w[1] - signalMean) / signalStd;
                    d.setExtraValue("Row " + (long) (w[0] + 1) + "  ·  " + signalName + " = " + Ui.fmt(w[1]) + "  ·  z = " + String.format("%+.2f", z)
                        + (Math.abs(z) >= 3 ? "  (ALERT)" : ""));
                    pts.add(d);
                }
                rows = new ArrayList<>(recentRows);
            }
            series.getData().setAll(pts);
            recentList.setItems(FXCollections.observableArrayList(rows));
        }
    }
}
