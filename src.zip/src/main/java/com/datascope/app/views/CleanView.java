package com.datascope.app.views;

import com.datascope.analysis.Cleaner;
import com.datascope.analysis.Profiler;
import com.datascope.app.AppState;
import com.datascope.model.ColumnProfile;
import com.datascope.model.DataSet;
import com.datascope.util.Async;
import com.datascope.util.Ui;
import javafx.collections.FXCollections;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;

import java.io.*;
import java.nio.file.*;
import java.util.*;

/** Preview-first cleaning. Every step produces a new working copy; the original can always be restored. */
public final class CleanView {
    private record Prepared(Cleaner.Outcome outcome, List<ColumnProfile> profiles) {}
    private static final int PREVIEW_PAGE_SIZE = 500;
    private static final String[] ACTIONS = {
        "Fill missing — mean", "Fill missing — median", "Fill missing — most common value",
        "Clip outliers (|z| ≥ 3)", "Drop rows missing this column"};

    private final AppState st;
    private final ScrollPane root;
    private final ComboBox<String> column = new ComboBox<>();
    private final ComboBox<String> action = new ComboBox<>(FXCollections.observableArrayList(ACTIONS));
    private final Label result = new Label("Choose a column and an action, then preview it.");
    private final Label previewNote = new Label("Preview a step to see exactly which cells would change — before and after.");
    private final com.datascope.swing.DataGrid preview = new com.datascope.swing.DataGrid(280);
    private final ListView<String> log = new ListView<>();
    private final Label state = new Label();
    private final Button previewButton = Ui.ghost("Preview");
    private final Button applyButton = Ui.button("Apply step");
    private final Button dedupeButton = Ui.ghost("Remove duplicate rows");
    private final Button export = Ui.ghost("Export current data as CSV…");
    private final Button previousPreview = Ui.ghost("Previous");
    private final Button nextPreview = Ui.ghost("Next");
    private final Label previewPageLabel = new Label("No changes");
    private List<Cleaner.Change> previewChanges = List.of();
    private String previewMessage = "";
    private int previewPage;
    private boolean busy;

    public CleanView(AppState st) {
        this.st = st;
        column.setPrefWidth(200); action.setPrefWidth(260); action.getSelectionModel().selectFirst();
        result.setWrapText(true); previewNote.getStyleClass().add("muted");

        previewButton.setOnAction(e -> run(false));
        applyButton.setOnAction(e -> run(true));
        previousPreview.setOnAction(e -> { if (previewPage > 0) { previewPage--; renderChangePage(); } });
        nextPreview.setOnAction(e -> {
            if ((previewPage + 1) * PREVIEW_PAGE_SIZE < previewChanges.size()) {
                previewPage++;
                renderChangePage();
            }
        });

        dedupeButton.setOnAction(e -> {
            if (busy) return;
            if (!st.hasData()) return;
            var input = st.dataset();
            setBusy(true); result.setText("Removing duplicate rows…");
            Async.run(() -> {
                Cleaner.Outcome outcome = Cleaner.dropDuplicates(input);
                List<ColumnProfile> profiles = outcome.changed() == 0 ? List.of() : Profiler.profile(outcome.data());
                return new Prepared(outcome, profiles);
            }, prepared -> {
                Cleaner.Outcome o = prepared.outcome();
                setBusy(false);
                if (st.dataset() != input) { closeIfNew(o.data(), input); result.setText("Dataset changed before duplicate removal completed; no changes were applied."); return; }
                showChanges(o, "Duplicate rows that were removed (" + o.changed() + "):");
                if (o.changed() == 0) { closeIfNew(o.data(), input); result.setText(o.message()); return; }
                st.apply(o.data(), prepared.profiles(), o.message()); result.setText(o.message());
            }, err -> { setBusy(false); result.setText("Duplicate removal failed: " + err.getMessage()); });
        });
        Button reset = Ui.ghost("Reset to original");
        reset.setOnAction(e -> { st.resetToOriginal(); showChanges(new Cleaner.Outcome(st.dataset(), "", 0, List.of()), ""); result.setText("Restored the original data."); });
        export.setOnAction(e -> export());

        HBox controls = new HBox(14, Ui.field("Column", column), Ui.field("Action", action), previewButton, applyButton);
        controls.setAlignment(Pos.BOTTOM_LEFT);
        HBox extras = new HBox(10, dedupeButton, reset, export);

        preview.setEmptyText("Nothing to preview yet");
        HBox previewPager = new HBox(8, previousPreview, previewPageLabel, nextPreview);
        previewPager.setAlignment(Pos.CENTER_RIGHT);

        log.setPrefHeight(150); log.setPlaceholder(new Label("No cleaning steps applied yet"));
        state.getStyleClass().add("muted");

        root = Ui.page("Clean", "Fix data problems safely. Steps apply to a working copy — your file on disk is never touched.",
            Ui.card("CLEANING WORKBENCH", new VBox(14, controls, extras)),
            Ui.card("PREVIEW — ROWS AND CELLS AFFECTED", new VBox(12, previewNote, preview.node(), previewPager)),
            Ui.card("RESULT", new VBox(10, result, state)),
            Ui.card("STEPS APPLIED", log));
        st.onData(this::refresh);
        refresh();
    }

    public Node node() { return root; }

    private void refresh() {
        String prev = column.getValue();
        column.setItems(FXCollections.observableArrayList(st.dataset().columns()));
        if (prev != null && column.getItems().contains(prev)) column.setValue(prev); else if (!column.getItems().isEmpty()) column.getSelectionModel().selectFirst();
        log.setItems(FXCollections.observableArrayList(st.history()));
        state.setText(st.isModified() ? "Working on a cleaned copy (" + st.dataset().rowCount() + " rows)." : "Working on the original data.");
    }

    private void run(boolean commit) {
        if (busy) return;
        if (!st.hasData() || column.getValue() == null) { result.setText("Load a dataset first."); return; }
        var input = st.dataset();
        int idx = st.dataset().columns().indexOf(column.getValue());
        int a = action.getSelectionModel().getSelectedIndex();
        boolean numeric = st.profiles().get(idx).type() == com.datascope.model.ColumnType.NUMERIC;
        if ((a == 0 || a == 1 || a == 3) && !numeric) { result.setText("'" + column.getValue() + "' is not numeric — use “most common value” or drop rows instead."); return; }
        setBusy(true);
        result.setText(commit ? "Applying cleaning step…" : "Previewing cleaning step…");
        Async.run(() -> {
            Cleaner.Outcome outcome = switch (a) {
                case 0 -> Cleaner.impute(input, idx, "mean");
                case 1 -> Cleaner.impute(input, idx, "median");
                case 2 -> Cleaner.impute(input, idx, "mode");
                case 3 -> Cleaner.clipOutliers(input, idx, 3.0);
                default -> Cleaner.dropMissing(input, idx);
            };
            List<ColumnProfile> profiles = commit && outcome.changed() > 0 ? Profiler.profile(outcome.data()) : List.of();
            return new Prepared(outcome, profiles);
        }, prepared -> {
            Cleaner.Outcome o = prepared.outcome();
            setBusy(false);
            if (st.dataset() != input) { closeIfNew(o.data(), input); result.setText("Dataset changed before the cleaning step completed; no changes were applied."); return; }
            if (!commit) {
                closeIfNew(o.data(), input);
                result.setText("Preview: " + o.message().replace("Filled", "Would fill").replace("Clipped", "Would clip").replace("Dropped", "Would drop")
                    + (o.changed() == 0 ? "" : "  " + o.changed() + " cell(s) or row(s) affected."));
                showChanges(o, "Changes (" + o.changed() + "):");
                return;
            }
            if (o.changed() == 0) { closeIfNew(o.data(), input); result.setText(o.message()); showChanges(o, "No cells needed changing."); return; }
            st.apply(o.data(), prepared.profiles(), o.message());
            result.setText(o.message());
            showChanges(o, "Changes (" + o.changed() + "):");
        }, err -> { setBusy(false); result.setText("Cleaning failed: " + err.getMessage()); });
    }

    private void setBusy(boolean value) {
        busy = value;
        previewButton.setDisable(value); applyButton.setDisable(value); dedupeButton.setDisable(value);
    }

    private void showChanges(Cleaner.Outcome o, String note) {
        previewChanges = o.changes();
        previewMessage = note;
        previewPage = 0;
        renderChangePage();
    }

    private void renderChangePage() {
        int total = previewChanges.size();
        int pages = total == 0 ? 0 : (total - 1) / PREVIEW_PAGE_SIZE + 1;
        int start = previewPage * PREVIEW_PAGE_SIZE;
        int end = Math.min(total, start + PREVIEW_PAGE_SIZE);
        List<List<String>> rows = new ArrayList<>(end - start);
        for (Cleaner.Change c : previewChanges.subList(start, end))
            rows.add(Arrays.asList(String.valueOf(c.row() + 1), s(c.column()), s(c.before()), s(c.after())));
        preview.setData(List.of("Row #", "Column", "Before", "After"), rows);
        previewNote.setText(previewMessage);
        previewPageLabel.setText(pages == 0 ? "No changes" :
            "Page " + (previewPage + 1) + " of " + pages + " · showing " + (start + 1) + "–" + end + " of " + total);
        previousPreview.setDisable(previewPage == 0);
        nextPreview.setDisable(previewPage + 1 >= pages);
    }

    private static String s(String v) { return v == null ? "" : v; }
    private static void closeIfNew(DataSet result, DataSet input) {
        if (result != input) result.close();
    }

    private void export() {
        if (!st.hasData()) return;
        FileChooser fc = new FileChooser();
        fc.setInitialFileName("datascope_cleaned.csv");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("CSV", "*.csv"));
        File f = fc.showSaveDialog(root.getScene().getWindow());
        if (f == null) return;
        DataSet ds = st.dataset();
        export.setDisable(true); result.setText("Exporting all " + ds.rowCount() + " rows…");
        Async.run(() -> {
            try (BufferedWriter w = Files.newBufferedWriter(f.toPath())) {
                w.write(csvLine(ds.columns())); w.newLine();
                for (List<String> row : ds.rows()) { w.write(csvLine(row)); w.newLine(); }
            }
            return ds.rowCount();
        }, count -> {
            export.setDisable(false);
            result.setText("Exported " + count + " rows to " + f.getName());
            st.notify("Exported cleaned data to " + f.getName());
        }, err -> { export.setDisable(false); result.setText("Export failed: " + err.getMessage()); });
    }

    static String csvLine(List<String> cells) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < cells.size(); i++) {
            if (i > 0) sb.append(',');
            String v = cells.get(i);
            if (v.contains(",") || v.contains("\"") || v.contains("\n")) sb.append('"').append(v.replace("\"", "\"\"")).append('"'); else sb.append(v);
        }
        return sb.toString();
    }
}
