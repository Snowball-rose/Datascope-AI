package com.datascope.app.views;

import com.datascope.analysis.DataQuality;
import com.datascope.app.AppState;
import com.datascope.model.ColumnProfile;
import com.datascope.model.DataSet;
import com.datascope.util.Async;
import com.datascope.util.Ui;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.animation.PauseTransition;
import javafx.util.Duration;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.atomic.AtomicLong;

/** Landing page: drop zone, KPIs, a transparent quality breakdown, column chips and a filterable data grid. */
public final class OverviewView {
    private static final int TABLE_PAGE_SIZE = 500;
    private static final String ALL = "All columns";
    private static final String[] MODES = com.datascope.swing.DataGrid.MODES;

    private final AppState st;
    private final ScrollPane root;
    private final Label fileName = new Label("—");
    private final Label fileMeta = new Label("");
    private final HBox kpis = new HBox(12);
    private final FlowPane chips = new FlowPane(8, 8);
    private final VBox qualityBody = new VBox(12);
    private final com.datascope.swing.DataGrid grid = new com.datascope.swing.DataGrid(450);
    private final TextField search = new TextField();
    private final ComboBox<String> filterColumn = new ComboBox<>();
    private final ComboBox<String> filterMode = new ComboBox<>(FXCollections.observableArrayList(MODES));
    private final Label tableNote = new Label();
    private final Label pageLabel = new Label();
    private final Button previousPage = Ui.ghost("Previous");
    private final Button nextPage = Ui.ghost("Next");
    private final PauseTransition filterDelay = new PauseTransition(Duration.millis(250));
    private final AtomicLong filterRevision = new AtomicLong();
    private final AtomicLong dataRevision = new AtomicLong();
    private int[] matchingRows;
    private List<Integer> pageRows = List.of();
    private int page;
    private boolean refreshing;

    public OverviewView(AppState st, Runnable chooseFile, Runnable loadDemo) {
        this.st = st;

        Label big = new Label("Drop a CSV or XLSX file anywhere");
        big.getStyleClass().add("hero-title");
        Label small = Ui.muted("DataScope detects column types, scores data quality, finds relationships and runs ML — all locally. "
            + "Your original file is never modified.");
        Button choose = Ui.button("Choose file…"); choose.setOnAction(e -> chooseFile.run());
        Button demo = Ui.ghost("Load demo data"); demo.setOnAction(e -> loadDemo.run());
        HBox actions = new HBox(10, choose, demo);
        VBox drop = new VBox(10, big, small, actions);
        drop.getStyleClass().add("dropzone");
        drop.setOnMouseClicked(e -> { if (e.getTarget() == drop) chooseFile.run(); });
        HBox.setHgrow(drop, Priority.ALWAYS);

        fileName.getStyleClass().add("file-name");
        fileMeta.getStyleClass().add("muted");
        VBox fileCard = new VBox(6, new Label("CURRENT DATASET"), fileName, fileMeta);
        fileCard.getChildren().get(0).getStyleClass().add("card-title");
        fileCard.getStyleClass().add("card");
        fileCard.setMinWidth(260); fileCard.setPrefWidth(300);
        HBox hero = new HBox(16, drop, fileCard);

        tableNote.getStyleClass().add("muted");
        search.setPromptText("Filter value…"); search.setPrefWidth(220);
        filterColumn.setPrefWidth(190); filterColumn.getItems().add(ALL); filterColumn.setValue(ALL);
        filterMode.setPrefWidth(130); filterMode.setValue("contains");
        filterColumn.valueProperty().addListener((o, a, b) -> applyFilter());
        filterMode.valueProperty().addListener((o, a, b) -> applyFilter());
        previousPage.setOnAction(e -> { if (page > 0) { page--; showPage(); } });
        nextPage.setOnAction(e -> { page++; showPage(); });
        HBox tableBar = new HBox(10, Ui.field("Column", filterColumn), Ui.field("Match", filterMode), Ui.field("Value", search),
            Ui.spacer(), previousPage, pageLabel, nextPage, tableNote);
        tableBar.setAlignment(Pos.BOTTOM_LEFT);
        search.textProperty().addListener((o, a, b) -> applyFilter());
        filterDelay.setOnFinished(e -> searchDataset());

        grid.setEmptyText("No data loaded");
        grid.setOnRowDoubleClick((idx, row) -> {
            if (idx >= 0 && idx < pageRows.size()) showRow(row, pageRows.get(idx));
        });
        tableNote.setText("Double-click a row to inspect every field.");

        root = Ui.page("Overview", "Ingest a table, check its health, and browse the raw rows.",
            hero, kpis,
            Ui.card("DATA QUALITY — HOW THE SCORE IS BUILT", qualityBody),
            Ui.card("COLUMNS", chips),
            Ui.card("DATA PREVIEW", new VBox(14, tableBar, grid.node())));
        st.onData(this::refresh);
        refresh();
    }

    public Node node() { return root; }

    private void refresh() {
        var ds = st.dataset(); List<ColumnProfile> ps = st.profiles();
        long revision = dataRevision.incrementAndGet();
        filterRevision.incrementAndGet();
        refreshing = true;
        fileName.setText(st.hasData() ? ds.name() + (st.isModified() ? "  (cleaned copy)" : "") : "No file loaded");
        fileMeta.setText(st.hasData() ? ds.rowCount() + " rows × " + ds.columnCount() + " columns" : "Upload a file or load the demo data");

        kpis.getChildren().clear();
        qualityBody.getChildren().clear();
        if (st.hasData()) {
            long numeric = ps.stream().filter(p -> p.type() == com.datascope.model.ColumnType.NUMERIC).count();
            kpis.getChildren().addAll(Ui.metric("QUALITY SCORE", "Calculating…"), Ui.metric("ROWS", String.format("%,d", ds.rowCount())), Ui.metric("COLUMNS", String.valueOf(ds.columnCount())),
                Ui.metric("NUMERIC", String.valueOf(numeric)), Ui.metric("MISSING CELLS", "Calculating…"), Ui.metric("DUPLICATE ROWS", "Calculating…"));
            qualityBody.getChildren().setAll(Ui.muted("Scoring every row in the background…"));
            Async.run(() -> DataQuality.score(ds, ps), q -> {
                if (dataRevision.get() == revision) showQuality(q);
            }, err -> {
                if (dataRevision.get() == revision) {
                    kpis.getChildren().set(0, Ui.metric("QUALITY SCORE", "Failed"));
                    qualityBody.getChildren().setAll(Ui.emptyState("Quality analysis failed: " + err.getMessage()));
                }
            });
        } else {
            qualityBody.getChildren().add(Ui.emptyState("Load a dataset to see its quality breakdown."));
        }

        chips.getChildren().clear();
        for (ColumnProfile p : ps) {
            Label c = Ui.chip(p.name() + "  ·  " + p.type().name().toLowerCase());
            c.getStyleClass().add("type-" + p.type().name().toLowerCase());
            chips.getChildren().add(c);
        }

        // data grid — a real Swing JTable hosted in a SwingNode
        filterColumn.getItems().setAll(ALL);
        for (String name : ds.columns()) filterColumn.getItems().add(name);
        filterColumn.setValue(ALL);
        search.clear();
        refreshing = false;
        matchingRows = null;
        page = 0;
        showPage();
    }

    private void showQuality(DataQuality.Result q) {
        kpis.getChildren().set(0, Ui.metric("QUALITY SCORE", q.score() + " / 100"));
        VBox qTile = (VBox) kpis.getChildren().get(0);
        qTile.getStyleClass().add(q.score() >= 85 ? "metric-good" : q.score() >= 60 ? "metric-warn" : "metric-bad");
        kpis.getChildren().set(4, Ui.metric("MISSING CELLS", String.format("%,d", q.missingCells())));
        kpis.getChildren().set(5, Ui.metric("DUPLICATE ROWS", String.valueOf(q.duplicateRows())));

        Label verdict = new Label(q.verdict());
        verdict.getStyleClass().add("finding-title");
        Label formula = Ui.muted("Score = 40% completeness + 20% uniqueness + 15% consistency + 10% validity + 15% feature usefulness. "
            + "Hover a meter for the raw counts. Completeness = filled cells; uniqueness = non-duplicate rows; "
            + "consistency = non-constant columns; validity = cells within 4 robust deviations; usefulness = non-constant, non-identifier columns.");
        HBox meters = new HBox(16,
            Ui.meter("COMPLETENESS (40%)", q.completeness(), pct(q.completeness())),
            Ui.meter("UNIQUENESS (20%)", q.uniqueness(), pct(q.uniqueness())),
            Ui.meter("CONSISTENCY (15%)", q.consistency(), pct(q.consistency())),
            Ui.meter("VALIDITY (10%)", q.validity(), pct(q.validity())),
            Ui.meter("USEFULNESS (15%)", q.usefulness(), pct(q.usefulness())));
        meters.getChildren().forEach(n -> HBox.setHgrow(n, Priority.ALWAYS));
        qualityBody.getChildren().setAll(verdict, meters, formula);
    }

    private void applyFilter() {
        if (refreshing) return;
        filterRevision.incrementAndGet();
        page = 0;
        filterDelay.stop();
        String needle = search.getText() == null ? "" : search.getText().trim();
        String mode = filterMode.getValue() == null ? "contains" : filterMode.getValue();
        if (needle.isEmpty() && !mode.equals("is empty") && !mode.equals("is not empty")) {
            matchingRows = null;
            showPage();
        } else {
            tableNote.setText("Preparing full-dataset search…");
            filterDelay.playFromStart();
        }
    }

    private void searchDataset() {
        String needle = search.getText() == null ? "" : search.getText().trim().toLowerCase(Locale.ROOT);
        String mode = filterMode.getValue() == null ? "contains" : filterMode.getValue();
        int col = filterColumn.getValue() == null || ALL.equals(filterColumn.getValue()) ? -1 : filterColumn.getItems().indexOf(filterColumn.getValue()) - 1;
        var ds = st.dataset();
        long revision = filterRevision.get();
        Async.run(() -> {
            IntBuffer matches = new IntBuffer();
            for (int row = 0; row < ds.rowCount(); row++) {
                List<String> values = ds.row(row);
                if (col < 0) {
                    for (String value : values) {
                        if (matches(value, mode, needle)) { matches.add(row); break; }
                    }
                } else if (col < values.size() && matches(values.get(col), mode, needle)) {
                    matches.add(row);
                }
            }
            return matches.toArray();
        }, result -> {
            if (filterRevision.get() != revision || st.dataset() != ds) return;
            matchingRows = result;
            page = 0;
            showPage();
        }, err -> {
            if (filterRevision.get() == revision) tableNote.setText("Search failed: " + err.getMessage());
        });
    }

    private void showPage() {
        var ds = st.dataset();
        int total = matchingRows == null ? ds.rowCount() : matchingRows.length;
        int pages = total == 0 ? 0 : (total - 1) / TABLE_PAGE_SIZE + 1;
        if (pages == 0) page = 0;
        else page = Math.max(0, Math.min(page, pages - 1));
        int start = page * TABLE_PAGE_SIZE, end = Math.min(total, start + TABLE_PAGE_SIZE);
        List<List<String>> rows = new ArrayList<>(end - start);
        List<Integer> indexes = new ArrayList<>(end - start);
        for (int i = start; i < end; i++) {
            int source = matchingRows == null ? i : matchingRows[i];
            indexes.add(source);
            rows.add(ds.row(source));
        }
        pageRows = List.copyOf(indexes);
        grid.setData(ds.columns(), rows);
        previousPage.setDisable(page <= 0);
        nextPage.setDisable(page + 1 >= pages);
        pageLabel.setText(pages == 0 ? "Page 0 of 0" : "Page " + (page + 1) + " of " + pages);
        tableNote.setText(total == 0 ? "No matching rows" : "Rows " + (start + 1) + "–" + end + " of " + total
            + (matchingRows == null ? "" : " matches (" + ds.rowCount() + " total)"));
    }

    private static boolean matches(String value, String mode, String needle) {
        String text = value == null ? "" : value;
        return switch (mode) {
            case "equals" -> text.toLowerCase(Locale.ROOT).equals(needle);
            case "starts with" -> text.toLowerCase(Locale.ROOT).startsWith(needle);
            case "is empty" -> text.isBlank();
            case "is not empty" -> !text.isBlank();
            case ">", "≥", "<", "≤" -> {
                Double a = DataSet.parseDouble(text), b = DataSet.parseDouble(needle);
                if (a == null || b == null) yield false;
                yield switch (mode) {
                    case ">" -> a > b;
                    case "≥" -> a >= b;
                    case "<" -> a < b;
                    default -> a <= b;
                };
            }
            default -> text.toLowerCase(Locale.ROOT).contains(needle);
        };
    }

    private static final class IntBuffer {
        private int[] values = new int[1024];
        private int size;
        void add(int value) {
            if (size == values.length) values = java.util.Arrays.copyOf(values, Math.multiplyExact(values.length, 2));
            values[size++] = value;
        }
        int[] toArray() { return java.util.Arrays.copyOf(values, size); }
    }

    private static String pct(double f) {
        double v = f * 100;
        if (v >= 99.95) return "100%";
        if (v <= 0.05) return "0%";
        return String.format("%.1f%%", v);
    }

    private void showRow(List<String> row, int index) {
        if (row == null) return;
        Dialog<Void> dialog = new Dialog<>();
        dialog.setTitle("Row " + (index + 1));
        dialog.getDialogPane().getButtonTypes().add(ButtonType.CLOSE);
        TableView<String[]> tv = new TableView<>();
        TableColumn<String[], String> a = new TableColumn<>("Column");
        a.setCellValueFactory(d -> new SimpleStringProperty(d.getValue()[0])); a.setPrefWidth(190);
        TableColumn<String[], String> b = new TableColumn<>("Value");
        b.setCellValueFactory(d -> new SimpleStringProperty(d.getValue()[1])); b.setPrefWidth(320);
        tv.getColumns().addAll(a, b);
        List<String[]> data = new ArrayList<>();
        for (int c = 0; c < st.dataset().columnCount(); c++) data.add(new String[]{st.dataset().columns().get(c), c < row.size() ? row.get(c) : ""});
        tv.setItems(FXCollections.observableArrayList(data));
        tv.setPrefSize(520, 420);
        VBox box = new VBox(8, Ui.muted("Complete field values for this row."), tv);
        box.setPadding(new Insets(6));
        dialog.getDialogPane().setContent(box);
        dialog.getDialogPane().getStylesheets().addAll(root.getScene().getStylesheets());
        dialog.showAndWait();
    }
}
