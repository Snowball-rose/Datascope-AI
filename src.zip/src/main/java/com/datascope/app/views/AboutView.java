package com.datascope.app.views;

import com.datascope.util.Ui;
import javafx.scene.Node;
import javafx.scene.layout.*;

public final class AboutView {
    private final Node root;

    public AboutView() {
        VBox what = new VBox(10,
            Ui.muted("DataScope AI turns a CSV or XLSX table into an interactive data-intelligence workspace: profile → clean → model → explore → stream."),
            Ui.muted("Everything runs locally. The original file is never modified — cleaning works on a copy that can be reset or exported."));
        VBox stack = new VBox(10,
            Ui.muted("Java 21 · JavaFX 21 + Swing · Apache POI (XLSX) · core Java concurrency"),
            Ui.muted("The interface deliberately uses both desktop toolkits. JavaFX drives the shell, the CSS theme, "
                + "the animated charts, the page transitions and the 3D point cloud. Swing supplies the dense data "
                + "grids — JTable with TableRowSorter and predicate RowFilter — hosted inside the JavaFX scene with "
                + "SwingNode, where its sorting, filtering and large-row performance are the better tool."),
            Ui.muted("From-scratch ML: k-means++ clustering, PCA (power iteration), logistic & linear regression, robust median/MAD anomaly scoring, silhouette, train/test evaluation"));
        VBox keys = new VBox(10,
            Ui.muted("Ctrl+O  open a file      Ctrl+1 … Ctrl+9  jump to a page"),
            Ui.muted("Drag a .csv or .xlsx file onto the window to load it"));
        VBox interactions = new VBox(10,
            Ui.muted("Hover any chart for a floating readout of the nearest point."),
            Ui.muted("Overview: double-click a row for every field; filter by a specific column and match mode."),
            Ui.muted("Clean: preview a step to see the exact cells (row, column, before → after) that would change."),
            Ui.muted("Explorer: click a point to trace it back to its source row; run a technique in ML Studio to publish a new cloud."),
            Ui.muted("Live Stream: hover the signal for the row index, value and z-score; shrink the queue to see backpressure."));
        root = Ui.page("About", "DataScope AI", Ui.card("WHAT IT DOES", what), Ui.card("TECHNOLOGY", stack), Ui.card("INTERACTIONS", interactions), Ui.card("SHORTCUTS", keys));
    }

    public Node node() { return root; }
}
