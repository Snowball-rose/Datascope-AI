package com.datascope.app.views;

import com.datascope.app.AppState;
import com.datascope.app.AppState.Projection;
import com.datascope.app.AppState.Projection.ChartSpec;
import com.datascope.util.Ui;
import javafx.animation.AnimationTimer;
import javafx.application.Platform;
import javafx.beans.property.SimpleStringProperty;
import javafx.collections.FXCollections;
import javafx.geometry.Insets;
import javafx.geometry.Orientation;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.embed.swing.SwingFXUtils;

import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferInt;
import java.util.*;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Rasterized 3D/2D point cloud for all rows. Drag to rotate, scroll to zoom, and click a visible
 * point to inspect its source row. Technique-specific charts are rendered alongside the cloud.
 */
public final class ExplorerView {
    record RasterFrame(BufferedImage image, int[] pointAtPixel, int width, int height) {}
    private static final int MAX_RASTER_WIDTH = 1600, MAX_RASTER_HEIGHT = 1000;
    private static final int POINT_HIT_RADIUS = 7;
    private static final int POINT_RADIUS = 4;
    private static final double EXTENT = 230;

    private final AppState st;
    private final BorderPane root = new BorderPane();
    private final StackPane stage = new StackPane();
    private final ImageView plot = new ImageView();
    private final Label title = new Label("No projection yet");
    private final Label techniqueBadge = Ui.badge("—");
    private final FlowPane legend = new FlowPane(14, 6);
    private final Label empty = new Label("Run a technique in ML Studio — or send results from the Anomaly Lab — to see points here. "
        + "Click any point to inspect the underlying row.");
    private final ToggleButton mode3d = new ToggleButton("3D"), mode2d = new ToggleButton("2D");
    private final CheckBox spin = new CheckBox("Auto-rotate");
    private final VBox chartsBox = new VBox(12);
    private final SplitPane split = new SplitPane();
    private final ScrollPane visuals;
    private final TableView<String[]> detailTable = new TableView<>();
    private final Label detailTitle = new Label("No point selected");
    private final Label detailHint = Ui.muted("Click a point in the plot to trace it back to its source row.");
    private final Tooltip pointTip = new Tooltip();
    private final AnimationTimer timer;
    private final ScheduledExecutorService rasterizer = Executors.newSingleThreadScheduledExecutor(r -> {
        Thread thread = new Thread(r, "datascope-point-rasterizer");
        thread.setDaemon(true);
        return thread;
    });
    private final AtomicLong renderRevision = new AtomicLong();
    private Projection current;
    private RasterFrame frame;
    private ScheduledFuture<?> pendingRender;
    private double xAngle = -18, yAngle = 28, zoom = 1, dragX, dragY;
    private boolean dragged;
    private volatile boolean rendering;
    private long lastSpinRender;

    public ExplorerView(AppState st) {
        this.st = st;
        stage.setMinSize(0, 0);
        plot.fitWidthProperty().bind(stage.widthProperty());
        plot.fitHeightProperty().bind(stage.heightProperty());
        plot.setPreserveRatio(false);
        plot.setSmooth(false);
        plot.setPickOnBounds(true);
        empty.getStyleClass().add("overlay"); empty.setWrapText(true); empty.setMaxWidth(460);
        stage.getChildren().addAll(plot, empty);
        stage.getStyleClass().add("stage");
        mouse();
        stage.widthProperty().addListener((o, a, b) -> requestRender());
        stage.heightProperty().addListener((o, a, b) -> requestRender());

        ToggleGroup g = new ToggleGroup(); mode3d.setToggleGroup(g); mode2d.setToggleGroup(g); mode3d.setSelected(true);
        mode3d.getStyleClass().add("seg"); mode2d.getStyleClass().add("seg");
        g.selectedToggleProperty().addListener((o, a, b) -> { if (b == null) a.setSelected(true); else applyMode(); });
        Button reset = Ui.ghost("Reset view"); reset.setOnAction(e -> {
            xAngle = -18; yAngle = 28; zoom = 1; requestRender();
        });
        timer = new AnimationTimer() {
            @Override public void handle(long now) {
                yAngle += 0.3;
                if (!rendering && now - lastSpinRender >= 500_000_000L) {
                    lastSpinRender = now;
                    requestRender();
                }
            }
        };
        spin.selectedProperty().addListener((o, a, on) -> { if (on) timer.start(); else timer.stop(); });
        title.getStyleClass().add("page-title");
        pointTip.setStyle("-fx-background-color:#0b1018; -fx-border-color:#2b4a6b; -fx-text-fill:#eef6ff; -fx-font-size:12px;");

        HBox bar = new HBox(12, title, techniqueBadge, Ui.spacer(), new HBox(2, mode3d, mode2d), spin, reset);
        bar.setAlignment(Pos.CENTER_LEFT); bar.setPadding(new Insets(16, 22, 8, 22));
        legend.setPadding(new Insets(10, 22, 14, 22));
        Label hint = Ui.muted("Drag to rotate · scroll to zoom · click a point for its full row · axes are the first three principal components · drag the divider to resize");
        VBox bottom = new VBox(4, legend, hint); bottom.setPadding(new Insets(0, 22, 14, 22));

        chartsBox.setPadding(Insets.EMPTY);
        VBox cloud = new VBox(stage);
        VBox.setVgrow(stage, Priority.ALWAYS);
        cloud.setMinHeight(240);

        visuals = new ScrollPane(Ui.card("TECHNIQUE VISUALS", chartsBox));
        visuals.setFitToWidth(true);
        visuals.setHbarPolicy(ScrollPane.ScrollBarPolicy.NEVER);
        visuals.setMinHeight(150);

        split.setOrientation(Orientation.VERTICAL);
        split.getStyleClass().add("explorer-split");
        split.setPadding(new Insets(0, 22, 14, 22));
        split.getItems().addAll(cloud, visuals);
        SplitPane.setResizableWithParent(cloud, Boolean.TRUE);
        SplitPane.setResizableWithParent(visuals, Boolean.FALSE);
        split.heightProperty().addListener((o, a, b) -> fitDivider());
        root.setTop(bar); root.setCenter(split); root.setBottom(bottom);

        // detail panel
        detailTitle.getStyleClass().add("card-title");
        TableColumn<String[], String> f = new TableColumn<>("Field");
        f.setCellValueFactory(d -> new SimpleStringProperty(d.getValue()[0])); f.setPrefWidth(150);
        TableColumn<String[], String> v = new TableColumn<>("Value");
        v.setCellValueFactory(d -> new SimpleStringProperty(d.getValue()[1])); v.setPrefWidth(200);
        detailTable.getColumns().addAll(f, v);
        detailTable.setPrefHeight(430); detailTable.setMinHeight(300);
        detailTable.setPlaceholder(new Label("No point selected"));
        VBox panel = new VBox(8, detailTitle, detailHint, detailTable);
        panel.setPadding(new Insets(16, 16, 16, 4));
        panel.setPrefWidth(360); panel.setMinWidth(300);
        root.setRight(panel);

        st.onProjection(this::refresh);
        refresh();
    }

    public Node node() { return root; }

    private void mouse() {
        plot.setOnMousePressed(e -> { dragX = e.getSceneX(); dragY = e.getSceneY(); dragged = false; });
        plot.setOnMouseDragged(e -> {
            double dx = e.getSceneX() - dragX, dy = e.getSceneY() - dragY;
            if (Math.abs(dx) + Math.abs(dy) > 1) dragged = true;
            if (mode3d.isSelected()) {
                yAngle += dx * 0.4;
                xAngle = Math.max(-89, Math.min(89, xAngle - dy * 0.4));
                requestRender();
            }
            dragX = e.getSceneX(); dragY = e.getSceneY();
        });
        plot.setOnMouseClicked(e -> {
            if (dragged) return;
            int index = pointAt(e.getX(), e.getY());
            if (index >= 0) { showPoint(index); e.consume(); }
        });
        plot.setOnMouseMoved(e -> {
            int index = pointAt(e.getX(), e.getY());
            if (index < 0) { pointTip.hide(); return; }
            pointTip.setText(hoverText(current, index));
            if (!pointTip.isShowing()) pointTip.show(plot, e.getScreenX() + 14, e.getScreenY() + 14);
            else {
                pointTip.setX(e.getScreenX() + 14);
                pointTip.setY(e.getScreenY() + 14);
            }
        });
        plot.setOnMouseExited(e -> pointTip.hide());
        plot.setOnScroll(e -> {
            zoom = Math.max(0.35, Math.min(4, zoom * Math.pow(1.0015, e.getDeltaY())));
            requestRender();
            e.consume();
        });
    }

    private void applyMode() {
        plot.setVisible(st.projection() != null);
        requestRender();
    }

    private static Color colorFor(Projection p, int label) {
        if (p.colors() != null && label < p.colors().length && p.colors()[label] != null) return p.colors()[label];
        return Ui.color(label);
    }

    private void refresh() {
        legend.getChildren().clear(); chartsBox.getChildren().clear();
        Projection p = st.projection();
        current = p;
        frame = null;
        plot.setImage(null);
        renderRevision.incrementAndGet();
        if (pendingRender != null) pendingRender.cancel(false);
        empty.setVisible(p == null);
        if (p == null) {
            title.setText("Explorer"); techniqueBadge.setText("—"); applyMode();
            detailTable.getItems().clear(); detailTitle.setText("No point selected");
            Platform.runLater(this::fitDivider);
            return;
        }
        title.setText(p.title());
        techniqueBadge.setText(p.technique() == null ? "PROJECTION" : p.technique().toUpperCase(Locale.ROOT));
        detailTitle.setText("POINT DETAILS");
        detailHint.setText(String.format("%,d points — all rows · click a visible point to inspect its source row.", p.points().length));

        for (int lab = 0; lab < Math.max(1, p.legend() == null ? 0 : p.legend().length); lab++) {
            String name = p.legend() != null && lab < p.legend().length ? p.legend()[lab] : "Group " + (lab + 1);
            Label l = new Label("●  " + name); l.setStyle("-fx-text-fill: " + Ui.hex(colorFor(p, lab)) + "; -fx-font-weight: bold;");
            legend.getChildren().add(l);
        }

        renderCharts(p);
        applyMode();
        Platform.runLater(this::fitDivider);
    }

    private void requestRender() {
        Projection p = current;
        if (p == null || stage.getWidth() < 2 || stage.getHeight() < 2) return;
        long revision = renderRevision.incrementAndGet();
        if (pendingRender != null) pendingRender.cancel(false);
        int width = Math.min(MAX_RASTER_WIDTH, Math.max(1, (int) Math.round(stage.getWidth())));
        int height = Math.min(MAX_RASTER_HEIGHT, Math.max(1, (int) Math.round(stage.getHeight())));
        double x = xAngle, y = yAngle, scale = zoom;
        boolean threeD = mode3d.isSelected();
        pendingRender = rasterizer.schedule(() -> {
            rendering = true;
            RasterFrame next = rasterize(p, width, height, x, y, scale, threeD, revision, renderRevision);
            if (next == null) {
                Platform.runLater(() -> {
                    if (renderRevision.get() == revision) rendering = false;
                });
                return;
            }
            Platform.runLater(() -> {
                if (renderRevision.get() != revision || current != p) return;
                rendering = false;
                frame = next;
                plot.setImage(SwingFXUtils.toFXImage(next.image(), null));
                if (spin.isSelected()) requestRender();
            });
        }, 70, TimeUnit.MILLISECONDS);
    }

    static RasterFrame rasterize(Projection p, int width, int height,
                                 double xAngle, double yAngle, double zoom,
                                 boolean threeD, long revision, AtomicLong latestRevision) {
        BufferedImage image = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        int[] pixels = ((DataBufferInt) image.getRaster().getDataBuffer()).getData();
        int[] pointAtPixel = new int[pixels.length];
        Arrays.fill(pointAtPixel, -1);
        float[] nearestDepth = new float[pixels.length];
        Arrays.fill(nearestDepth, Float.NEGATIVE_INFINITY);
        short[] hits = new short[pixels.length];

        double[] abs = new double[Math.min(p.points().length, 4096) * 3];
        for (int i = 0; i < abs.length / 3; i++) {
            int row = abs.length / 3 == p.points().length ? i : (int) ((long) i * (p.points().length - 1) / (abs.length / 3 - 1));
            for (int d = 0; d < 3; d++) abs[i * 3 + d] = Math.abs(coord(p.points()[row], d));
        }
        Arrays.sort(abs);
        double ref = abs.length == 0 ? 1 : abs[(int) Math.min(abs.length - 1, Math.floor(abs.length * 0.98))];
        double worldScale = ref < 1e-9 ? 1 : Math.min(width, height) * 0.42 / ref;
        double cosX = Math.cos(Math.toRadians(xAngle)), sinX = Math.sin(Math.toRadians(xAngle));
        double cosY = Math.cos(Math.toRadians(yAngle)), sinY = Math.sin(Math.toRadians(yAngle));
        double camera = Math.min(width, height) * 1.45;
        int[] colors = new int[p.legend() == null ? 1 : p.legend().length];
        for (int i = 0; i < colors.length; i++) {
            Color c = colorFor(p, i);
            colors[i] = 0xff000000 | ((int) (c.getRed() * 255) << 16)
                | ((int) (c.getGreen() * 255) << 8) | (int) (c.getBlue() * 255);
        }

        double[] q = new double[3];
        for (int i = 0; i < p.points().length; i++) {
            if ((i & 0x3fff) == 0 && latestRevision.get() != revision) return null;
            q[0] = clamp(coord(p.points()[i], 0) * worldScale);
            q[1] = clamp(coord(p.points()[i], 1) * worldScale);
            q[2] = clamp(coord(p.points()[i], 2) * worldScale);
            double px, py, depth;
            if (threeD) {
                double xr = q[0] * cosY + q[2] * sinY;
                double zr = -q[0] * sinY + q[2] * cosY;
                double yr = q[1] * cosX - zr * sinX;
                depth = q[1] * sinX + zr * cosX;
                double perspective = camera / Math.max(camera * 0.35, camera - depth);
                px = width / 2.0 + xr * perspective * zoom;
                py = height / 2.0 - yr * perspective * zoom;
            } else {
                px = width / 2.0 + q[0] * zoom;
                py = height / 2.0 - q[1] * zoom;
                depth = 0;
            }
            int ix = (int) px, iy = (int) py;
            if (ix < 0 || ix >= width || iy < 0 || iy >= height) continue;
            int label = p.labels() == null || i >= p.labels().length ? 0 : p.labels()[i];
            int color = label >= 0 && label < colors.length ? colors[label] : 0xff43d8ff;
            for (int dy = -POINT_RADIUS; dy <= POINT_RADIUS; dy++) {
                int py2 = iy + dy;
                if (py2 < 0 || py2 >= height) continue;
                for (int dx = -POINT_RADIUS; dx <= POINT_RADIUS; dx++) {
                    int px2 = ix + dx;
                    if (px2 < 0 || px2 >= width) continue;
                    double d2 = dx * dx + dy * dy;
                    if (d2 > (double) POINT_RADIUS * POINT_RADIUS) continue;
                    int at = py2 * width + px2;
                    int count = Short.toUnsignedInt(hits[at]);
                    int previous = pixels[at];
                    if (count == 0) pixels[at] = color;
                    else if (count < 255) {
                        int red = (((previous >> 16) & 255) * count + ((color >> 16) & 255)) / (count + 1);
                        int green = (((previous >> 8) & 255) * count + ((color >> 8) & 255)) / (count + 1);
                        int blue = ((previous & 255) * count + (color & 255)) / (count + 1);
                        pixels[at] = 0xff000000 | red << 16 | green << 8 | blue;
                    }
                    if (count < 255) hits[at] = (short) (count + 1);
                    if (depth >= nearestDepth[at]) {
                        nearestDepth[at] = (float) depth;
                        pointAtPixel[at] = i;
                    }
                }
            }
        }
        for (int i = 0; i < pixels.length; i++) {
            int count = Short.toUnsignedInt(hits[i]);
            if (count < 2) continue;
            double brightness = 1 + Math.min(0.45, Math.log1p(count) * 0.1);
            int color = pixels[i];
            int red = Math.min(255, (int) (((color >> 16) & 255) * brightness));
            int green = Math.min(255, (int) (((color >> 8) & 255) * brightness));
            int blue = Math.min(255, (int) ((color & 255) * brightness));
            pixels[i] = 0xff000000 | red << 16 | green << 8 | blue;
        }

        Graphics2D g = image.createGraphics();
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        drawAxes(g, width, height, xAngle, yAngle, zoom, camera, threeD);
        g.dispose();
        return new RasterFrame(image, pointAtPixel, width, height);
    }

    private static void drawAxes(Graphics2D g, int width, int height,
                                 double xAngle, double yAngle, double zoom,
                                 double camera, boolean threeD) {
        double cosX = Math.cos(Math.toRadians(xAngle)), sinX = Math.sin(Math.toRadians(xAngle));
        double cosY = Math.cos(Math.toRadians(yAngle)), sinY = Math.sin(Math.toRadians(yAngle));
        double[][] ends = threeD
            ? new double[][]{{EXTENT * 1.1, 0, 0}, {0, EXTENT * 1.1, 0}, {0, 0, EXTENT * 1.1}}
            : new double[][]{{EXTENT * 1.1, 0, 0}, {0, EXTENT * 1.1, 0}};
        String[] colors = {"#ff7a45", "#7cf29c", "#6aa8ff"};
        for (int axis = 0; axis < ends.length; axis++) {
            double[] q = ends[axis];
            double[][] endpoints = {{-q[0], -q[1], -q[2]}, q};
            double[] screen = new double[4];
            for (int end = 0; end < 2; end++) {
                double xr = endpoints[end][0] * cosY + endpoints[end][2] * sinY;
                double zr = -endpoints[end][0] * sinY + endpoints[end][2] * cosY;
                double yr = endpoints[end][1] * cosX - zr * sinX;
                double depth = endpoints[end][1] * sinX + zr * cosX;
                double perspective = threeD ? camera / Math.max(camera * 0.35, camera - depth) : 1;
                screen[end * 2] = width / 2.0 + xr * zoom * perspective;
                screen[end * 2 + 1] = height / 2.0 - yr * zoom * perspective;
            }
            g.setColor(java.awt.Color.decode(colors[axis]));
            g.drawLine((int) screen[0], (int) screen[1], (int) screen[2], (int) screen[3]);
        }
    }

    private int pointAt(double x, double y) {
        return hitTest(frame, x, y, plot.getBoundsInLocal().getWidth(), plot.getBoundsInLocal().getHeight());
    }

    static int hitTest(RasterFrame active, double x, double y, double displayWidth, double displayHeight) {
        if (active == null || active.width() == 0 || active.height() == 0
            || displayWidth <= 0 || displayHeight <= 0
            || x < 0 || x >= displayWidth || y < 0 || y >= displayHeight) return -1;
        int cx = (int) (x * active.width() / displayWidth);
        int cy = (int) (y * active.height() / displayHeight);
        int best = -1, distance = Integer.MAX_VALUE;
        for (int dy = -POINT_HIT_RADIUS; dy <= POINT_HIT_RADIUS; dy++)
            for (int dx = -POINT_HIT_RADIUS; dx <= POINT_HIT_RADIUS; dx++) {
                int px = cx + dx, py = cy + dy;
                if (px < 0 || px >= active.width() || py < 0 || py >= active.height()) continue;
                int index = active.pointAtPixel()[py * active.width() + px];
                int d = dx * dx + dy * dy;
                if (index >= 0 && d < distance) { best = index; distance = d; }
            }
        return best;
    }

    private void fitDivider() {
        if (split.getItems().size() < 2) return;
        double total = split.getHeight();
        if (total < 80) return;
        double divider = 10;
        double want = visuals.prefHeight(split.getWidth()) + 6;
        if (want <= 0) return;
        double pos = (total - want - divider) / total;
        pos = Math.max(0.32, Math.min(0.88, pos));
        if (Math.abs(pos - split.getDividerPositions()[0]) > 0.004)
            split.setDividerPositions(pos);
    }

    private void renderCharts(Projection p) {
        if (p.charts() == null || p.charts().isEmpty()) {
            chartsBox.getChildren().add(Ui.muted("This technique has no extra charts — the point cloud is the whole story. "
                + "Hover any point for details."));
            return;
        }
        FlowPane row = new FlowPane(14, 14);
        for (ChartSpec spec : p.charts()) {
            Node chart;
            if ("line".equals(spec.kind())) {
                LineChart<String, Number> lc = Ui.lineChart(spec.title(), 180);
                lc.getData().add(Ui.series(spec.title(), spec.labels(), spec.values()));
                chart = lc;
            } else {
                BarChart<String, Number> bc = Ui.barChart(spec.title(), 180);
                bc.getData().add(Ui.series(spec.title(), spec.labels(), spec.values()));
                chart = bc;
            }
            VBox tile = new VBox(chart);
            tile.getStyleClass().add("chart-tile");
            tile.setPrefWidth(430); tile.setMinWidth(340);
            row.getChildren().add(tile);
        }
        chartsBox.getChildren().add(row);
    }

    private String hoverText(Projection p, int idx) {
        int row = p.rows() != null && idx < p.rows().length ? p.rows()[idx] : idx;
        int lab = p.labels() != null && idx < p.labels().length ? p.labels()[idx] : 0;
        String name = p.legend() != null && lab < p.legend().length ? p.legend()[lab] : "Group " + (lab + 1);
        String info = p.pointInfo() != null && idx < p.pointInfo().length ? p.pointInfo()[idx] : null;
        StringBuilder sb = new StringBuilder();
        sb.append("Row ").append(row + 1).append("  ·  ").append(name);
        if (info != null && !info.isBlank()) sb.append("\n").append(info);
        sb.append("\nclick to inspect all fields");
        return sb.toString();
    }

    private void showPoint(int idx) {
        Projection p = current;
        if (p == null || idx < 0 || idx >= p.points().length) return;
        int row = p.rows() != null && idx < p.rows().length ? p.rows()[idx] : idx;
        int lab = p.labels() != null && idx < p.labels().length ? p.labels()[idx] : 0;
        String labelName = p.legend() != null && lab < p.legend().length ? p.legend()[lab] : "Group " + (lab + 1);
        detailTitle.setText("POINT #" + (idx + 1) + "  ·  SOURCE ROW " + (row + 1));

        List<String[]> fields = new ArrayList<>();
        fields.add(new String[]{"Technique", p.technique() == null ? "—" : p.technique()});
        fields.add(new String[]{"Group", labelName});
        if (p.pointInfo() != null && idx < p.pointInfo().length && p.pointInfo()[idx] != null)
            fields.add(new String[]{"Detail", p.pointInfo()[idx]});
        fields.add(new String[]{"PC 1", Ui.fmt(coord(p.points()[idx], 0))});
        fields.add(new String[]{"PC 2", Ui.fmt(coord(p.points()[idx], 1))});
        fields.add(new String[]{"PC 3", Ui.fmt(coord(p.points()[idx], 2))});
        if (st.hasData() && row >= 0 && row < st.dataset().rowCount()) {
            fields.add(new String[]{"— source row —", "—"});
            for (int c = 0; c < st.dataset().columnCount(); c++)
                fields.add(new String[]{st.dataset().columns().get(c), st.dataset().value(row, c)});
        }
        detailTable.setItems(FXCollections.observableArrayList(fields));
        detailTable.getSelectionModel().clearSelection();
    }

    private static double coord(double[] q, int i) { return i < q.length ? q[i] : 0; }
    private static double clamp(double v) { return Math.max(-EXTENT * 1.5, Math.min(EXTENT * 1.5, v)); }

    /** Scale so the 98th percentile of |coordinate| maps to EXTENT, so a few extreme points don't squash the rest. */
    private static double scaleFor(double[][] pts, int n) {
        double[] abs = new double[n * 3]; int c = 0;
        for (int i = 0; i < n; i++) for (int d = 0; d < 3; d++) abs[c++] = Math.abs(coord(pts[i], d));
        Arrays.sort(abs);
        double ref = abs.length == 0 ? 1 : abs[(int) Math.min(abs.length - 1, Math.floor(abs.length * 0.98))];
        return ref < 1e-9 ? 1 : EXTENT / ref;
    }
}
