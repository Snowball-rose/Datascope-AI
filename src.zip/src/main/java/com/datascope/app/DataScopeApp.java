package com.datascope.app;

import com.datascope.analysis.Profiler;
import com.datascope.app.views.*;
import com.datascope.io.DataLoader;
import com.datascope.model.ColumnProfile;
import com.datascope.model.DataSet;
import com.datascope.util.Async;
import com.datascope.util.Ui;
import javafx.animation.FadeTransition;
import javafx.animation.PauseTransition;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.*;
import javafx.scene.layout.*;
import javafx.stage.FileChooser;
import javafx.stage.Stage;
import javafx.util.Duration;

import java.io.File;
import java.nio.file.Path;
import java.util.*;

/** Application shell: sidebar navigation, top bar, status bar, file loading and drag-and-drop. */
public class DataScopeApp extends Application {
    private record Loaded(DataSet data, List<ColumnProfile> profiles) {}
    private record Page(String title, Node node) {}

    private final AppState state = new AppState();
    private final StackPane content = new StackPane();
    private final Label status = new Label("Ready — open a CSV/XLSX file to begin.");
    private final Label datasetChip = Ui.badge("NO DATA");
    private final Label toast = new Label();
    private final ToggleGroup nav = new ToggleGroup();
    private Stage stage;

    @Override public void start(Stage stage) {
        this.stage = stage;
        stage.setTitle("DataScope AI — tabular data intelligence");
        state.setNotifier(msg -> { status.setText(msg); showToast(msg); });

        OverviewView overview = new OverviewView(state, this::chooseFile, this::loadDemo);
        List<Page> pages = List.of(
            new Page("Overview", overview.node()),
            new Page("Profile", new ProfileView(state).node()),
            new Page("Insights", new InsightsView(state).node()),
            new Page("Clean", new CleanView(state).node()),
            new Page("ML Studio", new MlView(state).node()),
            new Page("Anomalies", new AnomalyView(state).node()),
            new Page("Explorer", new ExplorerView(state).node()),
            new Page("Live Stream", new LiveView(state).node()),
            new Page("Benchmark", new BenchmarkView(state).node()),
            new Page("About", new AboutView().node()));

        VBox sidebar = new VBox(4);
        sidebar.getStyleClass().add("sidebar"); sidebar.setPrefWidth(206); sidebar.setMinWidth(206);
        Label brand = new Label("DATASCOPE AI"); brand.getStyleClass().add("brand");
        Label sub = new Label("tabular intelligence"); sub.getStyleClass().add("subtitle");
        VBox brandBox = new VBox(1, brand, sub); brandBox.setPadding(new Insets(4, 8, 18, 10));
        sidebar.getChildren().add(brandBox);

        List<ToggleButton> buttons = new ArrayList<>();
        for (int i = 0; i < pages.size(); i++) {
            ToggleButton b = new ToggleButton(pages.get(i).title());
            b.setToggleGroup(nav); b.getStyleClass().add("nav-btn"); b.setMaxWidth(Double.MAX_VALUE);
            b.setUserData(pages.get(i).node());
            buttons.add(b); sidebar.getChildren().add(b);
        }
        nav.selectedToggleProperty().addListener((o, a, b) -> {
            if (b == null) { if (a != null) a.setSelected(true); return; }
            Node next = (Node) b.getUserData();
            content.getChildren().setAll(next);
            next.setOpacity(0);
            FadeTransition ft = new FadeTransition(Duration.millis(180), next);
            ft.setFromValue(0); ft.setToValue(1); ft.play();
        });
        buttons.get(0).setSelected(true);
        state.setNavigator(title -> {
            for (int i = 0; i < pages.size(); i++)
                if (pages.get(i).title().equals(title)) { buttons.get(i).setSelected(true); return; }
        });

        Button open = Ui.button("+  Open CSV / XLSX"); open.setOnAction(e -> chooseFile());
        HBox top = new HBox(12, datasetChip, Ui.spacer(), open);
        top.getStyleClass().add("topbar"); top.setAlignment(Pos.CENTER_LEFT);
        status.getStyleClass().add("muted");
        HBox bottom = new HBox(status); bottom.getStyleClass().add("status-bar");

        BorderPane shell = new BorderPane();
        shell.getStyleClass().add("app");
        shell.setLeft(sidebar); shell.setTop(top); shell.setCenter(content); shell.setBottom(bottom);

        toast.getStyleClass().add("toast");
        toast.setMouseTransparent(true);
        toast.setOpacity(0);
        toast.setMaxWidth(420);
        toast.setWrapText(true);
        StackPane.setAlignment(toast, Pos.TOP_RIGHT);
        StackPane.setMargin(toast, new Insets(64, 28, 0, 0));
        StackPane rootStack = new StackPane(shell, toast);

        Scene scene = new Scene(rootStack, 1380, 880);
        scene.getStylesheets().add(Objects.requireNonNull(getClass().getResource("/datascope.css")).toExternalForm());
        scene.getAccelerators().put(new KeyCodeCombination(KeyCode.O, KeyCombination.SHORTCUT_DOWN), this::chooseFile);
        for (int i = 0; i < Math.min(9, buttons.size()); i++) {
            final ToggleButton target = buttons.get(i);
            scene.getAccelerators().put(new KeyCodeCombination(KeyCode.valueOf("DIGIT" + (i + 1)), KeyCombination.SHORTCUT_DOWN), () -> target.setSelected(true));
        }
        enableDrop(scene);

        state.onData(() -> datasetChip.setText(state.hasData()
            ? state.dataset().name() + "   ·   " + state.dataset().rowCount() + " rows × " + state.dataset().columnCount() + " cols" + (state.isModified() ? "   ·   cleaned copy" : "")
            : "NO DATA"));

        stage.setScene(scene); stage.setMinWidth(1100); stage.setMinHeight(700); stage.show();
        // The sample dataset is intentionally NOT loaded automatically — the user chooses a file
        // (or presses "Load demo data" on the Overview page) so the workspace always starts empty.
    }

    private void showToast(String message) {
        toast.setText(message);
        toast.setOpacity(0);
        FadeTransition in = new FadeTransition(Duration.millis(200), toast);
        in.setFromValue(0); in.setToValue(1);
        in.setOnFinished(e -> {
            PauseTransition hold = new PauseTransition(Duration.seconds(2.8));
            hold.setOnFinished(e2 -> {
                FadeTransition out = new FadeTransition(Duration.millis(400), toast);
                out.setFromValue(1); out.setToValue(0); out.play();
            });
            hold.play();
        });
        in.play();
    }

    private void loadDemo() {
        status.setText("Loading demo data…");
        Async.run(() -> {
            DataSet ds = DataLoader.loadCsvResource("/sample_customer_data.csv", "sample_customer_data.csv");
            return new Loaded(ds, Profiler.profile(ds));
        }, l -> { finishLoad(l); state.notify("Demo dataset loaded — " + l.data().rowCount() + " rows."); },
            err -> status.setText("Could not load demo data: " + err.getMessage()));
    }

    private void chooseFile() {
        FileChooser fc = new FileChooser();
        fc.setTitle("Open a CSV or XLSX file");
        fc.getExtensionFilters().add(new FileChooser.ExtensionFilter("Tabular files", "*.csv", "*.xlsx"));
        File f = fc.showOpenDialog(stage);
        if (f != null) loadFile(f.toPath());
    }

    private void loadFile(Path path) {
        String name = path.getFileName().toString().toLowerCase(Locale.ROOT);
        if (!name.endsWith(".csv") && !name.endsWith(".xlsx")) { status.setText("Unsupported file type — use .csv or .xlsx."); return; }
        status.setText("Loading " + path.getFileName() + "…");
        Async.run(() -> {
            DataSet ds = DataLoader.load(path);
            if (ds.columnCount() == 0) throw new IllegalStateException("The file has no columns.");
            return new Loaded(ds, Profiler.profile(ds));
        }, this::finishLoad, err -> status.setText("Could not load file: " + err.getMessage()));
    }

    private void finishLoad(Loaded l) {
        state.load(l.data(), l.profiles());
        status.setText("Loaded " + l.data().name() + " — " + l.data().rowCount() + " rows, " + l.data().columnCount() + " columns.");
    }

    private void enableDrop(Scene scene) {
        scene.setOnDragOver(e -> { if (e.getDragboard().hasFiles()) e.acceptTransferModes(TransferMode.COPY); e.consume(); });
        scene.setOnDragDropped(e -> {
            Dragboard db = e.getDragboard();
            boolean ok = db.hasFiles() && !db.getFiles().isEmpty();
            if (ok) loadFile(db.getFiles().get(0).toPath());
            e.setDropCompleted(ok); e.consume();
        });
    }

    public static void main(String[] args) { launch(args); }
}
