package com.datascope.app;
public class Launcher { public static void main(String[] args){ DataScopeApp.main(args); } }
