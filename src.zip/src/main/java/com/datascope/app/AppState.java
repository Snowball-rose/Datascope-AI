package com.datascope.app;

import com.datascope.model.*;
import javafx.scene.paint.Color;

import java.util.*;
import java.util.function.Consumer;

/** Shared, observable application state. Views register listeners and refresh themselves. */
public final class AppState {
    /**
     * A full-row 2D/3D point cloud published by ML Studio / Anomaly Lab for the Explorer.
     *
     * @param points     xyz coordinates (PCA space)
     * @param labels     class/cluster label per point (index into {@code legend}/{@code colors})
     * @param rows       source dataset row per point, so a clicked point can be traced back
     * @param legend     human-readable name per label
     * @param colors     optional explicit colour per label (falls back to {@link com.datascope.util.Ui#color(int)})
     * @param title      headline shown in the Explorer
     * @param technique  which technique produced this cloud ("K-Means", "PCA", "Logistic regression", …)
     * @param pointInfo  optional per-point detail string (e.g. "P(churn)=0.83")
     * @param charts     technique-specific charts the Explorer should render next to the cloud
     */
    public record Projection(double[][] points, int[] labels, int[] rows, String[] legend, Color[] colors,
                             String title, String technique, String[] pointInfo, List<ChartSpec> charts) {
        /** A lightweight chart description the Explorer can render without depending on ML classes. */
        public record ChartSpec(String title, String kind, List<String> labels, List<Double> values) {
            public static ChartSpec bar(String title, List<String> labels, List<Double> values) { return new ChartSpec(title, "bar", labels, values); }
            public static ChartSpec line(String title, List<String> labels, List<Double> values) { return new ChartSpec(title, "line", labels, values); }
        }

        public static Projection of(double[][] points, int[] labels, int[] rows, String[] legend, Color[] colors,
                                    String title, String technique, String[] pointInfo, List<ChartSpec> charts) {
            return new Projection(points, labels, rows, legend, colors, title, technique, pointInfo, charts);
        }
    }

    private DataSet original = new DataSet("Empty", List.of(), List.of());
    private DataSet dataset = original;
    private List<ColumnProfile> originalProfiles = List.of();
    private List<ColumnProfile> profiles = List.of();
    private Projection projection;
    private final List<String> history = new ArrayList<>();
    private final List<Runnable> dataListeners = new ArrayList<>();
    private final List<Runnable> projectionListeners = new ArrayList<>();
    private Consumer<String> notifier = s -> {};
    private Consumer<String> navigator = page -> {};

    public DataSet dataset() { return dataset; }
    public List<ColumnProfile> profiles() { return profiles; }
    public Projection projection() { return projection; }
    public List<String> history() { return Collections.unmodifiableList(history); }
    public boolean hasData() { return dataset.rowCount() > 0; }
    public boolean isModified() { return dataset != original; }

    public void onData(Runnable r) { dataListeners.add(r); }
    public void onProjection(Runnable r) { projectionListeners.add(r); }
    public void setNotifier(Consumer<String> n) { notifier = n; }
    public void notify(String message) { notifier.accept(message); }
    /** Views call this to jump to another page by its title (e.g. "Explorer"). */
    public void setNavigator(Consumer<String> n) { navigator = n; }
    public void navigate(String page) { navigator.accept(page); }

    /** Load a brand-new dataset (profiles computed by the caller, usually off the UI thread). */
    public void load(DataSet ds, List<ColumnProfile> ps) {
        original = ds; dataset = ds; originalProfiles = ps; profiles = ps; projection = null; history.clear();
        dataListeners.forEach(Runnable::run); projectionListeners.forEach(Runnable::run);
    }

    /** Apply a cleaned working copy. */
    public void apply(DataSet cleaned, List<ColumnProfile> cleanedProfiles, String logLine) {
        dataset = cleaned; profiles = cleanedProfiles; projection = null;
        if (logLine != null) history.add(logLine);
        dataListeners.forEach(Runnable::run); projectionListeners.forEach(Runnable::run);
    }

    public void resetToOriginal() {
        dataset = original; profiles = originalProfiles; projection = null; history.clear();
        dataListeners.forEach(Runnable::run); projectionListeners.forEach(Runnable::run);
    }

    public void setProjection(Projection p) { projection = p; projectionListeners.forEach(Runnable::run); }

    // ---- derived helpers -------------------------------------------------

    public List<Integer> numericIndexes() {
        List<Integer> out = new ArrayList<>();
        for (int i = 0; i < profiles.size(); i++) if (profiles.get(i).type() == ColumnType.NUMERIC) out.add(i);
        return out;
    }

    public List<String> numericNames() {
        return numericIndexes().stream().map(i -> dataset.columns().get(i)).toList();
    }

    /** Dense feature matrix with missing cells mean-imputed. Column means are computed once per column. */
    public double[][] matrix(List<Integer> cols, int maxRows) {
        return matrix(dataset, cols, maxRows);
    }

    public static double[][] matrix(DataSet dataset, List<Integer> cols, int maxRows) {
        int n = Math.min(dataset.rowCount(), maxRows);
        double[] sums = new double[cols.size()];
        int[] counts = new int[cols.size()];
        double[][] x = new double[n][cols.size()];
        boolean[][] missing = new boolean[n][cols.size()];
        for (int i = 0; i < dataset.rowCount(); i++) {
            List<String> row = dataset.row(i);
            for (int j = 0; j < cols.size(); j++) {
                int col = cols.get(j);
                Double value = DataSet.parseDouble(col < row.size() ? row.get(col) : "");
                if (value != null) {
                    sums[j] += value;
                    counts[j]++;
                    if (i < n) x[i][j] = value;
                } else if (i < n) {
                    missing[i][j] = true;
                }
            }
        }
        double[] means = new double[cols.size()];
        for (int j = 0; j < cols.size(); j++) means[j] = counts[j] == 0 ? 0 : sums[j] / counts[j];

        for (int i = 0; i < n; i++) {
            for (int j = 0; j < cols.size(); j++)
                if (missing[i][j]) x[i][j] = means[j];
        }
        return x;
    }

}
