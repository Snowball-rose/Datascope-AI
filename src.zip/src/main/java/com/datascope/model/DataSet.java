package com.datascope.model;

import java.io.*;
import java.nio.ByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.locks.ReentrantReadWriteLock;

public class DataSet implements AutoCloseable {
    private final String name;
    private final List<String> columns;
    private final List<List<String>> rows;
    private final RowStore store;

    public DataSet(String name, List<String> columns, List<List<String>> rows) {
        this.name = Objects.requireNonNull(name);
        this.columns = List.copyOf(columns);
        List<List<String>> copy = rows.stream().map(List::copyOf).toList();
        this.rows = copy;
        this.store = null;
    }

    private DataSet(String name, List<String> columns, RowStore store) {
        this.name = Objects.requireNonNull(name);
        this.columns = List.copyOf(columns);
        this.store = store;
        this.rows = new AbstractList<>() {
            @Override public List<String> get(int index) { return store.get(index); }
            @Override public int size() { return store.size(); }
        };
    }

    /** Writes rows incrementally to a temporary indexed store instead of retaining every cell in heap. */
    public static DataSet fromRows(String name, List<String> columns, Iterable<List<String>> source) {
        try (DiskWriter writer = newWriter(name, columns)) {
            for (List<String> row : source) writer.addRow(row);
            return writer.build();
        } catch (IOException e) {
            throw new UncheckedIOException("Could not create disk-backed dataset", e);
        }
    }

    public static DiskWriter newWriter(String name, List<String> columns) throws IOException {
        return new DiskWriter(name, columns);
    }

    public String name() { return name; }
    public List<String> columns() { return columns; }
    public List<List<String>> rows() { return rows; }
    public int rowCount() { return store == null ? rows.size() : store.size(); }
    public int columnCount() { return columns.size(); }
    public List<String> row(int index) { return rows.get(index); }
    public String value(int row, int col) {
        if (store != null && col >= 0) return store.getValue(row, col);
        List<String> values = row(row);
        return values.size() > col ? values.get(col) : "";
    }

    public ColumnType inferType(int col) {
        int numeric = 0, nonEmpty = 0, bools = 0, dateLike = 0;
        for (int r = 0; r < rowCount(); r++) {
            String v = value(r, col).trim();
            if (v.isEmpty()) continue;
            nonEmpty++;
            if (parseDouble(v) != null) numeric++;
            if (v.equalsIgnoreCase("true") || v.equalsIgnoreCase("false") || v.equals("0") || v.equals("1")) bools++;
            if (v.matches("\\d{4}[-/]\\d{1,2}[-/]\\d{1,2}.*")) dateLike++;
        }
        if (nonEmpty == 0) return ColumnType.TEXT;
        if ((long) numeric * 100 >= (long) nonEmpty * 90) return ColumnType.NUMERIC;
        if ((long) bools * 100 >= (long) nonEmpty * 95) return ColumnType.BOOLEAN;
        if ((long) dateLike * 100 >= (long) nonEmpty * 85) return ColumnType.DATETIME;
        double categoricalLimit = Math.max(25, rowCount() * 0.05);
        if (uniqueCountUpTo(col, (int) Math.floor(categoricalLimit) + 1) <= categoricalLimit) return ColumnType.CATEGORICAL;
        return ColumnType.TEXT;
    }

    public double[] numericColumn(int col) {
        double[] out = new double[rowCount()];
        for (int i = 0; i < out.length; i++) {
            Double value = parseDouble(value(i, col));
            out[i] = value == null ? Double.NaN : value;
        }
        return out;
    }

    public static Double parseDouble(String s) {
        if (s == null || s.isBlank()) return null;
        try { return Double.parseDouble(s.trim().replace(",", "")); }
        catch (NumberFormatException e) { return null; }
    }

    public int uniqueCount(int col) {
        Set<String> set = new HashSet<>();
        for (List<String> row : rows) if (row.size() > col && !row.get(col).isBlank()) set.add(row.get(col));
        return set.size();
    }

    private int uniqueCountUpTo(int col, int limit) {
        Set<String> set = new HashSet<>();
        for (List<String> row : rows) {
            if (row.size() > col && !row.get(col).isBlank()) {
                set.add(row.get(col));
                if (set.size() >= limit) return limit;
            }
        }
        return set.size();
    }

    @Override public void close() {
        if (store != null) store.close();
    }

    private interface RowStore {
        List<String> get(int index);
        String getValue(int index, int column);
        int size();
        void close();
    }

    public static final class DiskWriter implements AutoCloseable {
        private final String name;
        private final List<String> columns;
        private final Path path;
        private final LongOffsets offsets = new LongOffsets();
        private DataOutputStream out;
        private long offset;
        private boolean built;

        private DiskWriter(String name, List<String> columns) throws IOException {
            this.name = Objects.requireNonNull(name);
            this.columns = List.copyOf(columns);
            this.path = Files.createTempFile("datascope-", ".rows");
            try { this.out = new DataOutputStream(new BufferedOutputStream(Files.newOutputStream(path))); }
            catch (IOException e) {
                try { Files.deleteIfExists(path); } catch (IOException cleanup) { e.addSuppressed(cleanup); }
                throw e;
            }
        }

        public void addRow(List<String> row) throws IOException {
            if (out == null) throw new IllegalStateException("Dataset writer is closed.");
            offsets.add(offset);
            out.writeInt(row.size());
            offset += Integer.BYTES;
            for (String value : row) {
                byte[] bytes = (value == null ? "" : value).getBytes(StandardCharsets.UTF_8);
                out.writeInt(bytes.length);
                out.write(bytes);
                offset += Integer.BYTES + bytes.length;
            }
        }

        public DataSet build() throws IOException {
            if (out == null) throw new IllegalStateException("Dataset writer is closed.");
            out.close();
            out = null;
            path.toFile().deleteOnExit();
            DataSet result = new DataSet(name, columns, new FileRowStore(path, offsets.toArray()));
            built = true;
            return result;
        }

        @Override public void close() throws IOException {
            IOException failure = null;
            if (out != null) {
                try { out.close(); } catch (IOException e) { failure = e; }
                out = null;
            }
            if (!built) {
                try { Files.deleteIfExists(path); }
                catch (IOException e) { if (failure == null) failure = e; else failure.addSuppressed(e); }
            }
            if (failure != null) throw failure;
        }
    }

    private static final class FileRowStore implements RowStore {
        private final Path path;
        private final long[] offsets;
        private final FileChannel channel;
        private final long fileSize;
        private final ReentrantReadWriteLock lifecycle = new ReentrantReadWriteLock();
        private boolean closed;

        private FileRowStore(Path path, long[] offsets) throws IOException {
            this.path = path;
            this.offsets = offsets;
            this.channel = FileChannel.open(path, StandardOpenOption.READ);
            this.fileSize = channel.size();
        }

        @Override public List<String> get(int index) {
            Objects.checkIndex(index, offsets.length);
            var lock = lifecycle.readLock();
            lock.lock();
            try {
                if (closed) throw new IllegalStateException("Dataset storage is closed.");
                byte[] data = readRowBytes(index);
                ByteBuffer rowData = ByteBuffer.wrap(data);
                int count = rowData.getInt();
                if (count < 0) throw new IOException("Invalid row data.");
                List<String> row = new ArrayList<>(count);
                for (int i = 0; i < count; i++) {
                    int length = rowData.getInt();
                    if (length < 0) throw new IOException("Invalid row data.");
                    if (length > rowData.remaining()) throw new IOException("Invalid row data.");
                    int start = rowData.position();
                    row.add(new String(data, start, length, StandardCharsets.UTF_8));
                    rowData.position(start + length);
                }
                return List.copyOf(row);
            } catch (IOException e) {
                throw new UncheckedIOException("Could not read dataset row " + (index + 1), e);
            } finally {
                lock.unlock();
            }
        }

        @Override public String getValue(int index, int column) {
            Objects.checkIndex(index, offsets.length);
            var lock = lifecycle.readLock();
            lock.lock();
            try {
                if (closed) throw new IllegalStateException("Dataset storage is closed.");
                byte[] data = readRowBytes(index);
                ByteBuffer rowData = ByteBuffer.wrap(data);
                int count = rowData.getInt();
                if (count < 0) throw new IOException("Invalid row data.");
                if (column >= count) return "";
                for (int i = 0; i < count; i++) {
                    int length = rowData.getInt();
                    if (length < 0) throw new IOException("Invalid row data.");
                    if (length > rowData.remaining()) throw new IOException("Invalid row data.");
                    if (i == column) {
                        return new String(data, rowData.position(), length, StandardCharsets.UTF_8);
                    }
                    rowData.position(rowData.position() + length);
                }
                return "";
            } catch (IOException e) {
                throw new UncheckedIOException("Could not read dataset row " + (index + 1), e);
            } finally {
                lock.unlock();
            }
        }

        private byte[] readRowBytes(int index) throws IOException {
            long start = offsets[index];
            long end = index + 1 < offsets.length ? offsets[index + 1] : fileSize;
            long length = end - start;
            if (length < Integer.BYTES || length > Integer.MAX_VALUE)
                throw new IOException("Invalid row data.");
            ByteBuffer buffer = ByteBuffer.allocate((int) length);
            readFully(buffer, start);
            return buffer.array();
        }

        private void readFully(ByteBuffer buffer, long position) throws IOException {
            while (buffer.hasRemaining()) {
                int count = channel.read(buffer, position);
                if (count < 0) throw new EOFException("Unexpected end of dataset row data.");
                if (count > 0) position += count;
            }
        }

        @Override public int size() { return offsets.length; }

        @Override public void close() {
            var lock = lifecycle.writeLock();
            lock.lock();
            try {
                if (closed) return;
                IOException failure = null;
                try { channel.close(); }
                catch (IOException e) { failure = e; }
                try { Files.deleteIfExists(path); }
                catch (IOException e) {
                    if (failure == null) failure = e;
                    else failure.addSuppressed(e);
                }
                closed = true;
                if (failure != null) throw failure;
            } catch (IOException e) {
                throw new UncheckedIOException("Could not close dataset storage", e);
            } finally {
                lock.unlock();
            }
        }
    }

    private static final class LongOffsets {
        private long[] values = new long[1024];
        private int size;
        void add(long value) {
            if (size == values.length) values = Arrays.copyOf(values, Math.multiplyExact(values.length, 2));
            values[size++] = value;
        }
        long[] toArray() { return Arrays.copyOf(values, size); }
    }
}
