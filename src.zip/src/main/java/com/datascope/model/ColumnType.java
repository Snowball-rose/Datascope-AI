package com.datascope.model;
public enum ColumnType { NUMERIC, CATEGORICAL, TEXT, BOOLEAN, DATETIME }
