package com.datascope.model;

public record ColumnProfile(
    String name, ColumnType type, int missing, int unique, double mean,
    double min, double max, double stdDev, String sample, double missingPct) {}
