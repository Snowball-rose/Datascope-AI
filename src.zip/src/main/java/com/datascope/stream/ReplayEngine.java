package com.datascope.stream;

import com.datascope.model.DataSet;

import java.util.concurrent.*;
import java.util.concurrent.atomic.*;
import java.util.function.IntConsumer;

/** Producer/consumer row replay with a bounded queue. Rows are dropped (and counted) when the queue is full. */
public class ReplayEngine {
    private volatile ArrayBlockingQueue<Integer> queue = new ArrayBlockingQueue<>(5000);
    private final AtomicLong processed = new AtomicLong();
    private final AtomicLong dropped = new AtomicLong();
    private final AtomicBoolean running = new AtomicBoolean();
    private final AtomicBoolean paused = new AtomicBoolean();
    private final AtomicBoolean producerDone = new AtomicBoolean();
    private volatile ExecutorService executor;
    private volatile int rate = 1000;

    public void start(DataSet data, int rowsPerSecond, IntConsumer consumer, Runnable onComplete) {
        start(data, rowsPerSecond, 5000, consumer, onComplete);
    }

    public void start(DataSet data, int rowsPerSecond, int queueCapacity, IntConsumer consumer, Runnable onComplete) {
        stop();
        rate = Math.max(1, rowsPerSecond);
        queue = new ArrayBlockingQueue<>(Math.max(1, queueCapacity));
        processed.set(0); dropped.set(0); paused.set(false); producerDone.set(false); running.set(true);
        ExecutorService ex = Executors.newFixedThreadPool(2, r -> { Thread t = new Thread(r, "datascope-stream"); t.setDaemon(true); return t; });
        executor = ex;
        final ArrayBlockingQueue<Integer> q = queue;
        ex.submit(() -> producer(data, q));
        ex.submit(() -> consumerLoop(q, consumer, onComplete));
    }

    public void setRate(int r) { rate = Math.max(1, r); }
    public void pause() { paused.set(true); }
    public void resume() { paused.set(false); }
    public boolean isPaused() { return paused.get(); }
    public boolean isRunning() { return running.get(); }

    public void stop() {
        running.set(false);
        ExecutorService ex = executor;
        if (ex != null) { ex.shutdownNow(); executor = null; }
        queue.clear();
    }

    public long processed() { return processed.get(); }
    public long dropped() { return dropped.get(); }
    public int queueSize() { return queue.size(); }
    public int capacity() { ArrayBlockingQueue<Integer> q = queue; return q.remainingCapacity() + q.size(); }

    private void producer(DataSet data, ArrayBlockingQueue<Integer> q) {
        long next = System.nanoTime();
        try {
            for (int i = 0; i < data.rowCount() && running.get(); i++) {
                while (paused.get() && running.get()) { sleep(20); next = System.nanoTime(); }
                if (!q.offer(i)) dropped.incrementAndGet();
                next += 1_000_000_000L / Math.max(1, rate);
                long wait = next - System.nanoTime();
                if (wait > 0) sleepNanos(wait); else next = System.nanoTime();
            }
        } finally { producerDone.set(true); }
    }

    private void consumerLoop(ArrayBlockingQueue<Integer> q, IntConsumer consumer, Runnable onComplete) {
        boolean finished = false;
        try {
            while (running.get()) {
                if (paused.get()) { sleep(20); continue; }
                Integer idx = q.poll(100, TimeUnit.MILLISECONDS);
                if (idx != null) { consumer.accept(idx); processed.incrementAndGet(); }
                else if (producerDone.get()) { finished = true; break; }
            }
        } catch (InterruptedException ignored) {
            Thread.currentThread().interrupt();
        } finally {
            if (finished) running.set(false);
            if (finished && onComplete != null) onComplete.run();
        }
    }

    private static void sleep(long ms) { try { Thread.sleep(ms); } catch (InterruptedException e) { Thread.currentThread().interrupt(); } }
    private static void sleepNanos(long nanos) {
        try { Thread.sleep(nanos / 1_000_000, (int) (nanos % 1_000_000)); } catch (InterruptedException e) { Thread.currentThread().interrupt(); }
    }
}
