package com.datascope.util;

import javafx.application.Platform;

import java.util.concurrent.*;
import java.util.function.Consumer;

/** Runs work off the JavaFX thread and delivers the result back on it. */
public final class Async {
    private static final ExecutorService POOL = Executors.newFixedThreadPool(3, r -> {
        Thread t = new Thread(r, "datascope-worker"); t.setDaemon(true); return t;
    });
    private Async() {}

    public static <T> void run(Callable<T> work, Consumer<T> ok, Consumer<Throwable> fail) {
        POOL.submit(() -> {
            try { T r = work.call(); Platform.runLater(() -> ok.accept(r)); }
            catch (Throwable e) { Platform.runLater(() -> fail.accept(e)); }
        });
    }
}
