package com.datascope.util;

import javafx.geometry.Insets;
import javafx.geometry.Point2D;
import javafx.geometry.Pos;
import javafx.scene.Node;
import javafx.scene.chart.*;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.util.Duration;

import java.util.List;

public final class Ui {
    private Ui() {}

    /*
     * One spacing scale for the whole application. Every page, card, tile and form field is laid
     * out from these five numbers, so the vertical rhythm is identical everywhere instead of each
     * view inventing its own gaps. PAD_CARD mirrors `.card` in datascope.css.
     */
    public static final double GAP_BLOCK = 20;   // between blocks on a page
    public static final double GAP_CARD  = 16;   // card title to card body
    public static final double GAP_ROW   = 14;   // between tiles in a row
    public static final double GAP_TIGHT = 6;    // label to its control
    public static final double PAD_PAGE  = 30;   // page padding

    public static VBox card(String title, Node content) {
        Label l = new Label(title); l.getStyleClass().add("card-title");
        VBox box = new VBox(GAP_CARD, l, content); box.getStyleClass().add("card");
        VBox.setVgrow(content, Priority.ALWAYS);
        return box;
    }

    /** A single KPI tile. */
    public static VBox metric(String label, String value) {
        Label a = new Label(label); a.getStyleClass().add("metric-label");
        Label b = new Label(value); b.getStyleClass().add("metric-value");
        VBox v = new VBox(6, a, b); v.getStyleClass().add("metric");
        HBox.setHgrow(v, Priority.ALWAYS); v.setMaxWidth(Double.MAX_VALUE);
        return v;
    }

    /** A tile whose value can be updated later. */
    public static VBox liveMetric(String label, Label valueLabel) {
        Label a = new Label(label); a.getStyleClass().add("metric-label");
        valueLabel.getStyleClass().add("metric-value");
        VBox v = new VBox(6, a, valueLabel); v.getStyleClass().add("metric");
        HBox.setHgrow(v, Priority.ALWAYS); v.setMaxWidth(Double.MAX_VALUE);
        return v;
    }

    public static HBox metricRow(VBox... tiles) {
        HBox h = new HBox(GAP_ROW, tiles);
        h.setAlignment(Pos.CENTER_LEFT);
        return h;
    }

    /** A labelled 0..1 progress meter used by the quality breakdown. */
    public static VBox meter(String label, double fraction, String valueText) {
        Label l = new Label(label); l.getStyleClass().add("metric-label");
        Label v = new Label(valueText); v.getStyleClass().add("meter-value");
        Region spacer = spacer();
        HBox top = new HBox(8, l, spacer, v); top.setAlignment(Pos.CENTER_LEFT);
        ProgressBar bar = new ProgressBar(Math.max(0, Math.min(1, fraction)));
        bar.setMaxWidth(Double.MAX_VALUE);
        bar.setPrefHeight(7);
        bar.getStyleClass().add(fraction >= 0.9 ? "meter-good" : fraction >= 0.7 ? "meter-warn" : "meter-bad");
        VBox box = new VBox(7, top, bar);
        box.setFillWidth(true);
        HBox.setHgrow(box, Priority.ALWAYS); box.setMaxWidth(Double.MAX_VALUE);
        return box;
    }

    /** A dark-themed tooltip that also works inside popup scenes that don't inherit the app stylesheet. */
    public static Tooltip tooltip(String text) {
        Tooltip t = new Tooltip(text);
        t.setStyle("-fx-background-color:#0b1018; -fx-border-color:#2b4a6b; -fx-text-fill:#eef6ff; -fx-font-size:12px;");
        return t;
    }

    public static Label badge(String text) { Label l = new Label(text); l.getStyleClass().add("badge"); return l; }
    public static Label chip(String text) { Label l = new Label(text); l.getStyleClass().add("chip"); return l; }
    public static Label muted(String text) { Label l = new Label(text); l.getStyleClass().add("muted"); l.setWrapText(true); return l; }
    public static Label heading(String text) { Label l = new Label(text); l.getStyleClass().add("page-title"); return l; }

    public static Button button(String text) { Button b = new Button(text); b.getStyleClass().add("primary"); return b; }
    public static Button ghost(String text) { Button b = new Button(text); b.getStyleClass().add("ghost"); return b; }

    public static ScrollPane scroll(Node n) {
        ScrollPane s = new ScrollPane(n); s.setFitToWidth(true); s.getStyleClass().add("edge-to-edge"); return s;
    }

    /** Standard page wrapper: title, subtitle, then content blocks. */
    public static ScrollPane page(String title, String subtitle, Node... blocks) {
        VBox box = new VBox(GAP_BLOCK); box.setPadding(new Insets(PAD_PAGE, PAD_PAGE + 2, PAD_PAGE + 6, PAD_PAGE + 2));
        VBox head = new VBox(7, heading(title), muted(subtitle));
        box.getChildren().add(head);
        box.getChildren().addAll(blocks);
        return scroll(box);
    }

    public static Node field(String label, Node control) {
        Label l = new Label(label); l.getStyleClass().add("field-label");
        VBox v = new VBox(GAP_TIGHT, l, control); return v;
    }

    public static Color color(int i) { return Color.hsb(((i * 67) + 190) % 360, 0.62, 1.0); }

    public static String hex(Color c) {
        return String.format("#%02x%02x%02x", (int) Math.round(c.getRed() * 255), (int) Math.round(c.getGreen() * 255), (int) Math.round(c.getBlue() * 255));
    }

    public static String fmt(double v) {
        if (!Double.isFinite(v)) return "—";
        if (v == Math.rint(v) && Math.abs(v) < 1e9) return String.valueOf((long) v);
        return Math.abs(v) >= 1000 ? String.format("%,.1f", v) : String.format("%.3f", v);
    }

    public static BarChart<String, Number> barChart(String title, double height) {
        CategoryAxis x = new CategoryAxis(); NumberAxis y = new NumberAxis();
        BarChart<String, Number> c = new BarChart<>(x, y);
        c.setTitle(title); c.setAnimated(false); c.setLegendVisible(false); c.setPrefHeight(height); c.setMinHeight(height);
        c.setCategoryGap(6);
        attachHover(c);
        return c;
    }

    public static LineChart<String, Number> lineChart(String title, double height) {
        LineChart<String, Number> c = new LineChart<>(new CategoryAxis(), new NumberAxis());
        c.setTitle(title); c.setAnimated(false); c.setLegendVisible(false); c.setPrefHeight(height); c.setMinHeight(height);
        attachHover(c);
        return c;
    }

    public static XYChart.Series<String, Number> series(String name, List<String> labels, List<? extends Number> values) {
        XYChart.Series<String, Number> s = new XYChart.Series<>(); s.setName(name);
        for (int i = 0; i < labels.size(); i++) s.getData().add(new XYChart.Data<>(labels.get(i), values.get(i)));
        return s;
    }

    public static Region spacer() { Region r = new Region(); HBox.setHgrow(r, Priority.ALWAYS); return r; }

    public static Node emptyState(String message) {
        Label l = new Label(message); l.getStyleClass().add("muted"); l.setWrapText(true);
        VBox v = new VBox(l); v.setAlignment(Pos.CENTER); v.setPadding(new Insets(48)); return v;
    }

    // ---- chart hover -------------------------------------------------------

    /**
     * Installs a floating tooltip on any {@link XYChart}. Moving the mouse anywhere over the chart
     * finds the nearest data point (numeric or category axis) and shows its series, x and y values —
     * or a custom detail string if the point carries one via {@link XYChart.Data#setExtraValue(Object)}.
     */
    public static void attachHover(XYChart<?, ?> chart) {
        Tooltip tip = tooltip("");
        tip.setShowDelay(Duration.millis(60));
        tip.setHideDelay(Duration.millis(30));
        tip.setShowDuration(Duration.seconds(60));
        Tooltip.install(chart, tip);
        chart.addEventHandler(MouseEvent.MOUSE_MOVED, e -> {
            String text = describe(chart, e);
            if (text == null || text.isBlank()) { tip.setText(""); tip.hide(); return; }
            tip.setText(text);
        });
        chart.addEventHandler(MouseEvent.MOUSE_EXITED, e -> tip.hide());
    }

    private static String describe(XYChart<?, ?> chart, MouseEvent e) {
        Axis<?> xa = chart.getXAxis(), ya = chart.getYAxis();
        if (xa == null || ya == null) return null;
        Object xv = valueAt(xa, xa.sceneToLocal(e.getSceneX(), e.getSceneY()).getX(), true);
        Object yv = valueAt(ya, ya.sceneToLocal(e.getSceneX(), e.getSceneY()).getY(), false);
        if (xv == null || yv == null) return null;

        XYChart.Data<?, ?> best = null; double bestDist = Double.MAX_VALUE; String bestSeries = "";
        for (Object sObj : chart.getData()) {
            XYChart.Series<?, ?> s = (XYChart.Series<?, ?>) sObj;
            for (Object dObj : s.getData()) {
                XYChart.Data<?, ?> d = (XYChart.Data<?, ?>) dObj;
                double dx = distance(xa, xv, d.getXValue());
                double dy = distance(ya, yv, d.getYValue());
                double dist = dx * dx + dy * dy;
                if (dist < bestDist) { bestDist = dist; best = d; bestSeries = s.getName(); }
            }
        }
        if (best == null) return null;
        Object extra = best.getExtraValue();
        if (extra != null) return String.valueOf(extra);
        String name = (bestSeries == null || bestSeries.isBlank()) ? "" : bestSeries + ":  ";
        return name + String.valueOf(best.getXValue()) + "  →  " + valueText(best.getYValue());
    }

    private static Object valueAt(Axis<?> axis, double localPos, boolean horizontal) {
        try {
            if (axis instanceof CategoryAxis ca) {
                List<String> cats = ca.getCategories();
                if (cats.isEmpty()) return null;
                double size = horizontal ? ca.getWidth() : ca.getHeight();
                if (size <= 0) return null;
                double frac = Math.max(0, Math.min(0.9999, localPos / size));
                return cats.get((int) (frac * cats.size()));
            }
            return axis.getValueForDisplay(localPos);
        } catch (Exception ex) { return null; }
    }

    private static double distance(Axis<?> axis, Object target, Object value) {
        if (axis instanceof CategoryAxis) return String.valueOf(target).equals(String.valueOf(value)) ? 0 : 1.0;
        double t = toDouble(target), v = toDouble(value);
        if (!Double.isFinite(t) || !Double.isFinite(v)) return 1e9;
        double range = 1;
        if (axis instanceof NumberAxis na) range = Math.abs(na.getUpperBound() - na.getLowerBound());
        if (range <= 0) range = 1;
        return Math.abs(t - v) / range;
    }

    private static double toDouble(Object o) {
        if (o instanceof Number n) return n.doubleValue();
        try { return Double.parseDouble(String.valueOf(o)); } catch (Exception e) { return Double.NaN; }
    }

    private static String valueText(Object o) {
        if (o instanceof Number n) return fmt(n.doubleValue());
        return String.valueOf(o);
    }
}
