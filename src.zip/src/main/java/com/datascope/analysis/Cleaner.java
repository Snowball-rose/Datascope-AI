package com.datascope.analysis;

import com.datascope.ml.Stats;
import com.datascope.model.DataSet;

import java.util.*;

/** Pure cleaning operations. Each returns a new DataSet; the input is never modified. */
public final class Cleaner {
    private Cleaner() {}

    /** A single cell that a cleaning step would change (used by the Clean preview). */
    public record Change(int row, String column, String before, String after) {}

    public record Outcome(DataSet data, String message, int changed, List<Change> changes) {}

    public static Outcome dropDuplicates(DataSet ds) {
        Set<List<String>> seen = new HashSet<>();
        List<Change> changes = new ArrayList<>();
        int[] removed = {0}, rowIndex = {0};
        Iterable<List<String>> output = () -> new Iterator<>() {
            private final Iterator<List<String>> input = ds.rows().iterator();
            private List<String> next = findNext();

            private List<String> findNext() {
                while (input.hasNext()) {
                    List<String> row = input.next();
                    int index = rowIndex[0]++;
                    if (seen.add(row)) return row;
                    removed[0]++;
                    changes.add(new Change(index, "(entire row)", summarize(row), "removed as duplicate"));
                }
                return null;
            }

            @Override public boolean hasNext() { return next != null; }
            @Override public List<String> next() {
                if (next == null) throw new NoSuchElementException();
                List<String> row = next;
                next = findNext();
                return row;
            }
        };
        DataSet result = DataSet.fromRows(ds.name(), ds.columns(), output);
        return new Outcome(result, "Removed " + removed[0] + " duplicate row(s).", removed[0], List.copyOf(changes));
    }

    public static Outcome dropMissing(DataSet ds, int col) {
        List<Change> changes = new ArrayList<>();
        String name = ds.columns().get(col);
        int[] removed = {0}, rowIndex = {0};
        Iterable<List<String>> output = () -> new Iterator<>() {
            private final Iterator<List<String>> input = ds.rows().iterator();
            private List<String> next = findNext();

            private List<String> findNext() {
                while (input.hasNext()) {
                    List<String> row = input.next();
                    int index = rowIndex[0]++;
                    if (col < row.size() && !row.get(col).isBlank()) return row;
                    removed[0]++;
                    changes.add(new Change(index, name, "(missing)", "row removed"));
                }
                return null;
            }

            @Override public boolean hasNext() { return next != null; }
            @Override public List<String> next() {
                if (next == null) throw new NoSuchElementException();
                List<String> row = next;
                next = findNext();
                return row;
            }
        };
        DataSet result = DataSet.fromRows(ds.name(), ds.columns(), output);
        return new Outcome(result, "Dropped " + removed[0] + " row(s) with a missing '" + name + "'.", removed[0], List.copyOf(changes));
    }

    /** strategy: "mean", "median" or "mode". */
    public static Outcome impute(DataSet ds, int col, String strategy) {
        String name = ds.columns().get(col);
        String fill;
        if (strategy.equals("mode")) fill = mode(ds, col);
        else {
            double[] x = ds.numericColumn(col);
            double v = strategy.equals("median") ? Stats.median(x) : Stats.mean(x);
            fill = num(v);
        }
        if (fill == null) return new Outcome(ds, "Nothing to impute in '" + name + "'.", 0, List.of());
        List<Change> changes = new ArrayList<>(); int[] changed = {0}, rowIndex = {0};
        Iterable<List<String>> output = () -> new Iterator<>() {
            private final Iterator<List<String>> input = ds.rows().iterator();
            @Override public boolean hasNext() { return input.hasNext(); }
            @Override public List<String> next() {
                int index = rowIndex[0]++;
                List<String> original = input.next();
                List<String> row = new ArrayList<>(original);
                while (row.size() <= col) row.add("");
                if (row.get(col).isBlank()) {
                    row.set(col, fill);
                    changed[0]++;
                    changes.add(new Change(index, name, "(missing)", fill));
                }
                return row;
            }
        };
        DataSet result = DataSet.fromRows(ds.name(), ds.columns(), output);
        return new Outcome(result, "Filled " + changed[0] + " missing cell(s) in '" + name + "' with " + strategy + " = " + fill + ".",
            changed[0], List.copyOf(changes));
    }

    /** Winsorise: values beyond mean ± z·std are clipped to the boundary. */
    public static Outcome clipOutliers(DataSet ds, int col, double z) {
        double[] x = ds.numericColumn(col);
        double m = Stats.mean(x), s = Stats.std(x), lo = m - z * s, hi = m + z * s;
        String name = ds.columns().get(col);
        List<Change> changes = new ArrayList<>(); int[] changed = {0}, rowIndex = {0};
        Iterable<List<String>> output = () -> new Iterator<>() {
            private final Iterator<List<String>> input = ds.rows().iterator();
            @Override public boolean hasNext() { return input.hasNext(); }
            @Override public List<String> next() {
                int index = rowIndex[0]++;
                List<String> row = new ArrayList<>(input.next());
                double v = x[index];
                if (Double.isFinite(v) && (v < lo || v > hi) && col < row.size()) {
                    String before = row.get(col), after = num(v < lo ? lo : hi);
                    row.set(col, after); changed[0]++;
                    changes.add(new Change(index, name, before, after));
                }
                return row;
            }
        };
        DataSet result = DataSet.fromRows(ds.name(), ds.columns(), output);
        return new Outcome(result, "Clipped " + changed[0] + " outlier(s) in '" + name + "' to [" + num(lo) + ", " + num(hi) + "].",
            changed[0], List.copyOf(changes));
    }

    private static String summarize(List<String> row) {
        String joined = String.join(" | ", row);
        return joined.length() > 60 ? joined.substring(0, 57) + "…" : joined;
    }

    private static String mode(DataSet ds, int col) {
        Map<String, Integer> counts = new HashMap<>();
        for (int i = 0; i < ds.rowCount(); i++) { String v = ds.value(i, col); if (!v.isBlank()) counts.merge(v, 1, Integer::sum); }
        return counts.entrySet().stream().max(Map.Entry.comparingByValue()).map(Map.Entry::getKey).orElse(null);
    }

    static String num(double v) {
        if (v == Math.rint(v) && Math.abs(v) < 1e15) return String.valueOf((long) v);
        return String.valueOf(Math.round(v * 10000.0) / 10000.0);
    }
}
