package com.datascope.analysis;

import java.util.List;

import com.datascope.ml.Stats;
import com.datascope.model.ColumnProfile;
import com.datascope.model.ColumnType;
import com.datascope.model.DataSet;

/* A transparent, explainable data-quality score. */
public final class DataQuality {
    private DataQuality() {}

    public record Result(int score, double completeness, double uniqueness, double consistency,
                         double validity, double usefulness, long missingCells, int duplicateRows,
                         int constantColumns, int idLikeColumns, long outlierCells, long numericCells,
                         String verdict) {}

    public static Result score(DataSet ds, List<ColumnProfile> ps) {
        int rows = ds.rowCount(), cols = ds.columnCount();
        if (rows == 0 || cols == 0) return new Result(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, "No data loaded.");

        long cells = (long) rows * cols, missing = 0;
        for (ColumnProfile p : ps) missing += p.missing();
        double completeness = clamp01(1 - (double) missing / cells);

        int dups = Profiler.duplicateRows(ds);
        double uniqueness = clamp01(1 - (double) dups / rows);

        int constant = 0, idLike = 0;
        long outliers = 0, numericCells = 0;
        for (int c = 0; c < cols; c++) {
            ColumnProfile p = ps.get(c);
            if (p.unique() <= 1) constant++;
            if (p.type() == ColumnType.TEXT && p.unique() > rows * 0.9) idLike++;
            if (p.type() == ColumnType.NUMERIC) {
                double[] values = ds.numericColumn(c);
                int finite = 0;
                for (double value : values) if (Double.isFinite(value)) finite++;
                if (finite > 3) {
                    double med = Stats.median(values);
                    double[] dev = new double[values.length];
                    for (int i = 0; i < values.length; i++) dev[i] = Double.isFinite(values[i]) ? Math.abs(values[i] - med) : Double.NaN;
                    double mad = Stats.median(dev) * 1.4826;
                    double scale = mad < 1e-9 ? Stats.std(values) : mad;
                    if (scale > 1e-12) {
                        for (double v : values) if (Double.isFinite(v)) { numericCells++; if (Math.abs((v - med) / scale) >= 4) outliers++; }
                    } else numericCells += finite;
                }
            }
        }
        double consistency = clamp01(1 - (double) constant / cols);
        double validity = numericCells == 0 ? 1 : clamp01(1 - (double) outliers / numericCells);
        double usefulness = clamp01(1 - (double) (constant + idLike) / cols);

        double s = 100 * (0.40 * completeness + 0.20 * uniqueness + 0.15 * consistency
            + 0.10 * validity + 0.15 * usefulness);
        int score = (int) Math.round(Math.max(0, Math.min(100, s)));
        String verdict = score >= 90 ? "Excellent — analysis-ready."
            : score >= 75 ? "Good — a few issues worth noting."
            : score >= 55 ? "Fair — cleaning recommended before modelling."
            : "Poor — clean this data before trusting any model.";
        return new Result(score, completeness, uniqueness, consistency, validity, usefulness,
            missing, dups, constant, idLike, outliers, numericCells, verdict);
    }

    private static double clamp01(double v) { return Math.max(0, Math.min(1, v)); }
}
