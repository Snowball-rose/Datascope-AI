package com.datascope.analysis;

import com.datascope.ml.Stats;
import com.datascope.model.*;

import java.util.*;

/** Rule-based "what should I know about this dataset?" findings. */
public final class Insights {
    private Insights() {}

    public enum Level { GOOD, INFO, WARN }
    public record Insight(Level level, String title, String detail) {}

    public static final int MAX_CORR_COLUMNS = 14;

    public static List<Insight> generate(DataSet ds, List<ColumnProfile> ps) {
        List<Insight> out = new ArrayList<>();
        if (ds.rowCount() == 0) return out;

        int dups = Profiler.duplicateRows(ds);
        if (dups > 0) out.add(new Insight(Level.WARN, dups + " duplicate rows",
            "Identical rows can bias models. Use CLEAN → Remove duplicates."));

        for (ColumnProfile p : ps) {
            if (p.missingPct() >= 0.05)
                out.add(new Insight(Level.WARN, p.name() + " is " + pct(p.missingPct()) + " missing",
                    "Consider imputing (mean/median for numeric, mode for categorical) before modelling."));
            else if (p.missing() > 0)
                out.add(new Insight(Level.INFO, p.name() + " has " + p.missing() + " missing value(s)",
                    "Small gap; imputation is safe."));
            if (p.unique() <= 1 && ds.rowCount() > 1)
                out.add(new Insight(Level.WARN, p.name() + " is constant",
                    "Carries no information; exclude it from models."));
            if (p.type() == ColumnType.TEXT && p.unique() > ds.rowCount() * 0.9)
                out.add(new Insight(Level.INFO, p.name() + " looks like an identifier",
                    "Nearly every value is unique, so it is not useful as a feature."));
        }

        List<Integer> num = new ArrayList<>();
        for (int i = 0; i < ps.size(); i++) if (ps.get(i).type() == ColumnType.NUMERIC && ps.get(i).unique() > 1) num.add(i);

        for (int i : num) {
            double sk = Stats.skewness(ds.numericColumn(i));
            if (Math.abs(sk) >= 1.0)
                out.add(new Insight(Level.INFO, ps.get(i).name() + " is " + (sk > 0 ? "right" : "left") + "-skewed (" + String.format("%.2f", sk) + ")",
                    "A log transform or robust scaling may help linear models."));
        }

        List<Integer> corrCols = num.size() > MAX_CORR_COLUMNS ? num.subList(0, MAX_CORR_COLUMNS) : num;
        List<double[]> cols = new ArrayList<>();
        for (int i : corrCols) cols.add(ds.numericColumn(i));
        double[][] m = Stats.correlationMatrix(cols);
        for (int a = 0; a < m.length; a++) for (int b = a + 1; b < m.length; b++)
            if (Math.abs(m[a][b]) >= 0.7)
                out.add(new Insight(Level.INFO, ps.get(corrCols.get(a)).name() + " ↔ " + ps.get(corrCols.get(b)).name() + " (r = " + String.format("%.2f", m[a][b]) + ")",
                    "Strongly correlated features are redundant; consider keeping one."));

        for (int i = 0; i < ps.size(); i++) {
            ColumnType t = ps.get(i).type();
            if ((t == ColumnType.BOOLEAN || t == ColumnType.CATEGORICAL) && ps.get(i).unique() == 2) {
                Map<String, Integer> c = new HashMap<>();
                for (int r = 0; r < ds.rowCount(); r++) { String v = ds.value(r, i); if (!v.isBlank()) c.merge(v, 1, Integer::sum); }
                int total = c.values().stream().mapToInt(Integer::intValue).sum();
                int minor = c.values().stream().mapToInt(Integer::intValue).min().orElse(0);
                if (total > 0 && minor < total * 0.2)
                    out.add(new Insight(Level.INFO, ps.get(i).name() + " is imbalanced (" + pct((double) minor / total) + " minority)",
                        "Accuracy alone is misleading here; watch precision, recall and F1."));
            }
        }

        boolean anyWarn = out.stream().anyMatch(x -> x.level() == Level.WARN);
        if (!anyWarn) out.add(0, new Insight(Level.GOOD, "No major data-quality problems found",
            "No heavy missingness, duplicates or constant columns were detected."));
        out.sort(Comparator.comparingInt(x -> switch (x.level()) { case WARN -> 0; case GOOD -> 1; case INFO -> 2; }));
        return out;
    }

    /** Names and correlation matrix for the numeric columns shown in the heatmap. */
    public record Correlation(List<String> names, double[][] matrix) {}

    public static Correlation correlation(DataSet ds, List<ColumnProfile> ps) {
        List<String> names = new ArrayList<>(); List<double[]> cols = new ArrayList<>();
        for (int i = 0; i < ps.size() && names.size() < MAX_CORR_COLUMNS; i++)
            if (ps.get(i).type() == ColumnType.NUMERIC) { names.add(ps.get(i).name()); cols.add(ds.numericColumn(i)); }
        return new Correlation(names, Stats.correlationMatrix(cols));
    }

    private static String pct(double f) { return String.format("%.1f%%", f * 100); }
}
