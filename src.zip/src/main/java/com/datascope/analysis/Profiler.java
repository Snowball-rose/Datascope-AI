package com.datascope.analysis;

import com.datascope.model.*;
import java.util.*;
import java.util.regex.Pattern;

public final class Profiler {
    private static final Pattern DATE_LIKE = Pattern.compile("\\d{4}[-/]\\d{1,2}[-/]\\d{1,2}.*");
    private static final int COLUMNS_PER_PASS = 4;

    private Profiler() {}
    public static List<ColumnProfile> profile(DataSet ds) {
        List<ColumnProfile> out = new ArrayList<>(ds.columnCount());
        for (int first = 0; first < ds.columnCount(); first += COLUMNS_PER_PASS) {
            int end = Math.min(ds.columnCount(), first + COLUMNS_PER_PASS);
            ColumnStats[] stats = new ColumnStats[end - first];
            for (int c = first; c < end; c++) stats[c - first] = new ColumnStats();

            for (int r = 0; r < ds.rowCount(); r++) {
                List<String> row = ds.row(r);
                for (int c = first; c < end; c++)
                    stats[c - first].add(c < row.size() ? row.get(c) : "");
            }
            for (int c = first; c < end; c++)
                out.add(stats[c - first].profile(ds.columns().get(c), ds.rowCount()));
        }
        return out;
    }

    private static final class ColumnStats {
        private final Set<String> unique = new HashSet<>();
        private int missing, nonEmpty, numeric, bools, dateLike, numericCount;
        private double mean, m2, min = Double.POSITIVE_INFINITY, max = Double.NEGATIVE_INFINITY;
        private String sample = "";

        private void add(String value) {
            String v = value.trim();
            if (v.isEmpty()) {
                missing++;
                return;
            }
            nonEmpty++;
            unique.add(v);
            if (sample.isEmpty()) sample = v;
            if (v.equalsIgnoreCase("true") || v.equalsIgnoreCase("false") || v.equals("0") || v.equals("1")) bools++;
            if (DATE_LIKE.matcher(v).matches()) dateLike++;
            Double d = DataSet.parseDouble(v);
            if (d == null) return;
            numeric++;
            numericCount++;
            double delta = d - mean;
            mean += delta / numericCount;
            m2 += delta * (d - mean);
            min = Math.min(min, d);
            max = Math.max(max, d);
        }

        private ColumnProfile profile(String name, int rowCount) {
            double categoricalLimit = Math.max(25, rowCount * 0.05);
            ColumnType type;
            if (nonEmpty == 0) type = ColumnType.TEXT;
            else if ((long) numeric * 100 >= (long) nonEmpty * 90) type = ColumnType.NUMERIC;
            else if ((long) bools * 100 >= (long) nonEmpty * 95) type = ColumnType.BOOLEAN;
            else if ((long) dateLike * 100 >= (long) nonEmpty * 85) type = ColumnType.DATETIME;
            else if (unique.size() <= categoricalLimit) type = ColumnType.CATEGORICAL;
            else type = ColumnType.TEXT;
            double profileMean = numericCount == 0 ? Double.NaN : mean;
            double profileMin = numericCount == 0 ? Double.NaN : min;
            double profileMax = numericCount == 0 ? Double.NaN : max;
            double std = numericCount > 1 ? Math.sqrt(m2 / (numericCount - 1)) : 0;
            double missingPct = rowCount == 0 ? 0 : (double) missing / rowCount;
            return new ColumnProfile(name, type, missing, unique.size(), profileMean,
                profileMin, profileMax, std, sample, missingPct);
        }
    }

    public static int duplicateRows(DataSet ds) {
        Set<List<String>> seen = new HashSet<>(); int dup=0;
        for (List<String> row: ds.rows()) if (!seen.add(row)) dup++;
        return dup;
    }
}
