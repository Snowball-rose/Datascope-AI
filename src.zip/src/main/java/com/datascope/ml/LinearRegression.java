package com.datascope.ml;
public final class LinearRegression {
    public record Result(double[] weights,double intercept,double r2) {}
    public static Result fit(double[][] x,double[] y){
        int n=x.length,p=x[0].length;double[] w=new double[p];double b=Stats.mean(y);double lr=0.01;
        for(int e=0;e<1200;e++){double[]gw=new double[p];double gb=0;for(int i=0;i<n;i++){double pred=b;for(int j=0;j<p;j++)pred+=w[j]*x[i][j];double err=pred-y[i];for(int j=0;j<p;j++)gw[j]+=err*x[i][j];gb+=err;}for(int j=0;j<p;j++)w[j]-=lr*gw[j]/n;b-=lr*gb/n;}
        double mean=Stats.mean(y),ssTot=0,ssRes=0;for(int i=0;i<n;i++){double pred=b;for(int j=0;j<p;j++)pred+=w[j]*x[i][j];ssRes+=(y[i]-pred)*(y[i]-pred);ssTot+=(y[i]-mean)*(y[i]-mean);}return new Result(w,b,ssTot==0?0:1-ssRes/ssTot);
    }

    /** Fits selected source rows without duplicating their feature matrix. */
    public static Result fitSelected(double[][] x, double[] y, int[] rows, int epochs) {
        if (rows.length == 0) throw new IllegalArgumentException("Training data is empty.");
        int p = x[0].length;
        double[] weights = new double[p];
        double intercept = 0;
        for (int row : rows) intercept += y[row];
        intercept /= rows.length;
        for (int epoch = 0; epoch < epochs; epoch++) {
            double[] gradient = new double[p];
            double biasGradient = 0;
            for (int row : rows) {
                double prediction = intercept;
                for (int j = 0; j < p; j++) prediction += weights[j] * x[row][j];
                double error = prediction - y[row];
                for (int j = 0; j < p; j++) gradient[j] += error * x[row][j];
                biasGradient += error;
            }
            for (int j = 0; j < p; j++) weights[j] -= 0.01 * gradient[j] / rows.length;
            intercept -= 0.01 * biasGradient / rows.length;
        }
        double mean = 0;
        for (int row : rows) mean += y[row];
        mean /= rows.length;
        double total = 0, residual = 0;
        for (int row : rows) {
            double prediction = intercept;
            for (int j = 0; j < p; j++) prediction += weights[j] * x[row][j];
            residual += (y[row] - prediction) * (y[row] - prediction);
            total += (y[row] - mean) * (y[row] - mean);
        }
        return new Result(weights, intercept, total == 0 ? 0 : 1 - residual / total);
    }
}
