package com.datascope.ml;

import java.util.*;

public final class KMeans {
    public record Result(int[] labels, double[][] centroids, int iterations, double inertia) {}

    /** Lloyd's algorithm with k-means++ seeding. */
    public static Result fit(double[][] data, int k, int maxIter, Random rnd) {
        if (data.length == 0) return new Result(new int[0], new double[0][0], 0, 0);
        k = Math.max(2, Math.min(k, data.length));
        int p = data[0].length;
        double[][] c = seed(data, k, rnd);
        int[] labels = new int[data.length];
        Arrays.fill(labels, -1);
        int it = 0;
        for (; it < maxIter; it++) {
            boolean changed = false;
            for (int i = 0; i < data.length; i++) {
                int best = 0; double bd = Double.POSITIVE_INFINITY;
                for (int j = 0; j < k; j++) { double d = dist2(data[i], c[j]); if (d < bd) { bd = d; best = j; } }
                if (labels[i] != best) { labels[i] = best; changed = true; }
            }
            double[][] sum = new double[k][p]; int[] count = new int[k];
            for (int i = 0; i < data.length; i++) { int g = labels[i]; count[g]++; for (int j = 0; j < p; j++) sum[g][j] += data[i][j]; }
            for (int g = 0; g < k; g++) if (count[g] > 0) for (int j = 0; j < p; j++) c[g][j] = sum[g][j] / count[g];
            if (!changed) break;
        }
        double inertia = 0;
        for (int i = 0; i < data.length; i++) inertia += dist2(data[i], c[labels[i]]);
        return new Result(labels, c, it + 1, inertia);
    }

    private static double[][] seed(double[][] data, int k, Random rnd) {
        double[][] c = new double[k][];
        c[0] = data[rnd.nextInt(data.length)].clone();
        double[] d2 = new double[data.length];
        for (int g = 1; g < k; g++) {
            double total = 0;
            for (int i = 0; i < data.length; i++) {
                double best = Double.POSITIVE_INFINITY;
                for (int j = 0; j < g; j++) best = Math.min(best, dist2(data[i], c[j]));
                d2[i] = best; total += best;
            }
            int pick = data.length - 1;
            if (total > 0) {
                double r = rnd.nextDouble() * total, acc = 0;
                for (int i = 0; i < data.length; i++) { acc += d2[i]; if (acc >= r) { pick = i; break; } }
            } else pick = rnd.nextInt(data.length);
            c[g] = data[pick].clone();
        }
        return c;
    }

    private static double dist2(double[] a, double[] b) { double s = 0; for (int j = 0; j < a.length; j++) { double d = a[j] - b[j]; s += d * d; } return s; }
}
