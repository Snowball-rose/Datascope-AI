package com.datascope.ml;

import java.util.*;

/** Evaluation helpers: splits, classification metrics, silhouette. */
public final class Metrics {
    private Metrics() {}

    public record Split(int[] train, int[] test) {}

    public static Split split(int n, double testFraction, Random rnd) {
        if (n <= 0) return new Split(new int[0], new int[0]);
        int[] idx = new int[n];
        for (int i = 0; i < n; i++) idx[i] = i;
        for (int i = n - 1; i > 0; i--) {
            int j = rnd.nextInt(i + 1), value = idx[i];
            idx[i] = idx[j]; idx[j] = value;
        }
        int nTest = Math.max(1, (int) Math.round(n * testFraction));
        nTest = Math.min(nTest, Math.max(1, n - 1));
        int[] test = new int[nTest], train = new int[n - nTest];
        for (int i = 0; i < n; i++) { if (i < nTest) test[i] = idx[i]; else train[i - nTest] = idx[i]; }
        return new Split(train, test);
    }

    public static double[][] rows(double[][] x, int[] idx) {
        double[][] o = new double[idx.length][];
        for (int i = 0; i < idx.length; i++) o[i] = x[idx[i]];
        return o;
    }
    public static int[] pick(int[] y, int[] idx) {
        int[] o = new int[idx.length];
        for (int i = 0; i < idx.length; i++) o[i] = y[idx[i]];
        return o;
    }
    public static double[] pick(double[] y, int[] idx) {
        double[] o = new double[idx.length];
        for (int i = 0; i < idx.length; i++) o[i] = y[idx[i]];
        return o;
    }

    /** Binary confusion counts. */
    public record Confusion(int tp, int fp, int tn, int fn) {
        public double accuracy() { int n = tp + fp + tn + fn; return n == 0 ? 0 : (double) (tp + tn) / n; }
        public double precision() { return tp + fp == 0 ? 0 : (double) tp / (tp + fp); }
        public double recall() { return tp + fn == 0 ? 0 : (double) tp / (tp + fn); }
        public double f1() { double p = precision(), r = recall(); return p + r == 0 ? 0 : 2 * p * r / (p + r); }
    }

    public static Confusion confusion(int[] actual, int[] predicted) {
        int tp = 0, fp = 0, tn = 0, fn = 0;
        for (int i = 0; i < actual.length; i++) {
            if (actual[i] == 1 && predicted[i] == 1) tp++;
            else if (actual[i] == 0 && predicted[i] == 1) fp++;
            else if (actual[i] == 0 && predicted[i] == 0) tn++;
            else fn++;
        }
        return new Confusion(tp, fp, tn, fn);
    }

    public static double r2(double[] actual, double[] pred) {
        double m = Stats.mean(actual), tot = 0, res = 0;
        for (int i = 0; i < actual.length; i++) { tot += (actual[i] - m) * (actual[i] - m); res += (actual[i] - pred[i]) * (actual[i] - pred[i]); }
        return tot == 0 ? 0 : 1 - res / tot;
    }

    public static double rmse(double[] actual, double[] pred) {
        double s = 0;
        for (int i = 0; i < actual.length; i++) s += (actual[i] - pred[i]) * (actual[i] - pred[i]);
        return actual.length == 0 ? 0 : Math.sqrt(s / actual.length);
    }

    /** Mean silhouette coefficient on at most maxRows points (O(n^2)). Range -1..1, higher is better. */
    public static double silhouette(double[][] x, int[] labels, int k, int maxRows) {
        int n = Math.min(x.length, maxRows);
        if (n < 3 || k < 2) return 0;
        double total = 0; int counted = 0;
        for (int sample = 0; sample < n; sample++) {
            int i = (int) ((long) sample * (x.length - 1) / (n - 1));
            double[] sum = new double[k]; int[] cnt = new int[k];
            for (int other = 0; other < n; other++) {
                int j = (int) ((long) other * (x.length - 1) / (n - 1));
                if (i == j) continue;
                sum[labels[j]] += Math.sqrt(dist2(x[i], x[j])); cnt[labels[j]]++;
            }
            int own = labels[i];
            if (cnt[own] == 0) continue;
            double a = sum[own] / cnt[own], b = Double.POSITIVE_INFINITY;
            for (int g = 0; g < k; g++) if (g != own && cnt[g] > 0) b = Math.min(b, sum[g] / cnt[g]);
            if (!Double.isFinite(b)) continue;
            double m = Math.max(a, b);
            total += m == 0 ? 0 : (b - a) / m; counted++;
        }
        return counted == 0 ? 0 : total / counted;
    }

    private static double dist2(double[] a, double[] b) {
        double s = 0; for (int j = 0; j < a.length; j++) { double d = a[j] - b[j]; s += d * d; } return s;
    }
}
