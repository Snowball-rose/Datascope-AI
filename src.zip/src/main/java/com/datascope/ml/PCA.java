package com.datascope.ml;
import java.util.*;
public final class PCA {
    public record Result(double[][] points,double[] eigenvalues,double[][] components){}
    public record SampledResult(double[][] points,int[] rows,double[] eigenvalues,double[][] components){}
    public static Result fitTransform(double[][] data,int dims){
        if(data.length==0)return new Result(new double[0][0],new double[0],new double[0][0]);
        return fitTransformStandardized(Stats.standardize(data), dims);
    }
    public static Result fitTransformStandardized(double[][] z,int dims){
        SampledResult result = fitTransformStandardizedSampled(z, dims, z.length);
        return new Result(result.points(), result.eigenvalues(), result.components());
    }
    public static SampledResult fitTransformStandardizedSampled(double[][] z,int dims,int maxPoints){
        if(z.length==0)return new SampledResult(new double[0][0],new int[0],new double[0],new double[0][0]);
        int n=Math.min(z.length,Math.max(0,maxPoints));
        int[] rows=new int[n];
        for(int i=0;i<n;i++)rows[i]=n==1?0:(int)((long)i*(z.length-1)/(n-1));
        return fitTransformStandardizedRows(z,dims,rows);
    }
    public static SampledResult fitTransformStandardizedRows(double[][] z,int dims,int[] rows){
        if(z.length==0)return new SampledResult(new double[0][0],new int[0],new double[0],new double[0][0]);
        int p=z[0].length; dims=Math.min(Math.max(2,dims),p);
        double[][] cov=new double[p][p]; for(int i=0;i<p;i++)for(int j=i;j<p;j++){double s=0;for(double[] row:z)s+=row[i]*row[j];cov[i][j]=cov[j][i]=s/Math.max(1,z.length-1);}
        double[][] comps=new double[dims][p]; double[] eig=new double[dims];
        for(int d=0;d<dims;d++){
            double[] v=new double[p]; v[d%p]=1; for(int iter=0;iter<150;iter++){double[] nv=mul(cov,v);normalize(nv);v=nv;}
            double ev=dot(v,mul(cov,v)); eig[d]=ev; comps[d]=v.clone();
            for(int i=0;i<p;i++)for(int j=0;j<p;j++)cov[i][j]-=ev*v[i]*v[j];
        }
        double[][] pts=new double[rows.length][dims]; int[] selected=rows.clone();
        for(int i=0;i<selected.length;i++){Objects.checkIndex(selected[i],z.length);for(int d=0;d<dims;d++)pts[i][d]=dot(z[selected[i]],comps[d]);}
        return new SampledResult(pts,selected,eig,comps);
    }
    private static double[] mul(double[][]a,double[]v){double[]o=new double[v.length];for(int i=0;i<a.length;i++)for(int j=0;j<v.length;j++)o[i]+=a[i][j]*v[j];return o;}
    private static double dot(double[]a,double[]b){double s=0;for(int i=0;i<a.length;i++)s+=a[i]*b[i];return s;}
    private static void normalize(double[]v){double n=Math.sqrt(dot(v,v));if(n==0)return;for(int i=0;i<v.length;i++)v[i]/=n;}
}
