package com.datascope.ml;
public final class LogisticRegression {
    public record Result(double[] weights,double intercept,double accuracy) {}
    public static Result fit(double[][] x,int[] y,int epochs,double lr){
        int n=x.length,p=x[0].length; double[] w=new double[p];double b=0;
        for(int e=0;e<epochs;e++){double[] gw=new double[p];double gb=0;for(int i=0;i<n;i++){double z=b;for(int j=0;j<p;j++)z+=w[j]*x[i][j];double pr=sigmoid(z),err=pr-y[i];for(int j=0;j<p;j++)gw[j]+=err*x[i][j];gb+=err;}for(int j=0;j<p;j++)w[j]-=lr*gw[j]/n;b-=lr*gb/n;}
        int correct=0;for(int i=0;i<n;i++)if(predict(x[i],w,b)==y[i])correct++;
        return new Result(w,b,(double)correct/n);
    }
    /** Fits against selected rows without copying a large feature matrix for the training split. */
    public static Result fitSelected(double[][] x, int[] y, int[] rows, int epochs, double lr) {
        if (rows.length == 0) throw new IllegalArgumentException("Training data is empty.");
        int p = x[0].length;
        double[] weights = new double[p];
        double intercept = 0;
        for (int epoch = 0; epoch < epochs; epoch++) {
            double[] gradient = new double[p];
            double biasGradient = 0;
            for (int row : rows) {
                double prediction = sigmoid(score(x[row], weights, intercept));
                double error = prediction - y[row];
                for (int j = 0; j < p; j++) gradient[j] += error * x[row][j];
                biasGradient += error;
            }
            for (int j = 0; j < p; j++) weights[j] -= lr * gradient[j] / rows.length;
            intercept -= lr * biasGradient / rows.length;
        }
        int correct = 0;
        for (int row : rows) if (predict(x[row], weights, intercept) == y[row]) correct++;
        return new Result(weights, intercept, (double) correct / rows.length);
    }
    public static int predict(double[] x,double[]w,double b){double z=b;for(int j=0;j<x.length;j++)z+=w[j]*x[j];return sigmoid(z)>=.5?1:0;}
    /** Probability that the row belongs to the positive class (sigmoid of the linear score). */
    public static double probability(double[] x,double[]w,double b){double z=b;for(int j=0;j<x.length;j++)z+=w[j]*x[j];return sigmoid(z);}
    private static double score(double[] x, double[] weights, double intercept) {
        double value = intercept;
        for (int j = 0; j < x.length; j++) value += weights[j] * x[j];
        return value;
    }
    private static double sigmoid(double x){if(x>=0){double e=Math.exp(-x);return 1/(1+e);}double e=Math.exp(x);return e/(1+e);}
}
