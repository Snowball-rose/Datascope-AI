package com.datascope.ml;

import java.util.*;

public final class Stats {
    private Stats() {}

    public static double mean(double[] x) {
        double s = 0; int n = 0;
        for (double v : x) if (Double.isFinite(v)) { s += v; n++; }
        return n == 0 ? 0 : s / n;
    }

    public static double std(double[] x) {
        double m = mean(x), s = 0; int n = 0;
        for (double v : x) if (Double.isFinite(v)) { s += (v - m) * (v - m); n++; }
        return n < 2 ? 1 : Math.sqrt(s / (n - 1));
    }

    public static double median(double[] x) {
        double[] f = Arrays.stream(x).filter(Double::isFinite).sorted().toArray();
        if (f.length == 0) return 0;
        return f.length % 2 == 0 ? (f[f.length / 2 - 1] + f[f.length / 2]) / 2 : f[f.length / 2];
    }

    /** Sample skewness (Fisher-Pearson). Returns 0 for degenerate input. */
    public static double skewness(double[] x) {
        double[] f = Arrays.stream(x).filter(Double::isFinite).toArray();
        if (f.length < 3) return 0;
        double m = mean(f), s = std(f);
        if (s < 1e-12) return 0;
        double acc = 0;
        for (double v : f) acc += Math.pow((v - m) / s, 3);
        return acc / f.length;
    }

    public static double[] fillMean(double[] x) {
        double m = mean(x); double[] y = x.clone();
        for (int i = 0; i < y.length; i++) if (!Double.isFinite(y[i])) y[i] = m;
        return y;
    }

    public static double correlation(double[] a, double[] b) {
        double ma = mean(a), mb = mean(b), num = 0, da = 0, db = 0;
        for (int i = 0; i < a.length && i < b.length; i++) {
            if (!Double.isFinite(a[i]) || !Double.isFinite(b[i])) continue;
            double x = a[i] - ma, y = b[i] - mb;
            num += x * y; da += x * x; db += y * y;
        }
        return da == 0 || db == 0 ? 0 : num / Math.sqrt(da * db);
    }

    public static double[][] correlationMatrix(List<double[]> columns) {
        int p = columns.size();
        double[][] m = new double[p][p];
        for (int i = 0; i < p; i++) {
            m[i][i] = 1;
            for (int j = i + 1; j < p; j++) m[i][j] = m[j][i] = correlation(columns.get(i), columns.get(j));
        }
        return m;
    }

    /** Z-score standardisation. Constant columns become all zeros instead of NaN. */
    public static double[][] standardize(double[][] x) {
        if (x.length == 0) return new double[0][0];
        double[][] z = new double[x.length][];
        for (int i = 0; i < x.length; i++) z[i] = x[i].clone();
        standardizeInPlace(z);
        return z;
    }

    /** Standardizes a dense matrix without allocating a second matrix or temporary column arrays. */
    public static double[][] standardizeInPlace(double[][] x) {
        if (x.length == 0) return x;
        int p = x[0].length;
        double[] means = new double[p], m2 = new double[p];
        int[] counts = new int[p];
        for (double[] row : x) {
            for (int j = 0; j < p; j++) {
                double value = row[j];
                if (!Double.isFinite(value)) continue;
                int count = ++counts[j];
                double delta = value - means[j];
                means[j] += delta / count;
                m2[j] += delta * (value - means[j]);
            }
        }
        double[] scales = new double[p];
        for (int j = 0; j < p; j++) {
            double s = counts[j] < 2 ? 1 : Math.sqrt(m2[j] / (counts[j] - 1));
            scales[j] = s < 1e-12 ? 1 : s;
        }
        for (double[] row : x)
            for (int j = 0; j < p; j++)
                row[j] = Double.isFinite(row[j]) ? (row[j] - means[j]) / scales[j] : 0;
        return x;
    }
}
