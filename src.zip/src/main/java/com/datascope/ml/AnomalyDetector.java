package com.datascope.ml;

import java.util.*;

public final class AnomalyDetector {
    /** scores: max robust |z| per row; topFeature: index of the feature that drives the score. */
    public record Result(double[] scores, boolean[] anomaly, int[] topFeature) {}

    /** Robust anomaly score using median/MAD per feature, with standard-deviation fallback. */
    public static Result zScore(double[][] x, double threshold) {
        if (x.length == 0) return new Result(new double[0], new boolean[0], new int[0]);
        int p = x[0].length;
        double[] med = new double[p], scale = new double[p];
        for (int j = 0; j < p; j++) {
            double[] c = new double[x.length];
            for (int i = 0; i < x.length; i++) c[i] = x[i][j];
            double[] orig = c.clone();
            Arrays.sort(c);
            med[j] = c[c.length / 2];
            double[] dev = new double[c.length];
            for (int i = 0; i < c.length; i++) dev[i] = Math.abs(c[i] - med[j]);
            Arrays.sort(dev);
            double mad = dev[dev.length / 2] * 1.4826;
            if (mad < 1e-9) mad = Stats.std(orig);
            scale[j] = Math.max(mad, 1e-9);
        }
        double[] scores = new double[x.length];
        boolean[] flag = new boolean[x.length];
        int[] top = new int[x.length];
        for (int i = 0; i < x.length; i++) {
            double mx = 0; int arg = 0;
            for (int j = 0; j < p; j++) {
                double z = Math.abs((x[i][j] - med[j]) / scale[j]);
                if (z > mx) { mx = z; arg = j; }
            }
            scores[i] = mx; flag[i] = mx >= threshold; top[i] = arg;
        }
        return new Result(scores, flag, top);
    }
}
