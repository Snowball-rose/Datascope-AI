# DataScope AI — Feature Map

## 01 DATA HUB
- Drag and drop CSV/XLSX onto the application.
- File chooser and demo dataset.
- CSV and XLSX rows are streamed into an indexed temporary row store.
- Background loading keeps the UI responsive.
- Overview browses 500-row pages and filters across the full dataset in the background.
- Pipeline overview.

## 02 PROFILE
- Row/column counts.
- Automatic column type inference.
- Missing-value count and percentage.
- Unique values.
- Numeric summary statistics.
- Duplicate-row count.

## 03 CLEAN
- Mean or median imputation preview.
- Z-score outlier scan.
- Export a cleaned CSV copy.
- Cleaning works across all rows; only the first 500 changed cells/rows are shown in the preview.
- Original input file is never overwritten.

## 04 ML STUDIO
- K-Means clustering.
- PCA dimensionality reduction.
- Logistic regression for binary targets.
- Linear regression.
- Explicit target-column selection.
- Experiment metrics are computed off the UI thread.
- Models fit against all rows; Explorer projections are representative samples (up to 1,500 points).
- Silhouette and elbow diagnostics use representative samples where their cost would otherwise be quadratic or repetitive.

## 05 ANOMALY
- Robust median/MAD anomaly scoring.
- Configurable threshold.
- Top anomaly-score chart.
- Every row is scanned; all flagged rows can be paged through and exported.

## 06 3D EXPLORER
- Native JavaFX 3D scene.
- PCA point cloud.
- Cluster-aware point coloring.
- Mouse rotation.

## 07 LIVE STREAM
- Replay the loaded dataset row-by-row.
- Adjustable ingest rate.
- Bounded producer/consumer queue.
- Pause/resume/stop.
- Queue utilization and drop tracking.
- Backpressure indicator.
- UI updates are sampled instead of one UI callback per event.

## 08 BENCHMARK
- K-Means timing/inertia.
- PCA timing.
- Anomaly-detection timing/count.
- Runs off the JavaFX thread.

## 09 ABOUT
- Architecture and technology summary.
