# DataScope AI — Project Report Guide

## Suggested title
**DataScope AI: A Real-Time Java Platform for Automated Tabular Data Profiling, Machine Learning and 3D Analytics**

## Problem statement
Small and medium datasets are often analyzed manually using spreadsheets and disconnected scripts. There is a gap between easy-to-use spreadsheet workflows and engineering-grade streaming/ML pipelines.

## Proposed solution
A native JavaFX desktop platform that accepts CSV/XLSX data, infers schema, profiles quality, previews cleaning, applies ML techniques, detects anomalies, replays rows through a bounded concurrent pipeline, and visualizes results in 2D/3D.

## ML techniques implemented
- K-Means clustering
- PCA
- Logistic regression
- Linear regression
- Z-score anomaly detection
- Standardization and correlation statistics

## Engineering contributions
- Off-UI-thread file loading and ML work
- Bounded producer/consumer queue for real-time replay
- Backpressure telemetry
- Native JavaFX 3D point visualization
- CSV/XLSX support
- Deterministic benchmarkable experiments

## Evaluation ideas
Measure model runtime, anomaly counts under changing thresholds, PCA explained variance, K-Means inertia, logistic accuracy, queue utilization and throughput at 100 / 500 / 1000 / 2500 / 5000 rows per second.
