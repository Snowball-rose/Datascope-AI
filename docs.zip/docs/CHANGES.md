# What changed in this version

## UX revision — clarity, drill-down and immersion
- Sidebar tabs no longer carry numeric prefixes (`01`, `02`, …).
- The sample dataset is **no longer loaded automatically**; the app starts empty and the demo is opt-in via the Overview page.
- **Overview**
  - Quality score rebuilt around five explainable components (completeness 40%, uniqueness 20%, consistency 15%, validity 10%, usefulness 15%) with a visible breakdown and verdict. The old score could go negative and ignored constant/identifier columns and outliers.
  - The row filter is now column-specific: pick a column plus a match mode (contains, equals, starts with, is empty / not empty, `>` `≥` `<` `≤`).
  - Double-click any row to inspect all of its fields in a dialog.
- **Clean**: Preview now shows a table of the exact rows/cells that would change — row number, column, before and after — for imputation, outlier clipping and row drops.
- **ML Studio**: every technique (K-Means, PCA, logistic, linear) publishes a projection to the Explorer, with an “Open in Explorer” button.
- **Anomalies**: “Show in Explorer” now actually navigates to the Explorer and carries the flagged point cloud with it.
- **Explorer**: click any point to trace it back to its full source row; hover for a quick summary; technique-specific charts (cluster sizes, elbow, scree, residual/probability distributions, score histogram) render alongside the cloud.
- **Live Stream**: purpose explained up front; the live chart shows per-point details on hover (row index, value, z-score, alert); queue readout reflects the chosen capacity before a run starts.
- **Benchmark**: added a “how to read this page” explainer, a `ms / 1k rows` column, a labelled scaling curve and hover details.
- **Every chart** in every tab now shows details on hover via a shared `Ui.attachHover` helper; the correlation heatmap shows the exact `r` per cell.
- Added toast notifications, page fade-in transitions and dark-themed tooltips for a more immersive feel.


## New UI
- Sidebar navigation (10 pages) with a persistent top bar and status bar; a single shared `AppState` so every page updates when data changes.
- Rebuilt dark theme in `src/main/resources/datascope.css` (previously an inline string).
- New pages: **Insights** (findings + correlation heatmap), **Explorer** (3D/2D), and richer **Profile / Clean / ML Studio / Anomalies / Live Stream / Benchmark**.
- Views live in `com.datascope.app.views`; the shell is `DataScopeApp`.

## Engine improvements
- `Cleaner`: real, resettable cleaning steps (impute, clip, drop, de-duplicate).
- `Insights`: rule-based data findings; `Stats` gained median, skewness, correlation matrix.
- `Metrics`: train/test split, confusion matrix, precision/recall/F1, R², RMSE, silhouette.
- `KMeans` now uses k-means++ seeding.
- `AnomalyDetector` reports which feature drives each score.

## Bugs fixed
- `ReplayEngine` never signalled completion; the queue size was fixed and rate changes were ignored. Now completes correctly, has a configurable queue, and `setRate` works.
- Feature matrix construction recomputed a column mean for every missing cell (quadratic); now once per column.
- Supervised models could be trained with the target column as a feature (leakage); the target is now excluded.
- Constant columns produced NaN after standardisation; they now become zeros.
- Accuracy was measured on the training data; supervised models are now scored on a held-out 20% test set.
- The 3D view accumulated a new rotation transform on every mouse event; it now uses two reusable `Rotate` objects.
- The demo CSV is bundled on the classpath, so "Load demo data" works from any working directory.
