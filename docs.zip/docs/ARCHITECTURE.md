# DataScope AI Architecture

```text
                 +----------------------+
                 |       DATA HUB       |
                 |     CSV / XLSX       |
                 +----------+-----------+
                            |
                            v
                 +----------------------+
                 | Indexed DataSet Model |
                 | rows in temp file     |
                 +----------+-----------+
                            |
              +-------------+-------------+
              |                           |
              v                           v
     +------------------+         +------------------+
     |     Profiler     |         |  Data Cleaning   |
     | types / quality  |         | impute / export  |
     +--------+---------+         +--------+---------+
              |                           |
              +-------------+-------------+
                            v
                 +----------------------+
                 | Feature Preparation  |
                 | standardization      |
                 +----------+-----------+
                            |
          +-----------------+-----------------
          |          |          |             |
          v          v          v             v
       K-Means      PCA     Logistic       Linear
                              Regression    Regression
          |          |          |             |
          +----------+----------+-------------+
                            |
                            v
                 +----------------------+
                 |    Anomaly Engine    |
                 | robust z / MAD score |
                 +----------+-----------+
                            |
                            v
                 +----------------------+
                 |    JavaFX Views      |
                 | charts + tables + 3D |
                 +----------+-----------+
                            ^
                            |
                 +----------------------+
                 |    Live Replay       |
                 | bounded queue / rate |
                 +----------------------+
```

### Threading rule
File loading, full-dataset searches, quality scoring, cleaning, exports, ML experiments, anomaly
scans and benchmark runs execute on background threads. JavaFX updates are marshalled back to the
application thread. The Overview table loads one 500-row page at a time; CSV input and XLSX sheet
rows are streamed into a temporary indexed row store. Live replay uses a bounded queue and sampled
UI metrics to avoid the freeze problem seen in the earlier prototype.

Numeric ML operations still create a dense matrix for the selected features, so their working
memory grows with row count and feature count. Explorer projections, silhouette calculations and
the K-Means elbow diagnostic use representative samples; the underlying model fitting and anomaly
scan still process all dataset rows.
